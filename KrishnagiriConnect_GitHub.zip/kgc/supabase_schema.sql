-- ═══════════════════════════════════════════════════════════════
-- KRISHNAGIRI CONNECT — Complete Supabase Database Schema
-- ═══════════════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ROLES
CREATE TABLE roles (
  id TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  level INTEGER DEFAULT 8,
  color TEXT DEFAULT '#6B7280',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- DEPARTMENTS
CREATE TABLE departments (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT,
  color TEXT,
  head_officer_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TALUKS
CREATE TABLE taluks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL UNIQUE,
  district TEXT DEFAULT 'Krishnagiri',
  lat FLOAT,
  lng FLOAT,
  bdo_officer_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- USERS (extends Supabase auth.users)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  auth_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT REFERENCES roles(id) DEFAULT 'citizen',
  taluk TEXT,
  village TEXT,
  avatar TEXT DEFAULT '👤',
  status TEXT DEFAULT 'active' CHECK (status IN ('active','inactive','suspended')),
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- OFFICERS
CREATE TABLE officers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  name TEXT NOT NULL,
  designation TEXT NOT NULL,
  role TEXT REFERENCES roles(id),
  dept TEXT REFERENCES departments(id),
  phone TEXT,
  mobile TEXT,
  email TEXT,
  taluk TEXT,
  address TEXT,
  level INTEGER DEFAULT 3,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- VILLAGES
CREATE TABLE villages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  taluk TEXT NOT NULL,
  panchayat TEXT,
  lat FLOAT,
  lng FLOAT,
  population INTEGER DEFAULT 0,
  households INTEGER DEFAULT 0,
  water_score INTEGER DEFAULT 50,
  school_score INTEGER DEFAULT 50,
  road_score INTEGER DEFAULT 50,
  sanitation_score INTEGER DEFAULT 50,
  health_score INTEGER DEFAULT 50,
  safety_score INTEGER DEFAULT 50,
  vds INTEGER GENERATED ALWAYS AS (
    ROUND(water_score*0.25 + school_score*0.20 + road_score*0.20 + sanitation_score*0.15 + health_score*0.12 + safety_score*0.08)
  ) STORED,
  status TEXT GENERATED ALWAYS AS (
    CASE WHEN (water_score*0.25 + school_score*0.20 + road_score*0.20 + sanitation_score*0.15 + health_score*0.12 + safety_score*0.08)>=80 THEN 'green'
         WHEN (water_score*0.25 + school_score*0.20 + road_score*0.20 + sanitation_score*0.15 + health_score*0.12 + safety_score*0.08)>=60 THEN 'yellow'
         WHEN (water_score*0.25 + school_score*0.20 + road_score*0.20 + sanitation_score*0.15 + health_score*0.12 + safety_score*0.08)>=40 THEN 'orange'
         ELSE 'red' END
  ) STORED,
  water_source TEXT,
  schools_count INTEGER DEFAULT 0,
  last_inspection DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- SCHOOLS
CREATE TABLE schools (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  emis TEXT UNIQUE,
  type TEXT DEFAULT 'Primary School',
  village TEXT,
  taluk TEXT,
  panchayat TEXT,
  lat FLOAT,
  lng FLOAT,
  students INTEGER DEFAULT 0,
  teachers INTEGER DEFAULT 0,
  headmaster TEXT,
  phone TEXT,
  -- Infrastructure (boolean flags)
  has_drinking_water BOOLEAN DEFAULT false,
  has_toilets BOOLEAN DEFAULT false,
  has_girls_toilets BOOLEAN DEFAULT false,
  has_electricity BOOLEAN DEFAULT false,
  has_internet BOOLEAN DEFAULT false,
  has_library BOOLEAN DEFAULT false,
  has_science_lab BOOLEAN DEFAULT false,
  has_computer_lab BOOLEAN DEFAULT false,
  has_playground BOOLEAN DEFAULT false,
  has_cctv BOOLEAN DEFAULT false,
  has_boundary_wall BOOLEAN DEFAULT false,
  -- Score (computed)
  score INTEGER DEFAULT 0,
  status TEXT DEFAULT 'red',
  last_inspection DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- WATER ASSETS
CREATE TABLE water_assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  village TEXT,
  taluk TEXT,
  lat FLOAT,
  lng FLOAT,
  capacity TEXT,
  status TEXT DEFAULT 'Operational',
  officer_id UUID REFERENCES officers(id),
  dept TEXT REFERENCES departments(id),
  last_inspection DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- COMPLAINTS
CREATE TABLE complaints (
  id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  category_label TEXT,
  category_icon TEXT,
  dept TEXT REFERENCES departments(id),
  description TEXT,
  village TEXT,
  taluk TEXT,
  lat FLOAT,
  lng FLOAT,
  severity TEXT DEFAULT 'medium' CHECK (severity IN ('low','medium','high','critical','emergency')),
  status TEXT DEFAULT 'submitted',
  overdue BOOLEAN DEFAULT false,
  reporter_id UUID REFERENCES users(id),
  reporter TEXT,
  reporter_phone TEXT,
  assigned_bdo UUID REFERENCES officers(id),
  assigned_officer UUID REFERENCES officers(id),
  current_level INTEGER DEFAULT 1,
  sla_hours INTEGER DEFAULT 168,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- COMPLAINT PHOTOS
CREATE TABLE complaint_photos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complaint_id TEXT REFERENCES complaints(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  uploaded_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- COMPLAINT VIDEOS
CREATE TABLE complaint_videos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complaint_id TEXT REFERENCES complaints(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  uploaded_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- COMPLAINT COMMENTS
CREATE TABLE complaint_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complaint_id TEXT REFERENCES complaints(id) ON DELETE CASCADE,
  author_id UUID REFERENCES users(id),
  author_name TEXT,
  content TEXT NOT NULL,
  is_official BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- COMPLAINT STATUS HISTORY
CREATE TABLE complaint_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complaint_id TEXT REFERENCES complaints(id) ON DELETE CASCADE,
  from_status TEXT,
  to_status TEXT NOT NULL,
  changed_by UUID REFERENCES users(id),
  changed_by_name TEXT,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- NOTIFICATIONS
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'info',
  title TEXT NOT NULL,
  message TEXT,
  complaint_id TEXT REFERENCES complaints(id),
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SLA RULES
CREATE TABLE sla_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  severity TEXT UNIQUE NOT NULL,
  hours INTEGER NOT NULL,
  label TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ESCALATION RULES
CREATE TABLE escalation_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  level INTEGER NOT NULL,
  role_from TEXT,
  role_to TEXT,
  dept TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- REPORTS
CREATE TABLE reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  type TEXT NOT NULL,
  period TEXT,
  generated_by UUID REFERENCES users(id),
  data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AUDIT LOGS
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  action TEXT NOT NULL,
  table_name TEXT,
  record_id TEXT,
  old_data JSONB,
  new_data JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SETTINGS
CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value JSONB,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES ──────────────────────────────────────────────────
CREATE INDEX idx_complaints_taluk ON complaints(taluk);
CREATE INDEX idx_complaints_status ON complaints(status);
CREATE INDEX idx_complaints_severity ON complaints(severity);
CREATE INDEX idx_complaints_overdue ON complaints(overdue);
CREATE INDEX idx_complaints_created ON complaints(created_at DESC);
CREATE INDEX idx_notifications_user ON notifications(user_id, read);
CREATE INDEX idx_villages_taluk ON villages(taluk);
CREATE INDEX idx_schools_taluk ON schools(taluk);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Citizens can only see their own complaints
CREATE POLICY "Citizens view own complaints" ON complaints
  FOR SELECT USING (
    reporter_id = auth.uid() OR
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role IN ('admin','super_admin','collector','dro','bdo','ceo','deo','beo','twad','health','fire','electricity','municipal'))
  );

-- Only authenticated users can insert complaints
CREATE POLICY "Auth users insert complaints" ON complaints
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Officers/admins can update complaints
CREATE POLICY "Officers update complaints" ON complaints
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role NOT IN ('citizen','student','parent'))
  );

-- Users view own notifications
CREATE POLICY "View own notifications" ON notifications
  FOR ALL USING (user_id = auth.uid());

-- ── DEFAULT DATA ──────────────────────────────────────────────
INSERT INTO sla_rules (severity, hours, label) VALUES
  ('emergency', 1,   '1 hour'),
  ('critical',  24,  '24 hours'),
  ('high',      72,  '72 hours'),
  ('medium',    168, '7 days'),
  ('low',       720, '30 days');

INSERT INTO settings (key, value) VALUES
  ('app_name',       '"Krishnagiri Connect"'),
  ('district',       '"Krishnagiri, Tamil Nadu"'),
  ('collector',      '"Tmt. K. M. Sarayu, I.A.S."'),
  ('default_lang',   '"en"'),
  ('sms_enabled',    'true'),
  ('email_enabled',  'true'),
  ('push_enabled',   'true');
