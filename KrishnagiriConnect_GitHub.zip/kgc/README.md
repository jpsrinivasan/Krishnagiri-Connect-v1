# Krishnagiri Connect — Complete Production Platform

**Digital District Management & Public Grievance System**  
Government of Tamil Nadu · Krishnagiri District

---

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

Open http://localhost:5173

---

## 🔐 Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| **Admin** | admin@krishnagiriconnect.in | Admin@12345 |
| **Super Admin** | superadmin@krishnagiriconnect.in | Super@12345 |
| **District Collector** | collector@krishnagiriconnect.in | Collect@123 |
| **BDO** | bdo.hosur@krishnagiriconnect.in | Bdo@12345 |
| **TWAD Officer** | twad@krishnagiriconnect.in | Twad@1234 |
| **Citizen** | rajesh@gmail.com | Citizen@123 |

Quick demo buttons are available on the login screen.

---

## 📱 Application Routes

### Public
- `/` — Splash screen
- `/language` — Language selection (EN/தமிழ்)
- `/login` — Login
- `/signup` — Citizen registration

### Admin Panel (`/admin/*`)
- `/admin` — Admin Dashboard (KPIs, charts, recent activity)
- `/admin/collector` — District Collector Dashboard
- `/admin/map` — GIS Interactive Map
- `/admin/complaints` — Complaint Management (200 records, filters)
- `/admin/escalation` — Escalation Centre (SLA breach alerts)
- `/admin/schools` — School Module (50 schools, grid/table, infra scores)
- `/admin/villages` — Village Module (50 villages, VDS scores)
- `/admin/water` — Water Infrastructure (25 assets)
- `/admin/users` — User Management (CRUD, roles, activate/deactivate)
- `/admin/officers` — Officer Directory (20 officials)
- `/admin/reports` — Reports & Analytics (charts, export)
- `/admin/notifications` — Notification Centre
- `/admin/settings` — System Settings & SLA Config

### Officer Dashboard (`/officer/*`)
- `/officer` — Officer Dashboard (assigned complaints, SLA countdown)
- `/officer/complaints` — My Complaint Queue
- `/officer/map` — District Map
- `/officer/profile` — Profile + Logout

### Citizen Mobile (`/citizen/*`)
- `/citizen` — Home (quick actions, village score, emergency numbers)
- `/citizen/report` — 5-step complaint submission form
- `/citizen/tickets` — My Tickets (filter by status)
- `/citizen/ticket/:id` — Ticket Detail + Timeline
- `/citizen/map` — District Map
- `/citizen/profile` — Profile + Language toggle + Logout
- `/citizen/notifications` — Notification Centre

---

## 🏗️ Project Structure

```
src/
├── data/
│   └── seed.js              # All seed data (50 villages, 50 schools, 25 water, 200 complaints)
├── store/
│   └── index.js             # Zustand stores (auth + app state)
├── utils/
│   └── index.js             # Utilities (routing, SLA calc, formatters)
├── components/
│   ├── ui/index.jsx          # Button, Card, Modal, Table, Badge, KPICard, etc.
│   └── layout/index.jsx      # AdminLayout, OfficerLayout, CitizenLayout
├── pages/
│   ├── auth/index.jsx        # LoginPage, SignupPage
│   ├── mobile/index.jsx      # SplashScreen, LanguageSelect
│   ├── admin/index.jsx       # All admin pages
│   ├── map/index.jsx         # GIS Map (Leaflet)
│   ├── officer/index.jsx     # Officer pages
│   └── citizen/index.jsx     # Citizen mobile pages
└── App.jsx                   # Router + auth guards
```

---

## 📊 Seed Data

| Resource | Count |
|----------|-------|
| Villages | 50 (all 12 Krishnagiri taluks) |
| Schools | 50 (with EMIS numbers, infra scores) |
| Water Assets | 25 (dams, borewells, WTPs, OHTs) |
| Officers | 20 (real designations, phones, emails) |
| Users | 10 demo users across all roles |
| Complaints | 200 (realistic categories, auto-routed) |
| Departments | 10 (TWAD, Education, Health, PWD, etc.) |

---

## 🗄️ Database Schema (Zustand / localStorage)

Tables: `users`, `complaints`, `villages`, `schools`, `water_assets`,
`officers`, `notifications`, `departments`, `roles`

For production, replace with Supabase or Firebase:

```js
// supabase.js
import { createClient } from '@supabase/supabase-js'
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
```

---

## 🔀 Complaint Auto-Routing

```
Water issues      → TWAD Board → BDO → TWAD Officer → DRDA → Collector
School issues     → Headmaster → BEO → DEO → CEO → Collector
Road issues       → Panchayat → BDO → PWD → DRO → Collector
Electricity       → Panchayat/Municipality → TANGEDCO → DRO
Health issues     → Public Health Officer → DHO → Collector
Fire/Emergency    → Fire & Rescue → DRO → Collector (immediate)
```

---

## 📋 Complaint Workflow

```
Submitted → Verified → Assigned → Accepted → In Progress → 
Work Done → Verification Pending → Resolved
                                          ↓ (if SLA breach)
                                      Overdue → Escalated
```

### SLA Rules
- Emergency: 1 hour
- Critical: 24 hours
- High: 72 hours
- Medium: 7 days
- Low: 30 days

---

## 🗺️ GIS Map Features
- Leaflet.js with CARTO dark basemap
- 4 layers: Villages, Complaints, Schools, Water Assets
- Color coding: Green (Good), Yellow (Attention), Orange (High), Red (Critical)
- Click any marker for popup details
- Layer switcher chips

---

## 📱 Mobile App Features
- Mobile-first responsive design (max-w-md)
- Bottom navigation (Home, Report, Tickets, Map, Profile)
- 5-step complaint submission with GPS capture
- Tamil + English bilingual labels
- Boarding-pass style ticket confirmation with routing chain animation
- Emergency numbers quick access

---

## 🏛️ Government Structure Implemented
- District Collector: Tmt. K. M. Sarayu, I.A.S. (2015 batch) ✓ (real)
- 20 officers across all departments
- 10 BDOs for all taluks
- TWAD, TANGEDCO, PWD, Health, Fire & Rescue mapped
- Official phone/email from krishnagiri.nic.in format

---

## 🚀 Deployment

### GitHub Pages
```bash
npm install gh-pages -D
# Add to package.json: "deploy": "gh-pages -d dist"
npm run build && npm run deploy
```

### Netlify
```bash
npm run build
# Drag /dist folder to Netlify
# Build command: npm run build
# Publish directory: dist
```

### Vercel
```bash
npx vercel --prod
```

---

## 🔧 Production Backend (Supabase Setup)

1. Create Supabase project at supabase.com
2. Run SQL schema from `supabase_schema.sql`
3. Enable Row Level Security
4. Replace Zustand stores with Supabase client calls
5. Add `.env`: `VITE_SUPABASE_URL=...` and `VITE_SUPABASE_ANON_KEY=...`

---

Built with React + Vite + Zustand + Recharts + Leaflet + Tailwind CSS  
Krishnagiri District · Government of Tamil Nadu
