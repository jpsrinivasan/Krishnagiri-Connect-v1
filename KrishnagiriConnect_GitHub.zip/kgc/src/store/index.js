import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { USERS, COMPLAINTS, VILLAGES, SCHOOLS, WATER_ASSETS, OFFICERS, CAT_CONFIG, SLA_CONFIG } from '../data/seed.js';

// ── AUTH STORE ──────────────────────────────────────────────
export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      loginError: null,

      login: (email, password) => {
        const user = USERS.find(u =>
          u.email.toLowerCase() === email.toLowerCase() && u.password === password
        );
        if (user) {
          set({ user, isAuthenticated: true, loginError: null });
          return { success: true, user };
        }
        set({ loginError: 'Invalid email or password' });
        return { success: false };
      },

      loginWithRole: (role) => {
        const demoUsers = {
          admin: USERS[0],
          collector: USERS[2],
          citizen: USERS[3],
          bdo: USERS[5],
          twad: USERS[6],
        };
        const user = demoUsers[role] || USERS[0];
        set({ user, isAuthenticated: true, loginError: null });
        return { success: true, user };
      },

      logout: () => set({ user: null, isAuthenticated: false }),

      updateUser: (updates) => set(s => ({ user: { ...s.user, ...updates } })),

      clearError: () => set({ loginError: null }),
    }),
    { name: 'kgc-auth' }
  )
);

// ── APP STORE ──────────────────────────────────────────────
export const useAppStore = create(
  persist(
    (set, get) => ({
      // State
      complaints: COMPLAINTS,
      villages: VILLAGES,
      schools: SCHOOLS,
      waterAssets: WATER_ASSETS,
      officers: OFFICERS,
      users: USERS,
      notifications: [],
      language: 'en',
      mapLayer: 'villages',

      // Complaint actions
      addComplaint: (complaint) => {
        const newComp = {
          ...complaint,
          id: `KGC-2025-${String(10200 + get().complaints.length + 1).padStart(5,'0')}`,
          status: 'submitted',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          photos: complaint.photos || 0,
          comments: 0,
          overdue: false,
          days_ago: 0,
          age_hours: 0,
        };
        set(s => ({
          complaints: [newComp, ...s.complaints],
          notifications: [
            {
              id: `N${Date.now()}`,
              type: 'new_complaint',
              title: 'New Complaint Submitted',
              message: `${newComp.category_label} in ${newComp.village} — Ticket: ${newComp.id}`,
              read: false,
              created_at: new Date().toISOString(),
            },
            ...s.notifications,
          ],
        }));
        return newComp;
      },

      updateComplaint: (id, updates) => set(s => ({
        complaints: s.complaints.map(c =>
          c.id === id ? { ...c, ...updates, updated_at: new Date().toISOString() } : c
        ),
      })),

      resolveComplaint: (id) => set(s => ({
        complaints: s.complaints.map(c =>
          c.id === id ? { ...c, status: 'resolved', overdue: false, updated_at: new Date().toISOString() } : c
        ),
      })),

      escalateComplaint: (id) => set(s => ({
        complaints: s.complaints.map(c =>
          c.id === id
            ? { ...c, status: 'escalated', current_level: Math.min((c.current_level||1)+1, 5), updated_at: new Date().toISOString() }
            : c
        ),
        notifications: [
          {
            id: `N${Date.now()}`,
            type: 'escalation',
            title: 'Complaint Escalated',
            message: `Complaint ${id} has been escalated to higher authority`,
            read: false,
            created_at: new Date().toISOString(),
          },
          ...s.notifications,
        ],
      })),

      // User actions
      addUser: (user) => set(s => ({ users: [...s.users, { ...user, id: `U${String(s.users.length+1).padStart(3,'0')}` }] })),
      updateUser: (id, updates) => set(s => ({ users: s.users.map(u => u.id===id ? {...u,...updates} : u) })),
      deleteUser: (id) => set(s => ({ users: s.users.filter(u => u.id !== id) })),
      toggleUserStatus: (id) => set(s => ({
        users: s.users.map(u => u.id===id ? {...u, status: u.status==='active'?'inactive':'active'} : u)
      })),

      // School actions
      addSchool: (school) => set(s => ({ schools: [...s.schools, school] })),
      updateSchool: (id, updates) => set(s => ({ schools: s.schools.map(sch => sch.id===id ? {...sch,...updates} : sch) })),
      deleteSchool: (id) => set(s => ({ schools: s.schools.filter(sch => sch.id !== id) })),

      // Village actions
      updateVillage: (id, updates) => set(s => ({ villages: s.villages.map(v => v.id===id ? {...v,...updates} : v) })),

      // Water asset actions
      updateWaterAsset: (id, updates) => set(s => ({ waterAssets: s.waterAssets.map(a => a.id===id ? {...a,...updates} : a) })),

      // Notifications
      markNotificationRead: (id) => set(s => ({
        notifications: s.notifications.map(n => n.id===id ? {...n, read:true} : n)
      })),
      markAllRead: () => set(s => ({ notifications: s.notifications.map(n => ({...n, read:true})) })),
      clearNotifications: () => set({ notifications: [] }),

      // UI
      setLanguage: (lang) => set({ language: lang }),
      setMapLayer: (layer) => set({ mapLayer: layer }),

      // Getters
      getComplaintsByUser: (userId) => get().complaints.filter(c => c.reporter_id === userId),
      getComplaintsByStatus: (status) => get().complaints.filter(c => c.status === status),
      getComplaintsByTaluk: (taluk) => get().complaints.filter(c => c.taluk === taluk),
      getOverdueComplaints: () => get().complaints.filter(c => c.overdue),
      getCriticalComplaints: () => get().complaints.filter(c => ['critical','emergency'].includes(c.severity)),
      getUnreadNotifications: () => get().notifications.filter(n => !n.read),
    }),
    {
      name: 'kgc-app',
      partialize: (state) => ({
        complaints: state.complaints,
        users: state.users,
        notifications: state.notifications,
        language: state.language,
      }),
    }
  )
);
