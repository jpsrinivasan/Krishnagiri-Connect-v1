// ════════════════════════════════════════════════════════════
// KRISHNAGIRI CONNECT — Complete Seed Data
// ════════════════════════════════════════════════════════════

export const TALUKS = [
  'Krishnagiri','Hosur','Bargur','Uthangarai','Denkanikottai',
  'Shoolagiri','Kelamangalam','Thalli','Veppanapalli','Kaveripattinam',
  'Mathur','Pochampalli',
];

export const DEPARTMENTS = [
  { id:'dept_water',  name:'TWAD Water Supply',          icon:'💧', color:'#0891B2' },
  { id:'dept_edu',    name:'Education Department',        icon:'🏫', color:'#7C3AED' },
  { id:'dept_health', name:'Health Department',           icon:'🏥', color:'#DC2626' },
  { id:'dept_pwd',    name:'Public Works Department',     icon:'🛣️', color:'#92400E' },
  { id:'dept_elec',   name:'Electricity Board (TANGEDCO)',icon:'⚡', color:'#B45309' },
  { id:'dept_fire',   name:'Fire & Rescue Services',      icon:'🔥', color:'#EF4444' },
  { id:'dept_rev',    name:'Revenue Department',          icon:'📜', color:'#374151' },
  { id:'dept_phed',   name:'Public Health Engineering',   icon:'🚰', color:'#0284C7' },
  { id:'dept_muni',   name:'Municipal Administration',    icon:'🏙️', color:'#6D28D9' },
  { id:'dept_drda',   name:'DRDA',                        icon:'🏗️', color:'#065F46' },
];

export const ROLES = [
  { id:'super_admin',   label:'Super Admin',           level:0, color:'#1D4ED8' },
  { id:'admin',         label:'Admin',                 level:1, color:'#2563EB' },
  { id:'collector',     label:'District Collector',    level:2, color:'#D97706' },
  { id:'dro',           label:'District Revenue Officer', level:3, color:'#7C3AED' },
  { id:'drda_po',       label:'Project Officer DRDA',  level:3, color:'#065F46' },
  { id:'ceo',           label:'Chief Education Officer', level:3, color:'#0891B2' },
  { id:'deo',           label:'District Education Officer', level:4, color:'#6D28D9' },
  { id:'beo',           label:'Block Education Officer', level:5, color:'#7C3AED' },
  { id:'bdo',           label:'Block Development Officer', level:5, color:'#059669' },
  { id:'panchayat',     label:'Panchayat Officer',     level:6, color:'#16A34A' },
  { id:'twad',          label:'TWAD / Water Officer',  level:4, color:'#0891B2' },
  { id:'municipal',     label:'Municipal Officer',     level:5, color:'#6D28D9' },
  { id:'health',        label:'Public Health Officer', level:4, color:'#DC2626' },
  { id:'electricity',   label:'Electricity Officer',   level:5, color:'#B45309' },
  { id:'fire',          label:'Fire & Rescue Officer', level:4, color:'#EF4444' },
  { id:'headmaster',    label:'Headmaster',            level:6, color:'#7C3AED' },
  { id:'teacher',       label:'Teacher',               level:7, color:'#9333EA' },
  { id:'student',       label:'Student',               level:8, color:'#6366F1' },
  { id:'parent',        label:'Parent',                level:8, color:'#2563EB' },
  { id:'citizen',       label:'Citizen',               level:8, color:'#374151' },
];

export const CAT_CONFIG = {
  no_water:      { label:'No Drinking Water',    dept:'dept_water',  icon:'💧', tamil:'குடிநீர் இல்லை' },
  dirty_water:   { label:'Dirty Water',          dept:'dept_water',  icon:'🤢', tamil:'அசுத்த நீர்' },
  low_pressure:  { label:'Low Water Pressure',   dept:'dept_water',  icon:'📉', tamil:'குறைந்த நீர் அழுத்தம்' },
  pipeline_leak: { label:'Pipeline Leak',         dept:'dept_water',  icon:'🔧', tamil:'குழாய் கசிவு' },
  borewell:      { label:'Borewell Failure',      dept:'dept_water',  icon:'🔩', tamil:'ஆழ்குழாய் கோளாறு' },
  tank_overflow: { label:'Tank Overflow',         dept:'dept_water',  icon:'🌊', tamil:'தொட்டி நிரம்பி வழிகிறது' },
  school_damage: { label:'School Building Damage',dept:'dept_edu',   icon:'🏫', tamil:'பள்ளி கட்டிட சேதம்' },
  classroom:     { label:'Classroom Damage',      dept:'dept_edu',   icon:'🪑', tamil:'வகுப்பறை சேதம்' },
  toilet:        { label:'Toilet Problem',        dept:'dept_phed',  icon:'🚽', tamil:'கழிவறை பிரச்சனை' },
  girls_toilet:  { label:"Girls Toilet Problem",  dept:'dept_phed',  icon:'🚺', tamil:'பெண்கள் கழிவறை' },
  no_electricity:{ label:'No Electricity',        dept:'dept_elec',  icon:'⚡', tamil:'மின்சாரம் இல்லை' },
  streetlight:   { label:'Streetlight Failure',   dept:'dept_elec',  icon:'💡', tamil:'தெரு விளக்கு கோளாறு' },
  road_damage:   { label:'Road Damage',           dept:'dept_pwd',   icon:'🛣️', tamil:'சாலை சேதம்' },
  drainage:      { label:'Drainage Problem',      dept:'dept_muni',  icon:'🚰', tamil:'வடிகால் பிரச்சனை' },
  garbage:       { label:'Garbage Issue',         dept:'dept_muni',  icon:'🗑️', tamil:'குப்பை பிரச்சனை' },
  public_health: { label:'Public Health Issue',   dept:'dept_health', icon:'🏥', tamil:'பொது சுகாதார பிரச்சனை' },
  hospital:      { label:'Hospital / PHC Issue',  dept:'dept_health', icon:'🩺', tamil:'மருத்துவமனை பிரச்சனை' },
  fire_safety:   { label:'Fire Safety Issue',     dept:'dept_fire',  icon:'🔥', tamil:'தீ பாதுகாப்பு' },
  flooding:      { label:'Flooding',              dept:'dept_rev',   icon:'🌧️', tamil:'வெள்ளம்' },
  emergency:     { label:'Emergency Services',    dept:'dept_fire',  icon:'🚨', tamil:'அவசர சேவைகள்' },
  other:         { label:'Other',                 dept:'dept_rev',   icon:'📝', tamil:'மற்றவை' },
};

export const SLA_CONFIG = {
  emergency: { hours:1,    label:'1 hour',    color:'#7C3AED' },
  critical:  { hours:24,   label:'24 hours',  color:'#DC2626' },
  high:      { hours:72,   label:'72 hours',  color:'#EA580C' },
  medium:    { hours:168,  label:'7 days',    color:'#CA8A04' },
  low:       { hours:720,  label:'30 days',   color:'#16A34A' },
};

export const STATUSES = [
  { id:'submitted',    label:'Submitted',           color:'#6B7280' },
  { id:'verified',     label:'Verified',            color:'#2563EB' },
  { id:'assigned',     label:'Assigned',            color:'#7C3AED' },
  { id:'accepted',     label:'Accepted',            color:'#0891B2' },
  { id:'in_progress',  label:'In Progress',         color:'#B45309' },
  { id:'work_done',    label:'Work Completed',      color:'#059669' },
  { id:'pending_verify',label:'Verification Pending',color:'#D97706'},
  { id:'resolved',     label:'Resolved',            color:'#16A34A' },
  { id:'rejected',     label:'Rejected',            color:'#DC2626' },
  { id:'reopened',     label:'Reopened',            color:'#EA580C' },
  { id:'escalated',    label:'Escalated',           color:'#7C3AED' },
  { id:'overdue',      label:'Overdue',             color:'#991B1B' },
];

// ── OFFICERS (20) ──────────────────────────────────────────
export const OFFICERS = [
  { id:'O01', name:'Tmt. K. M. Sarayu, I.A.S.', role:'collector', dept:'District Administration', phone:'04343-230001', email:'collector.kgi@nic.in', taluk:'All', designation:'District Collector & Magistrate' },
  { id:'O02', name:'Thiru. R. Senthilkumar',   role:'dro',       dept:'Revenue Department',     phone:'04343-230010', email:'dro.kgi@nic.in',       taluk:'All', designation:'District Revenue Officer' },
  { id:'O03', name:'Thiru. P. Anbazhagan',      role:'drda_po',   dept:'DRDA',                   phone:'04343-230015', email:'drda.kgi@nic.in',      taluk:'All', designation:'Project Officer, DRDA' },
  { id:'O04', name:'Tmt. S. Karpagavalli',      role:'ceo',       dept:'Education Department',   phone:'04343-230020', email:'ceo.kgi@nic.in',       taluk:'All', designation:'Chief Education Officer' },
  { id:'O05', name:'Thiru. M. Karthikeyan',     role:'deo',       dept:'Education Department',   phone:'04344-221100', email:'deo.hosur@nic.in',     taluk:'Hosur', designation:'District Education Officer' },
  { id:'O06', name:'Thiru. S. Rajendran',       role:'twad',      dept:'TWAD Water Supply',      phone:'04343-230030', email:'twad.kgi@tnwater.gov.in', taluk:'All', designation:'Executive Engineer, TWAD' },
  { id:'O07', name:'Thiru. V. Subramaniam',     role:'electricity',dept:'Electricity Board',    phone:'04343-230040', email:'se.kgi@tangedco.gov.in', taluk:'All', designation:'Superintending Engineer, TANGEDCO' },
  { id:'O08', name:'Thiru. A. Muthukrishnan',   role:'bdo',       dept:'Block Development',      phone:'04344-221200', email:'bdo.hosur@nic.in',     taluk:'Hosur', designation:'Block Development Officer, Hosur' },
  { id:'O09', name:'Thiru. N. Murugesan',       role:'bdo',       dept:'Block Development',      phone:'04343-221200', email:'bdo.kgi@nic.in',       taluk:'Krishnagiri', designation:'BDO, Krishnagiri' },
  { id:'O10', name:'Tmt. P. Revathi',           role:'bdo',       dept:'Block Development',      phone:'04348-221200', email:'bdo.bargur@nic.in',    taluk:'Bargur', designation:'BDO, Bargur' },
  { id:'O11', name:'Thiru. D. Ramachandran',    role:'fire',      dept:'Fire & Rescue',          phone:'04343-230060', email:'dfo.kgi@tnfrs.gov.in', taluk:'All', designation:'District Fire Officer' },
  { id:'O12', name:'Dr. P. Vijayalakshmi',      role:'health',    dept:'Health Department',      phone:'04343-230050', email:'dho.kgi@nic.in',       taluk:'All', designation:'District Health Officer' },
  { id:'O13', name:'Thiru. K. Balamurugan',     role:'bdo',       dept:'Block Development',      phone:'04340-221200', email:'bdo.uthangarai@nic.in', taluk:'Uthangarai', designation:'BDO, Uthangarai' },
  { id:'O14', name:'Tmt. S. Selvi',             role:'bdo',       dept:'Block Development',      phone:'04344-231200', email:'bdo.shoolagiri@nic.in', taluk:'Shoolagiri', designation:'BDO, Shoolagiri' },
  { id:'O15', name:'Thiru. R. Palani',          role:'beo',       dept:'Education Department',   phone:'04344-221150', email:'beo.hosur@nic.in',     taluk:'Hosur', designation:'Block Education Officer, Hosur' },
  { id:'O16', name:'Tmt. K. Anandhi',           role:'municipal', dept:'Municipal Administration', phone:'04344-222233', email:'mun.hosur@tnulb.gov.in', taluk:'Hosur', designation:'Commissioner, Hosur Municipality' },
  { id:'O17', name:'Thiru. S. Prabhu',          role:'municipal', dept:'Municipal Administration', phone:'04343-222233', email:'mun.kgi@tnulb.gov.in',   taluk:'Krishnagiri', designation:'Commissioner, Krishnagiri Municipality' },
  { id:'O18', name:'Tmt. A. Devi',              role:'panchayat', dept:'Panchayat Administration', phone:'04343-250100', email:'panchayat.mathur@tnrd.gov.in', taluk:'Mathur', designation:'Panchayat Union Chairman, Mathur' },
  { id:'O19', name:'Thiru. C. Rajan',           role:'twad',      dept:'TWAD Water Supply',      phone:'04344-230030', email:'twad.hosur@tnwater.gov.in', taluk:'Hosur', designation:'AE, TWAD Hosur' },
  { id:'O20', name:'Tmt. L. Nithya',            role:'bdo',       dept:'Block Development',      phone:'04348-231200', email:'bdo.kaveripattinam@nic.in', taluk:'Kaveripattinam', designation:'BDO, Kaveripattinam' },
];

// ── USERS (sample set) ──────────────────────────────────────
export const USERS = [
  { id:'U001', name:'Admin User',        email:'admin@krishnagiriconnect.in', password:'Admin@12345', role:'admin',    phone:'9000000001', taluk:'All',          status:'active', avatar:'👨‍💼' },
  { id:'U002', name:'Super Admin',       email:'superadmin@krishnagiriconnect.in', password:'Super@12345', role:'super_admin', phone:'9000000000', taluk:'All', status:'active', avatar:'🔐' },
  { id:'U003', name:'Tmt. K. M. Sarayu',email:'collector@krishnagiriconnect.in', password:'Collect@123', role:'collector',  phone:'9444000001', taluk:'All', status:'active', avatar:'⚖️' },
  { id:'U004', name:'Rajesh Kumar',      email:'rajesh@gmail.com',            password:'Citizen@123', role:'citizen',  phone:'9876543210', taluk:'Hosur',        status:'active', avatar:'👨' },
  { id:'U005', name:'Priya Sundaram',    email:'priya@gmail.com',             password:'Citizen@123', role:'teacher',  phone:'9876543211', taluk:'Krishnagiri',  status:'active', avatar:'👩' },
  { id:'U006', name:'BDO Hosur',         email:'bdo.hosur@krishnagiriconnect.in', password:'Bdo@12345', role:'bdo',   phone:'9444000008', taluk:'Hosur',        status:'active', avatar:'📋' },
  { id:'U007', name:'TWAD Officer',      email:'twad@krishnagiriconnect.in',  password:'Twad@1234', role:'twad',     phone:'9444000006', taluk:'All',          status:'active', avatar:'💧' },
  { id:'U008', name:'Meena Devi',        email:'meena@gmail.com',             password:'Citizen@123', role:'parent',  phone:'9876543212', taluk:'Bargur',       status:'active', avatar:'👩' },
  { id:'U009', name:'Suresh Babu',       email:'suresh@gmail.com',            password:'Citizen@123', role:'student', phone:'9876543213', taluk:'Hosur',        status:'active', avatar:'🧑‍🎓' },
  { id:'U010', name:'Dr. Vijaya',        email:'health@krishnagiriconnect.in',password:'Health@123', role:'health',   phone:'9444000012', taluk:'All',          status:'active', avatar:'👩‍⚕️' },
];

// ── VILLAGES (50) ──────────────────────────────────────────
const makeVillage = (id, name, taluk, lat, lng, pop, ws, ss, rs, sns, hs, sfs) => {
  const vds = Math.round(ws*0.25 + ss*0.20 + rs*0.20 + sns*0.15 + hs*0.12 + sfs*0.08);
  const status = vds>=80?'green':vds>=60?'yellow':vds>=40?'orange':'red';
  return { id:`V${String(id).padStart(3,'0')}`, name, taluk, lat, lng, population:pop,
    households:Math.round(pop/4), panchayat:`${name} Gram Panchayat`,
    water_score:ws, school_score:ss, road_score:rs, sanitation_score:sns,
    health_score:hs, safety_score:sfs, vds, status,
    open_complaints:Math.floor(Math.random()*8), resolved_complaints:Math.floor(Math.random()*20)+5,
    last_inspection:new Date(2025,Math.floor(Math.random()*6),Math.floor(Math.random()*28)+1).toISOString().split('T')[0],
    water_source: ['Piped TWAD','Borewell','Open Well','Tanker'][Math.floor(Math.random()*4)],
    schools_count: Math.floor(Math.random()*4)+1,
  };
};

export const VILLAGES = [
  makeVillage(1,'Hosur Town','Hosur',12.7409,77.8253,45000,82,88,75,79,85,90),
  makeVillage(2,'Shoolagiri','Hosur',12.6900,77.9500,8200,68,72,61,65,70,75),
  makeVillage(3,'Berigai','Hosur',12.7100,77.8800,3400,45,52,48,42,55,60),
  makeVillage(4,'Rayakottai','Hosur',12.7600,77.8000,5100,72,68,70,68,72,78),
  makeVillage(5,'Thally','Hosur',12.7800,77.7900,4200,35,42,38,35,45,50),
  makeVillage(6,'Krishnagiri Town','Krishnagiri',12.5266,78.2132,58000,85,90,80,82,88,92),
  makeVillage(7,'Mathur','Krishnagiri',12.5000,78.2500,6800,62,70,58,60,65,72),
  makeVillage(8,'Veppanapalli','Krishnagiri',12.5500,78.1800,7200,55,65,52,55,62,68),
  makeVillage(9,'Naganeri','Krishnagiri',12.5100,78.2700,2800,42,48,40,38,50,55),
  makeVillage(10,'Kavalur','Krishnagiri',12.4900,78.2000,3200,78,75,72,70,76,82),
  makeVillage(11,'Bargur','Bargur',12.4500,78.1000,9500,60,65,58,58,62,70),
  makeVillage(12,'Pochampalli','Bargur',12.4200,78.0500,4100,38,45,35,35,42,48),
  makeVillage(13,'Doddaghatta','Bargur',12.4700,78.1200,2600,70,72,68,65,70,75),
  makeVillage(14,'Seetheri','Bargur',12.4300,78.0800,1900,32,38,30,28,38,42),
  makeVillage(15,'Muttandahalli','Bargur',12.4600,78.1500,2400,55,60,52,50,58,65),
  makeVillage(16,'Uthangarai','Uthangarai',12.3200,78.3200,11000,65,70,62,62,68,75),
  makeVillage(17,'Harur','Uthangarai',12.3500,78.2800,8200,72,75,68,70,74,80),
  makeVillage(18,'Bommidi','Uthangarai',12.2800,78.2500,3800,48,55,44,42,52,58),
  makeVillage(19,'Nathamedu','Uthangarai',12.3000,78.3500,2200,42,48,38,38,46,52),
  makeVillage(20,'Eriyur','Uthangarai',12.2500,78.3000,1800,35,40,32,30,40,45),
  makeVillage(21,'Denkanikottai','Denkanikottai',12.6200,77.9800,12000,78,82,72,75,80,85),
  makeVillage(22,'Pennagaram','Denkanikottai',12.5800,78.0200,6500,65,68,60,62,68,72),
  makeVillage(23,'Anchetti','Denkanikottai',12.5500,78.0000,3200,52,58,48,46,56,62),
  makeVillage(24,'Morappur','Denkanikottai',12.6000,78.0500,4800,68,72,64,65,70,76),
  makeVillage(25,'Thalavadi','Denkanikottai',12.5200,77.9500,2900,45,50,42,40,50,55),
  makeVillage(26,'Shoolagiri Town','Shoolagiri',12.6400,77.9200,7500,70,75,66,68,72,78),
  makeVillage(27,'Solai','Shoolagiri',12.6200,77.9000,2800,58,62,54,52,60,65),
  makeVillage(28,'Berigai West','Shoolagiri',12.6600,77.9400,2100,42,48,38,36,46,52),
  makeVillage(29,'Soolagiri','Shoolagiri',12.6100,77.9600,3500,76,78,72,70,76,82),
  makeVillage(30,'Checkpost','Shoolagiri',12.6300,77.9100,1900,50,55,46,44,54,60),
  makeVillage(31,'Kelamangalam','Kelamangalam',12.6100,77.9500,9800,80,85,76,78,82,88),
  makeVillage(32,'Obeysapuram','Kelamangalam',12.6300,77.9700,2600,62,68,58,60,66,72),
  makeVillage(33,'Chandrapuram','Kelamangalam',12.5900,77.9300,3100,55,60,52,50,58,64),
  makeVillage(34,'Attibele Road','Kelamangalam',12.6500,77.9800,1800,38,44,34,32,42,48),
  makeVillage(35,'Thalli Town','Thalli',12.7600,77.7800,5200,68,72,64,65,70,76),
  makeVillage(36,'Mekalachinnaeri','Thalli',12.7400,77.8000,2400,55,60,50,50,58,64),
  makeVillage(37,'Jawalagiri','Thalli',12.7800,77.7600,1700,42,48,38,36,46,52),
  makeVillage(38,'Veppanapalli Town','Veppanapalli',12.5500,78.1800,8500,72,78,68,70,76,82),
  makeVillage(39,'Kondappanaickenpatti','Veppanapalli',12.5300,78.1600,3200,60,65,56,58,64,70),
  makeVillage(40,'Salivaram','Veppanapalli',12.5700,78.2000,2100,48,54,44,42,52,58),
  makeVillage(41,'Kaveripattinam','Kaveripattinam',12.4200,78.1800,12500,75,80,70,72,78,84),
  makeVillage(42,'Eriyur North','Kaveripattinam',12.4400,78.2000,2800,58,64,54,54,62,68),
  makeVillage(43,'Hogenakkal','Kaveripattinam',12.1300,77.7900,6200,50,55,46,44,54,60),
  makeVillage(44,'Mathur Town','Mathur',12.5000,78.2500,7800,78,82,74,76,80,86),
  makeVillage(45,'Kanjanaickenpatti','Mathur',12.4800,78.2700,2900,62,68,58,60,66,72),
  makeVillage(46,'Pochampalli Town','Pochampalli',12.4000,78.0300,4500,65,70,60,62,68,74),
  makeVillage(47,'Nathamedu South','Pochampalli',12.3800,78.0100,1900,45,50,40,38,48,54),
  makeVillage(48,'Bargur Road','Bargur',12.4400,78.0700,2600,58,62,54,52,60,66),
  makeVillage(49,'Denkanikottai Road','Denkanikottai',12.6000,77.9700,3100,70,74,66,68,72,78),
  makeVillage(50,'Rayakottai South','Hosur',12.7400,77.7900,1800,40,46,36,34,44,50),
];

// ── SCHOOLS (50) ──────────────────────────────────────────
const makeSchool = (id, name, emis, village, taluk, lat, lng, students, teachers, hm, phone) => {
  const infra = {
    drinking_water: Math.random()>0.15, toilets: Math.random()>0.12,
    girls_toilets: Math.random()>0.22, electricity: Math.random()>0.10,
    internet: Math.random()>0.45, library: Math.random()>0.38,
    science_lab: Math.random()>0.55, computer_lab: Math.random()>0.62,
    playground: Math.random()>0.28, cctv: Math.random()>0.68,
    boundary_wall: Math.random()>0.25,
  };
  const WEIGHTS = {drinking_water:15,toilets:10,girls_toilets:12,electricity:8,internet:7,library:8,science_lab:10,computer_lab:10,playground:5,cctv:5,boundary_wall:10};
  const score = Object.entries(infra).reduce((s,[k,v])=>s+(v?WEIGHTS[k]:0),0);
  const status = score>=80?'green':score>=60?'yellow':score>=40?'orange':'red';
  const type = students>400?'Higher Secondary':students>200?'High School':students>80?'Middle School':'Primary School';
  return {
    id:`SCH${String(id).padStart(3,'0')}`, name, emis, village, taluk, lat, lng,
    students, teachers, headmaster:hm, phone, type, infra, score, status,
    open_complaints:Math.floor(Math.random()*5),
    resolved_complaints:Math.floor(Math.random()*15)+2,
    last_inspection:new Date(2025,Math.floor(Math.random()*6),Math.floor(Math.random()*28)+1).toISOString().split('T')[0],
  };
};

export const SCHOOLS = [
  makeSchool(1,'Govt Higher Secondary School Hosur','3310001','Hosur Town','Hosur',12.7409,77.8253,850,38,'Dr. K. Rajan','04344-222100'),
  makeSchool(2,'Panchayat Union Middle School Shoolagiri','3310002','Shoolagiri','Hosur',12.6900,77.9500,280,12,'Tmt. S. Meena','04344-222200'),
  makeSchool(3,'Govt High School Berigai','3310003','Berigai','Hosur',12.7100,77.8800,320,15,'Thiru. P. Kumar','04344-222300'),
  makeSchool(4,'ADW Primary School Rayakottai','3310004','Rayakottai','Hosur',12.7600,77.8000,95,4,'Tmt. R. Valli','04344-222400'),
  makeSchool(5,'Tribal Welfare School Thally','3310005','Thally','Hosur',12.7800,77.7900,145,7,'Thiru. M. Balan','04344-222500'),
  makeSchool(6,'Govt Higher Secondary Krishnagiri','3310006','Krishnagiri Town','Krishnagiri',12.5266,78.2132,920,42,'Dr. S. Anbu','04343-221100'),
  makeSchool(7,'PU Middle School Mathur','3310007','Mathur','Krishnagiri',12.5000,78.2500,185,9,'Tmt. K. Devi','04343-221200'),
  makeSchool(8,'Govt High School Veppanapalli','3310008','Veppanapalli','Krishnagiri',12.5500,78.1800,380,18,'Thiru. R. Raj','04343-221300'),
  makeSchool(9,'ADW Primary School Naganeri','3310009','Naganeri','Krishnagiri',12.5100,78.2700,65,3,'Tmt. V. Selvi','04343-221400'),
  makeSchool(10,'Govt HS Kavalur','3310010','Kavalur','Krishnagiri',12.4900,78.2000,210,10,'Thiru. N. Siva','04343-221500'),
  makeSchool(11,'Govt HSS Bargur','3310011','Bargur','Bargur',12.4500,78.1000,540,25,'Dr. P. Muthu','04348-221100'),
  makeSchool(12,'PU Primary School Pochampalli','3310012','Pochampalli','Bargur',12.4200,78.0500,88,4,'Tmt. A. Lakshmi','04348-221200'),
  makeSchool(13,'Govt Middle School Doddaghatta','3310013','Doddaghatta','Bargur',12.4700,78.1200,155,7,'Thiru. C. Murugan','04348-221300'),
  makeSchool(14,'ADW Primary Seetheri','3310014','Seetheri','Bargur',12.4300,78.0800,55,3,'Tmt. D. Parvathi','04348-221400'),
  makeSchool(15,'Govt HS Uthangarai','3310015','Uthangarai','Uthangarai',12.3200,78.3200,420,20,'Thiru. E. Guna','04340-221100'),
  makeSchool(16,'PU Middle School Harur','3310016','Harur','Uthangarai',12.3500,78.2800,280,13,'Tmt. F. Saroja','04340-221200'),
  makeSchool(17,'Govt Primary School Bommidi','3310017','Bommidi','Uthangarai',12.2800,78.2500,75,4,'Thiru. G. Rajan','04340-221300'),
  makeSchool(18,'Govt HSS Denkanikottai','3310018','Denkanikottai','Denkanikottai',12.6200,77.9800,680,32,'Dr. H. Vijay','04346-221100'),
  makeSchool(19,'PU HS Pennagaram','3310019','Pennagaram','Denkanikottai',12.5800,78.0200,340,16,'Tmt. I. Kavitha','04346-221200'),
  makeSchool(20,'Govt Middle Anchetti','3310020','Anchetti','Denkanikottai',12.5500,78.0000,120,6,'Thiru. J. Babu','04346-221300'),
  makeSchool(21,'Govt HSS Shoolagiri','3310021','Shoolagiri Town','Shoolagiri',12.6400,77.9200,580,27,'Dr. K. Ravi','04344-231100'),
  makeSchool(22,'PU Primary Solai','3310022','Solai','Shoolagiri',12.6200,77.9000,68,3,'Tmt. L. Vani','04344-231200'),
  makeSchool(23,'Govt HS Kelamangalam','3310023','Kelamangalam','Kelamangalam',12.6100,77.9500,450,21,'Thiru. M. Arasu','04344-241100'),
  makeSchool(24,'PU Primary Thalli','3310024','Thalli Town','Thalli',12.7600,77.7800,88,4,'Tmt. N. Prema','04344-251100'),
  makeSchool(25,'Govt HSS Veppanapalli','3310025','Veppanapalli Town','Veppanapalli',12.5500,78.1800,520,24,'Dr. O. Kumar','04343-231100'),
  makeSchool(26,'Govt HS Kaveripattinam','3310026','Kaveripattinam','Kaveripattinam',12.4200,78.1800,390,18,'Thiru. P. Senthil','04348-231100'),
  makeSchool(27,'PU Middle Hogenakkal','3310027','Hogenakkal','Kaveripattinam',12.1300,77.7900,145,7,'Tmt. Q. Selvi','04348-231200'),
  makeSchool(28,'Govt Primary Mathur','3310028','Mathur Town','Mathur',12.5000,78.2500,92,4,'Thiru. R. Balu','04343-241100'),
  makeSchool(29,'Govt HS Pochampalli','3310029','Pochampalli Town','Pochampalli',12.4000,78.0300,310,14,'Tmt. S. Meena','04348-241100'),
  makeSchool(30,'PU Primary Bargur Road','3310030','Bargur Road','Bargur',12.4400,78.0700,78,4,'Thiru. T. Murugan','04348-221500'),
  makeSchool(31,'ADW HS Berigai West','3310031','Berigai West','Shoolagiri',12.6600,77.9400,185,9,'Tmt. U. Kamala','04344-231300'),
  makeSchool(32,'Govt Primary Salivaram','3310032','Salivaram','Veppanapalli',12.5700,78.2000,55,3,'Thiru. V. Arumugam','04343-231200'),
  makeSchool(33,'PU Middle Kondappanaickenpatti','3310033','Kondappanaickenpatti','Veppanapalli',12.5300,78.1600,125,6,'Tmt. W. Selvi','04343-231300'),
  makeSchool(34,'Govt HS Obeysapuram','3310034','Obeysapuram','Kelamangalam',12.6300,77.9700,260,12,'Thiru. X. Raja','04344-241200'),
  makeSchool(35,'Govt Primary Eriyur','3310035','Eriyur','Uthangarai',12.2500,78.3000,48,2,'Tmt. Y. Valli','04340-221400'),
  makeSchool(36,'ADW Middle Nathamedu','3310036','Nathamedu','Uthangarai',12.3000,78.3500,95,5,'Thiru. Z. Kumar','04340-221500'),
  makeSchool(37,'Tribal Welfare HS Harur','3310037','Harur','Uthangarai',12.3500,78.2800,225,11,'Tmt. AA. Mala','04340-221600'),
  makeSchool(38,'Govt Primary Muttandahalli','3310038','Muttandahalli','Bargur',12.4600,78.1500,62,3,'Thiru. BB. Siva','04348-221600'),
  makeSchool(39,'PU HS Chandrapuram','3310039','Chandrapuram','Kelamangalam',12.5900,77.9300,185,9,'Tmt. CC. Rekha','04344-241300'),
  makeSchool(40,'Govt HSS Pennagaram','3310040','Pennagaram','Denkanikottai',12.5800,78.0200,480,22,'Dr. DD. Anand','04346-221400'),
  makeSchool(41,'PU Primary Kavalur','3310041','Kavalur','Krishnagiri',12.4900,78.2000,72,4,'Tmt. EE. Padma','04343-221600'),
  makeSchool(42,'Govt Middle Mekalachinnaeri','3310042','Mekalachinnaeri','Thalli',12.7400,77.8000,115,6,'Thiru. FF. Babu','04344-251200'),
  makeSchool(43,'Govt HS Eriyur North','3310043','Eriyur North','Kaveripattinam',12.4400,78.2000,265,12,'Tmt. GG. Kamali','04348-231300'),
  makeSchool(44,'ADW Primary Naganeri','3310044','Naganeri','Krishnagiri',12.5100,78.2700,48,2,'Thiru. HH. Ravi','04343-221700'),
  makeSchool(45,'PU Middle Kanjanaickenpatti','3310045','Kanjanaickenpatti','Mathur',12.4800,78.2700,105,5,'Tmt. II. Santha','04343-241200'),
  makeSchool(46,'Govt Primary Checkpost','3310046','Checkpost','Shoolagiri',12.6300,77.9100,55,3,'Thiru. JJ. Murugesan','04344-231400'),
  makeSchool(47,'Govt HS Attibele Road','3310047','Attibele Road','Kelamangalam',12.6500,77.9800,195,9,'Tmt. KK. Selvi','04344-241400'),
  makeSchool(48,'PU Primary Jawalagiri','3310048','Jawalagiri','Thalli',12.7800,77.7600,42,2,'Thiru. LL. Balan','04344-251300'),
  makeSchool(49,'Govt Middle Nathamedu South','3310049','Nathamedu South','Pochampalli',12.3800,78.0100,88,4,'Tmt. MM. Revathi','04348-241200'),
  makeSchool(50,'ADW HS Seetheri','3310050','Seetheri','Bargur',12.4300,78.0800,165,8,'Thiru. NN. Palani','04348-221700'),
];

// ── WATER ASSETS (25) ──────────────────────────────────────
export const WATER_ASSETS = [
  { id:'WA001', name:'Krishnagiri Dam', type:'Dam', village:'Krishnagiri Town', taluk:'Krishnagiri', lat:12.5300,lng:78.2000, capacity:'3.85 MCft', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-05-15', complaints:2 },
  { id:'WA002', name:'Hosur Elevated Tank 1', type:'Overhead Tank', village:'Hosur Town', taluk:'Hosur', lat:12.7409,lng:77.8253, capacity:'2,50,000 L', status:'Operational', officer:'O19', dept:'dept_water', last_inspection:'2025-05-20', complaints:1 },
  { id:'WA003', name:'TWAD WTP Krishnagiri', type:'Water Treatment Plant', village:'Krishnagiri Town', taluk:'Krishnagiri', lat:12.5266,lng:78.2132, capacity:'2,000 KLD', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-04-10', complaints:0 },
  { id:'WA004', name:'Borewell Bargur-01', type:'Borewell', village:'Bargur', taluk:'Bargur', lat:12.4500,lng:78.1000, capacity:'N/A', status:'Failed', officer:'O06', dept:'dept_water', last_inspection:'2025-03-15', complaints:5 },
  { id:'WA005', name:'Elevated Tank Uthangarai', type:'Overhead Tank', village:'Uthangarai', taluk:'Uthangarai', lat:12.3200,lng:78.3200, capacity:'1,00,000 L', status:'Low Level', officer:'O13', dept:'dept_water', last_inspection:'2025-05-01', complaints:3 },
  { id:'WA006', name:'Pump Station Hosur', type:'Pump Station', village:'Hosur Town', taluk:'Hosur', lat:12.7350,lng:77.8200, capacity:'500 KLD', status:'Operational', officer:'O19', dept:'dept_water', last_inspection:'2025-05-25', complaints:0 },
  { id:'WA007', name:'Thenpennai River Intake', type:'River Intake', village:'Kaveripattinam', taluk:'Kaveripattinam', lat:12.4200,lng:78.1800, capacity:'N/A', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-04-20', complaints:1 },
  { id:'WA008', name:'Hogenakkal Reservoir', type:'Reservoir', village:'Hogenakkal', taluk:'Kaveripattinam', lat:12.1300,lng:77.7900, capacity:'1.20 MCft', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-03-10', complaints:0 },
  { id:'WA009', name:'Borewell Shoolagiri-01', type:'Borewell', village:'Shoolagiri Town', taluk:'Shoolagiri', lat:12.6400,lng:77.9200, capacity:'N/A', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-05-10', complaints:0 },
  { id:'WA010', name:'OHT Denkanikottai', type:'Overhead Tank', village:'Denkanikottai', taluk:'Denkanikottai', lat:12.6200,lng:77.9800, capacity:'80,000 L', status:'Maintenance', officer:'O06', dept:'dept_water', last_inspection:'2025-04-05', complaints:4 },
  { id:'WA011', name:'WTP Hosur', type:'Water Treatment Plant', village:'Hosur Town', taluk:'Hosur', lat:12.7300,lng:77.8300, capacity:'3,500 KLD', status:'Operational', officer:'O19', dept:'dept_water', last_inspection:'2025-05-30', complaints:0 },
  { id:'WA012', name:'Borewell Uthangarai-01', type:'Borewell', village:'Uthangarai', taluk:'Uthangarai', lat:12.3200,lng:78.3250, capacity:'N/A', status:'Low Yield', officer:'O13', dept:'dept_water', last_inspection:'2025-04-15', complaints:6 },
  { id:'WA013', name:'Public Tap - Mathur', type:'Public Tap', village:'Mathur Town', taluk:'Mathur', lat:12.5000,lng:78.2550, capacity:'N/A', status:'Operational', officer:'O18', dept:'dept_water', last_inspection:'2025-05-05', complaints:1 },
  { id:'WA014', name:'OHT Bargur', type:'Overhead Tank', village:'Bargur', taluk:'Bargur', lat:12.4550,lng:78.1050, capacity:'60,000 L', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-04-25', complaints:2 },
  { id:'WA015', name:'Borewell Kelamangalam-01', type:'Borewell', village:'Kelamangalam', taluk:'Kelamangalam', lat:12.6100,lng:77.9550, capacity:'N/A', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-05-08', complaints:0 },
  { id:'WA016', name:'STP Hosur Industrial', type:'Sewage Treatment Plant', village:'Hosur Town', taluk:'Hosur', lat:12.7450,lng:77.8350, capacity:'5 MLD', status:'Operational', officer:'O16', dept:'dept_phed', last_inspection:'2025-04-30', complaints:1 },
  { id:'WA017', name:'Ground Tank Veppanapalli', type:'Ground Level Tank', village:'Veppanapalli Town', taluk:'Veppanapalli', lat:12.5500,lng:78.1850, capacity:'50,000 L', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-05-12', complaints:0 },
  { id:'WA018', name:'Borewell Pochampalli-01', type:'Borewell', village:'Pochampalli Town', taluk:'Pochampalli', lat:12.4000,lng:78.0350, capacity:'N/A', status:'Failed', officer:'O20', dept:'dept_water', last_inspection:'2025-03-20', complaints:8 },
  { id:'WA019', name:'Pipeline Network Krishnagiri', type:'Pipeline Network', village:'Krishnagiri Town', taluk:'Krishnagiri', lat:12.5250,lng:78.2100, capacity:'250 km', status:'Partial Leak', officer:'O06', dept:'dept_water', last_inspection:'2025-04-18', complaints:12 },
  { id:'WA020', name:'OHT Shoolagiri', type:'Overhead Tank', village:'Shoolagiri Town', taluk:'Shoolagiri', lat:12.6420,lng:77.9220, capacity:'70,000 L', status:'Overflow', officer:'O14', dept:'dept_water', last_inspection:'2025-05-18', complaints:3 },
  { id:'WA021', name:'Borewell Thalli-01', type:'Borewell', village:'Thalli Town', taluk:'Thalli', lat:12.7600,lng:77.7820, capacity:'N/A', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-04-22', complaints:1 },
  { id:'WA022', name:'Pump Station Bargur', type:'Pump Station', village:'Bargur', taluk:'Bargur', lat:12.4480,lng:78.0980, capacity:'200 KLD', status:'Offline', officer:'O10', dept:'dept_water', last_inspection:'2025-03-25', complaints:9 },
  { id:'WA023', name:'Public Tap Hogenakkal', type:'Public Tap', village:'Hogenakkal', taluk:'Kaveripattinam', lat:12.1310,lng:77.7910, capacity:'N/A', status:'Operational', officer:'O20', dept:'dept_water', last_inspection:'2025-05-22', complaints:0 },
  { id:'WA024', name:'Borewell Denkanikottai-01', type:'Borewell', village:'Denkanikottai', taluk:'Denkanikottai', lat:12.6210,lng:77.9810, capacity:'N/A', status:'Operational', officer:'O06', dept:'dept_water', last_inspection:'2025-05-06', complaints:0 },
  { id:'WA025', name:'WTP Uthangarai', type:'Water Treatment Plant', village:'Uthangarai', taluk:'Uthangarai', lat:12.3180,lng:78.3180, capacity:'800 KLD', status:'Operational', officer:'O13', dept:'dept_water', last_inspection:'2025-04-28', complaints:1 },
];

// ── COMPLAINTS (200) ──────────────────────────────────────
const genComplaints = () => {
  const cats = Object.keys(CAT_CONFIG);
  const sevs = ['low','medium','high','critical','emergency'];
  const sevW = [0.20,0.30,0.28,0.17,0.05];
  const statuses = ['submitted','verified','assigned','accepted','in_progress','work_done','resolved','rejected','overdue','escalated'];
  const statW = [0.15,0.10,0.20,0.15,0.18,0.08,0.08,0.02,0.02,0.02];
  const reporters = ['Citizen','Student','Teacher','Parent','Village Leader'];
  const complaints = [];

  for(let i=1;i<=200;i++){
    const village = VILLAGES[Math.floor(Math.random()*VILLAGES.length)];
    const cat = cats[Math.floor(Math.random()*cats.length)];
    const cfg = CAT_CONFIG[cat];
    // Weighted severity
    let sevIdx=0; const r=Math.random(); let cum=0;
    for(let j=0;j<sevW.length;j++){cum+=sevW[j];if(r<cum){sevIdx=j;break;}}
    const sev = sevs[sevIdx];
    // Weighted status
    let stIdx=0; const r2=Math.random(); let cum2=0;
    for(let j=0;j<statW.length;j++){cum2+=statW[j];if(r2<cum2){stIdx=j;break;}}
    const status = statuses[stIdx];
    const daysAgo = Math.floor(Math.random()*45);
    const slaH = SLA_CONFIG[sev]?.hours||168;
    const ageH = daysAgo*24+Math.floor(Math.random()*24);
    const overdue = ageH>slaH && !['resolved','closed'].includes(status);
    const bdo = OFFICERS.find(o=>o.role==='bdo'&&o.taluk===village.taluk)||OFFICERS[8];
    const deptOfficer = OFFICERS.find(o=>{
      if(cfg.dept==='dept_water')return o.role==='twad';
      if(cfg.dept==='dept_edu')return o.role==='deo';
      if(cfg.dept==='dept_health')return o.role==='health';
      if(cfg.dept==='dept_elec')return o.role==='electricity';
      if(cfg.dept==='dept_fire')return o.role==='fire';
      return o.role==='bdo';
    })||OFFICERS[5];
    const created = new Date(Date.now()-daysAgo*86400000);

    complaints.push({
      id:`KGC-2025-${String(10000+i).padStart(5,'0')}`,
      category:cat, category_label:cfg.label, category_icon:cfg.icon,
      dept:cfg.dept, severity:sev, status: overdue?'overdue':status,
      overdue, village:village.name, taluk:village.taluk,
      lat:village.lat+(Math.random()-.5)*0.02, lng:village.lng+(Math.random()-.5)*0.02,
      reporter:reporters[Math.floor(Math.random()*reporters.length)],
      reporter_phone:`9${String(Math.floor(Math.random()*900000000)+100000000)}`,
      description:`${cfg.label} reported in ${village.name}. Affecting approximately ${Math.floor(Math.random()*500)+50} residents.`,
      assigned_bdo:bdo.id, assigned_officer:deptOfficer.id,
      assigned_bdo_name:bdo.name, assigned_officer_name:deptOfficer.name,
      sla_hours:slaH, age_hours:ageH, days_ago:daysAgo,
      created_at:created.toISOString(),
      updated_at:new Date(created.getTime()+Math.random()*3600000*daysAgo).toISOString(),
      photos:Math.floor(Math.random()*3),
      current_level:Math.floor(Math.random()*3)+1,
      comments:Math.floor(Math.random()*5),
    });
  }
  return complaints;
};

export const COMPLAINTS = genComplaints();

export const getStats = () => {
  const cs = COMPLAINTS;
  return {
    total: cs.length,
    open: cs.filter(c=>!['resolved','closed','rejected'].includes(c.status)).length,
    resolved: cs.filter(c=>['resolved'].includes(c.status)).length,
    overdue: cs.filter(c=>c.overdue).length,
    critical: cs.filter(c=>c.severity==='critical'||c.severity==='emergency').length,
    avg_resolution_h: 38.4,
    villages: VILLAGES.length,
    schools: SCHOOLS.length,
    water_assets: WATER_ASSETS.length,
    officers: OFFICERS.length,
    total_population: VILLAGES.reduce((s,v)=>s+v.population,0),
  };
};
