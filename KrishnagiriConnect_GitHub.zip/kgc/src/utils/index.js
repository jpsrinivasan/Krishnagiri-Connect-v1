import { CAT_CONFIG, SLA_CONFIG, OFFICERS } from '../data/seed.js';

export const formatDate = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
};

export const formatDateTime = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
};

export const timeAgo = (iso) => {
  if (!iso) return '—';
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.floor(diff / 3600000);
  if (h < 1) return 'Just now';
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return formatDate(iso);
};

export const getSeverityConfig = (sev) => ({
  emergency: { color:'#7C3AED', bg:'rgba(124,58,237,.15)', label:'Emergency', icon:'🚨' },
  critical:  { color:'#DC2626', bg:'rgba(220,38,38,.15)',  label:'Critical',  icon:'🔴' },
  high:      { color:'#EA580C', bg:'rgba(234,88,12,.15)',  label:'High',      icon:'🟠' },
  medium:    { color:'#CA8A04', bg:'rgba(202,138,4,.15)',  label:'Medium',    icon:'🟡' },
  low:       { color:'#16A34A', bg:'rgba(22,163,74,.15)',  label:'Low',       icon:'🟢' },
}[sev] || { color:'#6B7280', bg:'rgba(107,114,128,.15)', label:sev, icon:'⚪' });

export const getStatusConfig = (status) => ({
  submitted:      { color:'#6B7280', label:'Submitted' },
  verified:       { color:'#2563EB', label:'Verified' },
  assigned:       { color:'#7C3AED', label:'Assigned' },
  accepted:       { color:'#0891B2', label:'Accepted' },
  in_progress:    { color:'#B45309', label:'In Progress' },
  work_done:      { color:'#059669', label:'Work Done' },
  pending_verify: { color:'#D97706', label:'Verification Pending' },
  resolved:       { color:'#16A34A', label:'Resolved' },
  rejected:       { color:'#DC2626', label:'Rejected' },
  reopened:       { color:'#EA580C', label:'Reopened' },
  escalated:      { color:'#7C3AED', label:'Escalated' },
  overdue:        { color:'#991B1B', label:'Overdue' },
}[status] || { color:'#6B7280', label:status });

export const getVDSColor = (score) => {
  if (score >= 80) return '#16A34A';
  if (score >= 60) return '#CA8A04';
  if (score >= 40) return '#EA580C';
  return '#DC2626';
};

export const getVDSLabel = (score) => {
  if (score >= 80) return 'Good';
  if (score >= 60) return 'Needs Attention';
  if (score >= 40) return 'High Priority';
  return 'Critical';
};

export const autoRoute = (category, taluk) => {
  const cfg = CAT_CONFIG[category];
  if (!cfg) return null;
  const bdo = OFFICERS.find(o => o.role === 'bdo' && o.taluk === taluk) || OFFICERS[8];
  let deptOfficer = OFFICERS[5];
  if (cfg.dept === 'dept_water')  deptOfficer = OFFICERS.find(o=>o.role==='twad') || OFFICERS[5];
  if (cfg.dept === 'dept_edu')    deptOfficer = OFFICERS.find(o=>o.role==='ceo')  || OFFICERS[3];
  if (cfg.dept === 'dept_health') deptOfficer = OFFICERS.find(o=>o.role==='health')||OFFICERS[11];
  if (cfg.dept === 'dept_elec')   deptOfficer = OFFICERS.find(o=>o.role==='electricity')||OFFICERS[6];
  if (cfg.dept === 'dept_fire')   deptOfficer = OFFICERS.find(o=>o.role==='fire') || OFFICERS[10];
  if (cfg.dept === 'dept_pwd')    deptOfficer = OFFICERS.find(o=>o.role==='bdo')  || OFFICERS[8];
  const collector = OFFICERS.find(o => o.role === 'collector');
  return {
    dept: cfg.dept,
    dept_label: cfg.label,
    panchayat_level: `${taluk} Gram Panchayat`,
    bdo: bdo,
    dept_officer: deptOfficer,
    drda: OFFICERS.find(o=>o.role==='drda_po'),
    collector,
    chain: [
      { level:1, name:`${taluk} Panchayat Officer`, role:'Panchayat', icon:'🏘️' },
      { level:2, name:bdo.name, role:bdo.designation, icon:'📋' },
      { level:3, name:deptOfficer.name, role:deptOfficer.designation, icon:'🏢' },
      { level:4, name:'Project Officer, DRDA', role:'DRDA Krishnagiri', icon:'🏗️' },
      { level:5, name:'Tmt. K. M. Sarayu, I.A.S.', role:'District Collector', icon:'⚖️' },
    ],
  };
};

export const calculateSLAStatus = (complaint) => {
  const sla = SLA_CONFIG[complaint.severity];
  if (!sla) return { pct: 0, color: '#6B7280', remaining: '—', overdue: false };
  const pct = Math.min(100, Math.round((complaint.age_hours / sla.hours) * 100));
  const remaining = sla.hours - complaint.age_hours;
  const overdue = complaint.age_hours > sla.hours;
  const color = overdue ? '#DC2626' : pct > 80 ? '#EA580C' : pct > 60 ? '#CA8A04' : '#16A34A';
  const remainingLabel = overdue
    ? `${Math.abs(remaining)}h overdue`
    : remaining < 24 ? `${remaining}h left`
    : `${Math.floor(remaining/24)}d left`;
  return { pct, color, remaining: remainingLabel, overdue };
};

export const canAccess = (userRole, feature) => {
  const PERMISSIONS = {
    admin_panel:    ['super_admin','admin'],
    manage_users:   ['super_admin','admin'],
    view_all:       ['super_admin','admin','collector','dro'],
    manage_schools: ['super_admin','admin','ceo','deo','beo'],
    water_module:   ['super_admin','admin','twad'],
    complaint_mgmt: ['super_admin','admin','collector','dro','bdo','beo','ceo','twad','health','fire','electricity','municipal'],
    citizen_report: ['citizen','student','parent','teacher','village_leader','headmaster'],
  };
  return PERMISSIONS[feature]?.includes(userRole) ?? false;
};

export const getRoleDashboard = (role) => {
  const map = {
    super_admin: '/admin',
    admin: '/admin',
    collector: '/admin/collector',
    dro: '/admin',
    drda_po: '/admin',
    ceo: '/admin',
    deo: '/admin',
    beo: '/admin',
    bdo: '/officer',
    panchayat: '/officer',
    twad: '/officer',
    municipal: '/officer',
    health: '/officer',
    electricity: '/officer',
    fire: '/officer',
    headmaster: '/officer',
    teacher: '/citizen',
    student: '/citizen',
    parent: '/citizen',
    citizen: '/citizen',
  };
  return map[role] || '/citizen';
};

export const generateTicketNumber = () => {
  return `KGC-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
};

export const formatPopulation = (n) => {
  if (n >= 100000) return `${(n/100000).toFixed(1)}L`;
  if (n >= 1000) return `${(n/1000).toFixed(1)}K`;
  return String(n);
};
