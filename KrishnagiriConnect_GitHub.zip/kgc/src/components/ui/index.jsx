import React from 'react';
import { X } from 'lucide-react';

// ── BUTTON ──────────────────────────────────────────────────
export const Button = ({ children, variant='primary', size='md', onClick, disabled, className='', type='button', icon }) => {
  const base = 'inline-flex items-center gap-2 font-semibold rounded-lg transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-1 cursor-pointer';
  const sizes = { sm:'px-3 py-1.5 text-xs', md:'px-4 py-2 text-sm', lg:'px-5 py-2.5 text-sm', xl:'px-6 py-3 text-base' };
  const variants = {
    primary:  'bg-amber-500 hover:bg-amber-600 text-slate-900 focus:ring-amber-400',
    secondary:'bg-slate-700 hover:bg-slate-600 text-white focus:ring-slate-400',
    danger:   'bg-red-600 hover:bg-red-700 text-white focus:ring-red-400',
    success:  'bg-green-600 hover:bg-green-700 text-white focus:ring-green-400',
    ghost:    'bg-transparent hover:bg-white/10 text-slate-300 border border-white/10 focus:ring-white/20',
    outline:  'bg-transparent border border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-slate-900 focus:ring-amber-400',
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${sizes[size]} ${variants[variant]} ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
    >
      {icon && <span>{icon}</span>}
      {children}
    </button>
  );
};

// ── BADGE ───────────────────────────────────────────────────
export const Badge = ({ children, color='#6B7280', size='sm' }) => (
  <span
    className={`inline-flex items-center font-semibold rounded-full ${size==='sm'?'px-2 py-0.5 text-xs':'px-3 py-1 text-xs'}`}
    style={{ background:`${color}22`, color, border:`1px solid ${color}44` }}
  >
    {children}
  </span>
);

// ── CARD ────────────────────────────────────────────────────
export const Card = ({ children, className='', onClick, noPad }) => (
  <div
    onClick={onClick}
    className={`bg-slate-800 border border-white/7 rounded-xl ${noPad ? '' : 'p-4'} ${onClick ? 'cursor-pointer hover:bg-slate-750 transition-colors' : ''} ${className}`}
    style={{ borderColor:'rgba(255,255,255,0.07)' }}
  >
    {children}
  </div>
);

// ── KPI CARD ────────────────────────────────────────────────
export const KPICard = ({ label, value, icon, color='#E8931A', sub, trend, onClick }) => (
  <div
    onClick={onClick}
    className={`bg-slate-800 rounded-xl p-4 border-t-2 transition-all ${onClick?'cursor-pointer hover:bg-slate-750':''}`}
    style={{ borderTopColor:color, borderLeft:'1px solid rgba(255,255,255,0.07)', borderRight:'1px solid rgba(255,255,255,0.07)', borderBottom:'1px solid rgba(255,255,255,0.07)' }}
  >
    <div className="flex items-start justify-between">
      <div>
        <div className="text-2xl font-black text-white leading-none">{value}</div>
        <div className="text-xs text-slate-400 uppercase tracking-wide mt-1">{label}</div>
        {sub && <div className="text-xs mt-1" style={{ color }}>{sub}</div>}
      </div>
      <span className="text-2xl">{icon}</span>
    </div>
    {trend !== undefined && (
      <div className={`text-xs mt-2 ${trend>=0?'text-green-400':'text-red-400'}`}>
        {trend>=0?'↑':'↓'} {Math.abs(trend)}% from last month
      </div>
    )}
  </div>
);

// ── MODAL ───────────────────────────────────────────────────
export const Modal = ({ open, onClose, title, children, size='md', footer }) => {
  if (!open) return null;
  const sizes = { sm:'max-w-md', md:'max-w-xl', lg:'max-w-2xl', xl:'max-w-4xl', full:'max-w-6xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background:'rgba(0,0,0,0.6)', backdropFilter:'blur(4px)' }}>
      <div className={`bg-slate-800 rounded-2xl border border-white/10 w-full ${sizes[size]} max-h-[90vh] flex flex-col shadow-2xl`}>
        <div className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <h3 className="text-base font-bold text-white">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/10">
            <X size={18} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">{children}</div>
        {footer && <div className="p-4 border-t border-white/10 flex-shrink-0 flex gap-2 justify-end">{footer}</div>}
      </div>
    </div>
  );
};

// ── INPUT ───────────────────────────────────────────────────
export const Input = ({ label, labelTa, value, onChange, placeholder, type='text', required, disabled, className='', rows, options, error }) => (
  <div className={`flex flex-col gap-1 ${className}`}>
    {label && (
      <div>
        <label className="text-xs font-semibold text-slate-300">{label}{required&&<span className="text-red-400 ml-0.5">*</span>}</label>
        {labelTa && <div className="text-xs text-slate-500" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>{labelTa}</div>}
      </div>
    )}
    {options ? (
      <select
        value={value} onChange={e=>onChange(e.target.value)} disabled={disabled} required={required}
        className="bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors"
      >
        {options.map(o => (
          <option key={o.value??o} value={o.value??o}>{o.label??o}</option>
        ))}
      </select>
    ) : rows ? (
      <textarea
        value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        disabled={disabled} required={required} rows={rows}
        className="bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors resize-none"
      />
    ) : (
      <input
        type={type} value={value} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder} disabled={disabled} required={required}
        className="bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors"
      />
    )}
    {error && <div className="text-xs text-red-400">{error}</div>}
  </div>
);

// ── TABLE ───────────────────────────────────────────────────
export const Table = ({ headers, rows, emptyText='No records found' }) => (
  <div className="overflow-x-auto">
    <table className="w-full text-sm border-collapse">
      <thead>
        <tr className="bg-slate-700/50">
          {headers.map((h, i) => (
            <th key={i} className="px-4 py-3 text-left text-xs font-bold text-slate-400 uppercase tracking-wide whitespace-nowrap border-b border-white/7">
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.length === 0 ? (
          <tr><td colSpan={headers.length} className="px-4 py-8 text-center text-slate-500">{emptyText}</td></tr>
        ) : (
          rows.map((row, i) => (
            <tr key={i} className="border-b border-white/5 hover:bg-white/3 transition-colors" style={{ borderBottomColor:'rgba(255,255,255,0.05)' }}>
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-3 text-slate-300 whitespace-nowrap">{cell}</td>
              ))}
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// ── PROGRESS BAR ────────────────────────────────────────────
export const ProgressBar = ({ value, max=100, color='#E8931A', showLabel=true, height=6 }) => {
  const pct = Math.min(100, Math.round((value/max)*100));
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 rounded-full overflow-hidden" style={{ height, background:'rgba(255,255,255,0.08)' }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width:`${pct}%`, background:color }} />
      </div>
      {showLabel && <span className="text-xs font-semibold w-8 text-right" style={{ color }}>{pct}%</span>}
    </div>
  );
};

// ── SCORE RING (SVG) ────────────────────────────────────────
export const ScoreRing = ({ score, size=52, strokeWidth=5 }) => {
  const color = score>=80?'#16A34A':score>=60?'#CA8A04':score>=40?'#EA580C':'#DC2626';
  const r = (size/2) - strokeWidth/2;
  const circ = 2 * Math.PI * r;
  const dash = (score/100) * circ;
  return (
    <div className="relative" style={{ width:size, height:size }}>
      <svg width={size} height={size} style={{ transform:'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth={strokeWidth} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeDasharray={`${dash.toFixed(1)} ${(circ-dash).toFixed(1)}`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center font-black text-sm" style={{ color }}>
        {score}
      </div>
    </div>
  );
};

// ── STAT PILL ───────────────────────────────────────────────
export const StatPill = ({ label, value, color='#E8931A' }) => (
  <div className="flex items-center gap-2 bg-slate-700 rounded-lg px-3 py-2">
    <div className="text-lg font-black" style={{ color }}>{value}</div>
    <div className="text-xs text-slate-400">{label}</div>
  </div>
);

// ── LOADING SPINNER ──────────────────────────────────────────
export const Spinner = ({ size=20 }) => (
  <div className="flex items-center justify-center">
    <div className="rounded-full border-2 border-white/20 border-t-amber-500 animate-spin" style={{ width:size, height:size }} />
  </div>
);

// ── EMPTY STATE ──────────────────────────────────────────────
export const EmptyState = ({ icon='📭', title='No data found', description='', action }) => (
  <div className="flex flex-col items-center justify-center py-16 gap-3">
    <div className="text-5xl">{icon}</div>
    <div className="text-base font-bold text-white">{title}</div>
    {description && <div className="text-sm text-slate-400 text-center max-w-sm">{description}</div>}
    {action}
  </div>
);

// ── SECTION HEADER ──────────────────────────────────────────
export const SectionHeader = ({ title, sub, actions }) => (
  <div className="flex items-center justify-between mb-4">
    <div>
      <h2 className="text-sm font-bold text-white uppercase tracking-wide">{title}</h2>
      {sub && <div className="text-xs text-slate-400 mt-0.5">{sub}</div>}
    </div>
    {actions && <div className="flex gap-2">{actions}</div>}
  </div>
);
