import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Map, FileText, AlertTriangle, Building2,
  Droplets, Users, BarChart3, Settings, LogOut, Bell,
  Home, Plus, List, User, ChevronRight, Menu, X, Shield,
  School, Phone, BookOpen
} from 'lucide-react';
import { useAuthStore, useAppStore } from '../../store/index.js';

// ── ADMIN SIDEBAR ────────────────────────────────────────────
const ADMIN_NAV = [
  { section:'Main', items:[
    { path:'/admin', icon:LayoutDashboard, label:'Dashboard', exact:true },
    { path:'/admin/collector', icon:Shield, label:'Collector View' },
    { path:'/admin/map', icon:Map, label:'GIS District Map' },
  ]},
  { section:'Operations', items:[
    { path:'/admin/complaints', icon:FileText, label:'Complaints', badge:'open' },
    { path:'/admin/escalation', icon:AlertTriangle, label:'Escalation Centre', badge:'overdue' },
    { path:'/admin/notifications', icon:Bell, label:'Notifications', badge:'unread' },
  ]},
  { section:'Modules', items:[
    { path:'/admin/schools', icon:School, label:'School Module' },
    { path:'/admin/villages', icon:Building2, label:'Village Module' },
    { path:'/admin/water', icon:Droplets, label:'Water Module' },
  ]},
  { section:'Admin', items:[
    { path:'/admin/users', icon:Users, label:'Users' },
    { path:'/admin/officers', icon:Phone, label:'Officers' },
    { path:'/admin/reports', icon:BarChart3, label:'Reports & Analytics' },
    { path:'/admin/settings', icon:Settings, label:'Settings' },
  ]},
];

const OFFICER_NAV = [
  { path:'/officer', icon:LayoutDashboard, label:'Dashboard', exact:true },
  { path:'/officer/complaints', icon:FileText, label:'My Complaints' },
  { path:'/officer/map', icon:Map, label:'District Map' },
  { path:'/officer/profile', icon:User, label:'Profile' },
];

export function AdminLayout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { complaints, getUnreadNotifications } = useAppStore();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const openCount = complaints.filter(c => !['resolved','closed','rejected'].includes(c.status)).length;
  const overdueCount = complaints.filter(c => c.overdue).length;
  const unreadCount = getUnreadNotifications().length;

  const getBadge = (key) => {
    if (key === 'open') return openCount;
    if (key === 'overdue') return overdueCount;
    if (key === 'unread') return unreadCount;
    return 0;
  };

  const isActive = (path, exact) => exact ? location.pathname === path : location.pathname.startsWith(path);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Brand */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-xl flex-shrink-0" style={{ background:'radial-gradient(circle at 40% 40%,#F59E0B,#D97706)' }}>🏛️</div>
          {!collapsed && (
            <div>
              <div className="text-sm font-black text-white">Krishnagiri</div>
              <div className="text-xs" style={{ color:'#E8931A' }}>Connect</div>
            </div>
          )}
        </div>
      </div>

      {/* User info */}
      {!collapsed && user && (
        <div className="px-3 py-2.5 mx-2 mt-2 rounded-xl" style={{ background:'rgba(232,147,26,.1)', border:'1px solid rgba(232,147,26,.2)' }}>
          <div className="text-sm font-bold text-white truncate">{user.name}</div>
          <div className="text-xs text-amber-400 capitalize">{user.role?.replace('_',' ')}</div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-2 px-2">
        {ADMIN_NAV.map(section => (
          <div key={section.section} className="mb-2">
            {!collapsed && (
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 py-1 mt-2 mb-1">
                {section.section}
              </div>
            )}
            {section.items.map(item => {
              const active = isActive(item.path, item.exact);
              const badge = item.badge ? getBadge(item.badge) : 0;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg mb-0.5 text-sm font-medium transition-all ${
                    active
                      ? 'bg-amber-500 text-slate-900'
                      : 'text-slate-400 hover:text-white hover:bg-white/7'
                  }`}
                >
                  <item.icon size={15} className="flex-shrink-0" />
                  {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
                  {!collapsed && badge > 0 && (
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${active ? 'bg-slate-900 text-amber-500' : 'bg-red-500 text-white'}`}>
                      {badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Logout */}
      <div className="p-2 border-t border-white/10">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-all"
        >
          <LogOut size={15} />
          {!collapsed && 'Logout'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-900 text-white overflow-hidden">
      {/* Desktop Sidebar */}
      <div className={`hidden lg:flex flex-col border-r border-white/10 bg-slate-800 transition-all duration-300 ${collapsed ? 'w-14' : 'w-52'}`}>
        <div className="flex items-center justify-end p-2 border-b border-white/10">
          <button onClick={() => setCollapsed(!collapsed)} className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10">
            <Menu size={16} />
          </button>
        </div>
        <SidebarContent />
      </div>

      {/* Mobile Sidebar Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div className="w-64 bg-slate-800 border-r border-white/10 flex flex-col">
            <SidebarContent />
          </div>
          <div className="flex-1 bg-black/50" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-12 flex items-center justify-between px-4 border-b border-white/10 bg-slate-800 flex-shrink-0">
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-slate-400 hover:text-white" onClick={() => setMobileOpen(true)}>
              <Menu size={18} />
            </button>
            <div className="text-xs text-slate-400 hidden sm:block">
              Krishnagiri District Administration · Govt. of Tamil Nadu
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-green-400">Live</span>
            </div>
            <Link to="/admin/notifications" className="relative p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10">
              <Bell size={16} />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                  {Math.min(9, unreadCount)}
                </span>
              )}
            </Link>
            <button onClick={handleLogout} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-all">
              <LogOut size={13} /> Logout
            </button>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto bg-slate-900">
          {children}
        </main>
      </div>
    </div>
  );
}

// ── OFFICER LAYOUT ──────────────────────────────────────────
export function OfficerLayout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const isActive = (path, exact) => exact ? location.pathname === path : location.pathname.startsWith(path);
  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div className="flex h-screen bg-slate-900 text-white overflow-hidden">
      <div className="w-52 flex flex-col border-r border-white/10 bg-slate-800">
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-xl" style={{ background:'radial-gradient(circle at 40% 40%,#F59E0B,#D97706)' }}>🏛️</div>
            <div>
              <div className="text-sm font-black text-white">Krishnagiri</div>
              <div className="text-xs" style={{ color:'#E8931A' }}>Connect</div>
            </div>
          </div>
        </div>
        {user && (
          <div className="px-3 py-2.5 mx-2 mt-2 rounded-xl" style={{ background:'rgba(232,147,26,.1)', border:'1px solid rgba(232,147,26,.2)' }}>
            <div className="text-sm font-bold text-white">{user.avatar} {user.name}</div>
            <div className="text-xs text-amber-400 capitalize">{user.role?.replace('_',' ')}</div>
          </div>
        )}
        <nav className="flex-1 py-2 px-2">
          {OFFICER_NAV.map(item => {
            const active = isActive(item.path, item.exact);
            return (
              <Link key={item.path} to={item.path} className={`flex items-center gap-2.5 px-2.5 py-2 rounded-lg mb-0.5 text-sm font-medium transition-all ${active ? 'bg-amber-500 text-slate-900' : 'text-slate-400 hover:text-white hover:bg-white/7'}`}>
                <item.icon size={15} />{item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-2 border-t border-white/10">
          <button onClick={handleLogout} className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-all">
            <LogOut size={15} /> Logout
          </button>
        </div>
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-12 flex items-center justify-between px-4 border-b border-white/10 bg-slate-800 flex-shrink-0">
          <div className="text-xs text-slate-400">Officer Dashboard · Krishnagiri District</div>
        </header>
        <main className="flex-1 overflow-y-auto bg-slate-900">{children}</main>
      </div>
    </div>
  );
}

// ── CITIZEN MOBILE LAYOUT ───────────────────────────────────
export function CitizenLayout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const BOTTOM_NAV = [
    { path:'/citizen', icon:Home, label:'Home', exact:true },
    { path:'/citizen/report', icon:Plus, label:'Report' },
    { path:'/citizen/tickets', icon:List, label:'My Tickets' },
    { path:'/citizen/map', icon:Map, label:'Map' },
    { path:'/citizen/profile', icon:User, label:'Profile' },
  ];

  const isActive = (path, exact) => exact ? location.pathname === path : location.pathname.startsWith(path);

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white max-w-md mx-auto relative overflow-hidden">
      {/* Mobile Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-white/10 flex-shrink-0" style={{ paddingTop:'env(safe-area-inset-top,12px)' }}>
        <div className="flex items-center gap-2">
          <span className="text-xl">🏛️</span>
          <div>
            <div className="text-sm font-black text-white">Krishnagiri <span style={{ color:'#E8931A' }}>Connect</span></div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/citizen/notifications" className="text-slate-400 hover:text-white p-1">
            <Bell size={18} />
          </Link>
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 overflow-y-auto">{children}</main>

      {/* Bottom Nav */}
      <div className="flex items-center bg-slate-800 border-t border-white/10 flex-shrink-0" style={{ paddingBottom:'env(safe-area-inset-bottom,0px)' }}>
        {BOTTOM_NAV.map(item => {
          const active = isActive(item.path, item.exact);
          return (
            <Link key={item.path} to={item.path} className={`flex-1 flex flex-col items-center py-2.5 gap-0.5 transition-all ${active ? 'text-amber-500' : 'text-slate-500 hover:text-slate-300'}`}>
              {item.path === '/citizen/report' ? (
                <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center -mt-5 shadow-lg">
                  <item.icon size={18} className="text-slate-900" />
                </div>
              ) : (
                <item.icon size={20} />
              )}
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
