import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff, Phone, Mail, Lock, User, MapPin } from 'lucide-react';
import { useAuthStore, useAppStore } from '../../store/index.js';
import { getRoleDashboard } from '../../utils/index.js';
import { Button, Input, Spinner } from '../../components/ui/index.jsx';
import { TALUKS } from '../../data/seed.js';

// ── LOGIN PAGE ──────────────────────────────────────────────
export function LoginPage() {
  const navigate = useNavigate();
  const { login, loginWithRole, loginError, clearError } = useAuthStore();
  const [email, setEmail] = useState('admin@krishnagiriconnect.in');
  const [password, setPassword] = useState('Admin@12345');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { language } = useAppStore();

  const DEMO_ROLES = [
    { role:'admin', label:'Admin', icon:'👨‍💼', email:'admin@krishnagiriconnect.in', pw:'Admin@12345', color:'#2563EB' },
    { role:'collector', label:'Collector', icon:'⚖️', email:'collector@krishnagiriconnect.in', pw:'Collect@123', color:'#D97706' },
    { role:'bdo', label:'BDO', icon:'📋', email:'bdo.hosur@krishnagiriconnect.in', pw:'Bdo@12345', color:'#059669' },
    { role:'twad', label:'TWAD Officer', icon:'💧', email:'twad@krishnagiriconnect.in', pw:'Twad@1234', color:'#0891B2' },
    { role:'citizen', label:'Citizen', icon:'👨', email:'rajesh@gmail.com', pw:'Citizen@123', color:'#6B7280' },
  ];

  const handleLogin = async (e) => {
    e?.preventDefault();
    clearError();
    setLoading(true);
    await new Promise(r => setTimeout(r, 500));
    const result = login(email, password);
    setLoading(false);
    if (result.success) navigate(getRoleDashboard(result.user.role));
  };

  const handleDemoLogin = async (demoRole) => {
    setLoading(true);
    setEmail(demoRole.email);
    setPassword(demoRole.pw);
    await new Promise(r => setTimeout(r, 300));
    const result = login(demoRole.email, demoRole.pw);
    setLoading(false);
    if (result.success) navigate(getRoleDashboard(result.user.role));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 px-4 py-12">
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Tamil:wght@400;600;700&family=Inter:wght@400;500;600;700;800;900&display=swap');*{font-family:'Inter',sans-serif;}`}</style>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl shadow-2xl" style={{ background:'radial-gradient(circle at 38% 38%,#F59E0B,#D97706)', boxShadow:'0 0 40px rgba(232,147,26,.4)' }}>
            🏛️
          </div>
          <h1 className="text-2xl font-black text-white">Krishnagiri <span style={{ color:'#E8931A' }}>Connect</span></h1>
          <div className="text-sm text-slate-400 mt-1">கிருஷ்ணகிரி இணைப்பு · Govt. of Tamil Nadu</div>
        </div>

        {/* Login Card */}
        <div className="bg-slate-800 rounded-2xl p-6 border border-white/10 shadow-2xl">
          <h2 className="text-base font-bold text-white mb-4">Sign In to Your Account</h2>

          {loginError && (
            <div className="mb-4 p-3 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-sm">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Email Address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)} required
                  className="w-full bg-slate-700 border border-white/10 rounded-lg pl-9 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors"
                  placeholder="email@example.com"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                  className="w-full bg-slate-700 border border-white/10 rounded-lg pl-9 pr-10 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors"
                  placeholder="••••••••"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input type="checkbox" id="remember" className="w-3.5 h-3.5 rounded" />
                <label htmlFor="remember" className="text-xs text-slate-400">Remember me</label>
              </div>
              <button type="button" className="text-xs text-amber-500 hover:text-amber-400">Forgot password?</button>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all"
              style={{ background:'#E8931A', color:'#0A1628' }}
            >
              {loading ? <Spinner size={16} /> : '🔐 Sign In'}
            </button>
          </form>

          <div className="mt-3 text-center">
            <Link to="/signup" className="text-xs text-amber-500 hover:text-amber-400">
              New citizen? Create an account →
            </Link>
          </div>
        </div>

        {/* Demo Logins */}
        <div className="mt-4 bg-slate-800 rounded-xl p-4 border border-white/10">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">Quick Demo Login</div>
          <div className="grid grid-cols-5 gap-1.5">
            {DEMO_ROLES.map(r => (
              <button key={r.role} onClick={() => handleDemoLogin(r)}
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/10 transition-all"
              >
                <span className="text-xl">{r.icon}</span>
                <span className="text-xs text-slate-400 font-medium">{r.label}</span>
              </button>
            ))}
          </div>
          <div className="mt-2 p-2 rounded-lg text-xs text-slate-500 bg-slate-700/50">
            <strong className="text-slate-400">Admin login:</strong> admin@krishnagiriconnect.in / Admin@12345
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SIGNUP PAGE ──────────────────────────────────────────────
export function SignupPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const { addUser } = useAppStore();
  const [form, setForm] = useState({ name:'', phone:'', email:'', village:'', taluk:'Hosur', password:'', confirm:'' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setForm(f => ({ ...f, [k]:v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) { setError('Passwords do not match'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 600));
    const newUser = {
      name: form.name,
      email: form.email || `${form.phone}@kgc.in`,
      phone: form.phone,
      password: form.password,
      role: 'citizen',
      taluk: form.taluk,
      village: form.village,
      status: 'active',
      avatar: '👤',
    };
    addUser(newUser);
    login(newUser.email, newUser.password);
    navigate('/citizen');
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 px-4 py-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="text-3xl mb-2">🏛️</div>
          <h1 className="text-xl font-black text-white">Create Account</h1>
          <div className="text-xs text-slate-400">கிருஷ்ணகிரி இணைப்பு · Join Krishnagiri Connect</div>
        </div>
        <div className="bg-slate-800 rounded-2xl p-6 border border-white/10">
          {error && <div className="mb-4 p-3 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-sm">{error}</div>}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Full Name *</label>
              <input type="text" value={form.name} onChange={e=>set('name',e.target.value)} required placeholder="Your full name"
                className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Mobile Number *</label>
              <input type="tel" value={form.phone} onChange={e=>set('phone',e.target.value)} required placeholder="+91 XXXXX XXXXX"
                className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Email (optional)</label>
              <input type="email" value={form.email} onChange={e=>set('email',e.target.value)} placeholder="your@email.com"
                className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Village</label>
                <input type="text" value={form.village} onChange={e=>set('village',e.target.value)} placeholder="Your village"
                  className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Taluk *</label>
                <select value={form.taluk} onChange={e=>set('taluk',e.target.value)} required
                  className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  {TALUKS.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Password *</label>
              <input type="password" value={form.password} onChange={e=>set('password',e.target.value)} required placeholder="Min 6 characters"
                className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Confirm Password *</label>
              <input type="password" value={form.confirm} onChange={e=>set('confirm',e.target.value)} required placeholder="Re-enter password"
                className="w-full bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-lg font-bold text-sm flex items-center justify-center gap-2 mt-2"
              style={{ background:'#E8931A', color:'#0A1628' }}
            >
              {loading ? <Spinner size={16} /> : '✅ Create Account'}
            </button>
          </form>
          <div className="mt-3 text-center">
            <Link to="/login" className="text-xs text-amber-500 hover:text-amber-400">Already have an account? Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
