import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Camera, MapPin, ChevronRight, Bell, Star, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { useAuthStore, useAppStore } from '../../store/index.js';
import { CitizenLayout } from '../../components/layout/index.jsx';
import { Badge, Button, Card, ScoreRing, SectionHeader, EmptyState, Spinner, ProgressBar } from '../../components/ui/index.jsx';
import { getSeverityConfig, getStatusConfig, autoRoute, generateTicketNumber, timeAgo, formatDate, calculateSLAStatus } from '../../utils/index.js';
import { CAT_CONFIG, SLA_CONFIG, TALUKS, VILLAGES } from '../../data/seed.js';

// ── CITIZEN HOME ─────────────────────────────────────────────
export function CitizenHome() {
  const { user } = useAuthStore();
  const { complaints, villages, notifications } = useAppStore();
  const navigate = useNavigate();

  const myComplaints = complaints.filter(c => c.reporter_id === user?.id).slice(0,3);
  const openCount = myComplaints.filter(c => !['resolved','closed'].includes(c.status)).length;
  const userVillage = villages.find(v => v.name === user?.village) || villages[0];
  const unread = notifications.filter(n => !n.read).length;

  return (
    <CitizenLayout>
      <div className="px-4 py-4 space-y-4">
        {/* Welcome */}
        <div className="rounded-2xl p-4" style={{ background:'linear-gradient(135deg,rgba(232,147,26,.2),rgba(37,99,235,.15))', border:'1px solid rgba(232,147,26,.2)' }}>
          <div className="text-xs text-amber-400 mb-1">நமஸ்கார! Welcome back,</div>
          <div className="text-lg font-black text-white">{user?.name?.split(' ')[0] || 'Citizen'}</div>
          <div className="text-xs text-slate-400 mt-0.5">📍 {user?.village || 'Krishnagiri'} · {user?.taluk || 'Hosur'} Taluk</div>
          {unread > 0 && (
            <Link to="/citizen/notifications" className="mt-2 inline-flex items-center gap-1 text-xs bg-amber-500/20 text-amber-400 px-2 py-1 rounded-full">
              <Bell size={10} /> {unread} new notification{unread>1?'s':''}
            </Link>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Link to="/citizen/report">
            <div className="rounded-2xl p-4 text-center" style={{ background:'rgba(220,38,38,.12)', border:'1px solid rgba(220,38,38,.25)' }}>
              <div className="text-3xl mb-1">📝</div>
              <div className="text-sm font-bold text-white">Report Issue</div>
              <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>பிரச்சனை புகாரளிக்கவும்</div>
            </div>
          </Link>
          <Link to="/citizen/tickets">
            <div className="rounded-2xl p-4 text-center" style={{ background:'rgba(37,99,235,.12)', border:'1px solid rgba(37,99,235,.25)' }}>
              <div className="text-3xl mb-1">🎫</div>
              <div className="text-sm font-bold text-white">My Tickets</div>
              <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>என் புகார்கள்</div>
            </div>
          </Link>
          <Link to="/citizen/map">
            <div className="rounded-2xl p-4 text-center" style={{ background:'rgba(8,145,178,.12)', border:'1px solid rgba(8,145,178,.25)' }}>
              <div className="text-3xl mb-1">🗺️</div>
              <div className="text-sm font-bold text-white">District Map</div>
              <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>மாவட்ட வரைபடம்</div>
            </div>
          </Link>
          <div onClick={()=>navigate('/citizen/report', { state:{ emergency:true } })} className="cursor-pointer">
            <div className="rounded-2xl p-4 text-center" style={{ background:'rgba(124,58,237,.12)', border:'1px solid rgba(124,58,237,.25)' }}>
              <div className="text-3xl mb-1">🚨</div>
              <div className="text-sm font-bold text-white">Emergency</div>
              <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>அவசர உதவி</div>
            </div>
          </div>
        </div>

        {/* Complaint Categories */}
        <div>
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2">Report by Category</div>
          <div className="grid grid-cols-4 gap-2">
            {Object.entries(CAT_CONFIG).slice(0,8).map(([k,v]) => (
              <Link key={k} to={`/citizen/report?cat=${k}`}>
                <div className="rounded-xl p-2.5 text-center bg-slate-800 border border-white/7 hover:border-amber-500/50 transition-all">
                  <div className="text-xl mb-1">{v.icon}</div>
                  <div className="text-xs text-slate-400 leading-tight" style={{ fontSize:'9px' }}>{v.label.split(' ').slice(0,2).join(' ')}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Village Score */}
        {userVillage && (
          <Card>
            <div className="flex items-center gap-3">
              <ScoreRing score={userVillage.vds} size={52} />
              <div>
                <div className="text-sm font-bold text-white">{userVillage.name}</div>
                <div className="text-xs text-slate-400">Village Development Score</div>
                <div className="flex gap-1 mt-1">
                  {[['💧',userVillage.water_score],['🏫',userVillage.school_score],['🛣️',userVillage.road_score]].map(([ic,sc])=>(
                    <span key={ic} className="text-xs text-slate-400">{ic}{sc}</span>
                  ))}
                </div>
              </div>
              <div className="ml-auto">
                {userVillage.open_complaints > 0 && (
                  <div className="text-xs text-red-400 font-semibold">⚠ {userVillage.open_complaints} open</div>
                )}
              </div>
            </div>
          </Card>
        )}

        {/* Emergency Numbers */}
        <div>
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-2">Emergency Numbers</div>
          <div className="grid grid-cols-2 gap-2">
            {[['🚔 Police','100'],['🚑 Ambulance','102'],['🔥 Fire','101'],['📞 CM Helpline','1070']].map(([l,n])=>(
              <a key={n} href={`tel:${n}`} className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-800 border border-white/7">
                <span className="text-sm">{l.split(' ')[0]}</span>
                <div>
                  <div className="text-xs text-slate-300">{l.split(' ').slice(1).join(' ')}</div>
                  <div className="text-sm font-black text-amber-400">{n}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </CitizenLayout>
  );
}

// ── REPORT FORM ───────────────────────────────────────────────
export function ReportForm() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { addComplaint, villages } = useAppStore();
  const [step, setStep] = useState(1); // 1:category 2:details 3:location 4:severity 5:review
  const [form, setForm] = useState({
    category: new URLSearchParams(window.location.search).get('cat') || 'no_water',
    description: '',
    village: user?.village || 'Hosur Town',
    taluk: user?.taluk || 'Hosur',
    severity: 'medium',
    phone: user?.phone || '',
    photos: 0,
    gps: null,
  });
  const [submitting, setSubmitting] = useState(false);
  const [ticket, setTicket] = useState(null);
  const setF = (k,v) => setForm(f=>({...f,[k]:v}));

  const catCfg = CAT_CONFIG[form.category];
  const route = autoRoute(form.category, form.taluk);

  const handleGPS = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setF('gps', { lat:pos.coords.latitude, lng:pos.coords.longitude }),
        () => setF('gps', { lat:12.7409, lng:77.8253 }) // fallback Hosur
      );
    } else {
      setF('gps', { lat:12.7409, lng:77.8253 });
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 800));
    const newTicket = addComplaint({
      category: form.category,
      category_label: catCfg.label,
      category_icon: catCfg.icon,
      dept: catCfg.dept,
      description: form.description || `${catCfg.label} reported in ${form.village}`,
      village: form.village,
      taluk: form.taluk,
      severity: form.severity,
      reporter: user?.name || 'Citizen',
      reporter_id: user?.id,
      reporter_phone: form.phone,
      lat: form.gps?.lat || 12.7409,
      lng: form.gps?.lng || 77.8253,
      photos: form.photos,
      assigned_bdo: route?.bdo?.id,
      assigned_bdo_name: route?.bdo?.name,
      assigned_officer: route?.dept_officer?.id,
      assigned_officer_name: route?.dept_officer?.name,
      sla_hours: SLA_CONFIG[form.severity]?.hours || 168,
      current_level: 1,
    });
    setTicket(newTicket);
    setSubmitting(false);
  };

  // Ticket Confirmation
  if (ticket) {
    const sla = SLA_CONFIG[ticket.severity] || {};
    return (
      <CitizenLayout>
        <div className="px-4 py-6 max-w-md mx-auto">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-green-500/20 border-2 border-green-500 mx-auto mb-3 flex items-center justify-center text-3xl animate-bounce">✅</div>
            <h2 className="text-lg font-black text-white">Complaint Submitted!</h2>
            <div className="text-xs text-slate-400 mt-1" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>புகார் சமர்ப்பிக்கப்பட்டது</div>
          </div>

          {/* Ticket */}
          <div className="rounded-2xl overflow-hidden border border-white/10 mb-4">
            <div className="p-4 text-center" style={{ background:'linear-gradient(135deg,#162C52,#1E3A6A)' }}>
              <div className="text-xs text-slate-400 uppercase tracking-widest mb-1">Krishnagiri Connect · Govt. of Tamil Nadu</div>
              <div className="text-2xl font-black text-amber-400 font-mono tracking-wider">{ticket.id}</div>
              <div className="text-xs text-slate-400 mt-1">{new Date().toLocaleString('en-IN')}</div>
            </div>
            <div className="p-4 space-y-2 bg-slate-800">
              {[
                ['Category', `${catCfg.icon} ${catCfg.label}`],
                ['Department', route?.dept_officer?.dept || catCfg.dept],
                ['Assigned Officer', route?.bdo?.name || '—'],
                ['Village / Taluk', `${ticket.village} · ${ticket.taluk}`],
                ['Severity', form.severity.toUpperCase()],
                ['SLA Deadline', sla.label || '7 days'],
              ].map(([l,v]) => (
                <div key={l} className="flex justify-between text-sm">
                  <span className="text-slate-400">{l}</span>
                  <span className="font-semibold text-white">{v}</span>
                </div>
              ))}
            </div>
            <div className="p-3 text-xs text-center text-slate-500" style={{ borderTop:'2px dashed rgba(255,255,255,.08)' }}>
              SMS & Email notification sent · Track at krishnagiriconnect.in
            </div>
          </div>

          {/* Routing Chain */}
          <div className="bg-slate-800 rounded-xl p-4 mb-4 border border-white/7">
            <div className="text-xs font-bold text-slate-400 uppercase mb-3">Auto-Routing Chain</div>
            {route?.chain.map((node, i) => (
              <div key={i} className="flex items-center gap-2 mb-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${i===0?'bg-green-500/20 border border-green-500 text-green-400':i===1?'bg-amber-500/20 border border-amber-500 text-amber-400':'bg-slate-700 border border-slate-600 text-slate-400'}`}>
                  {i===0?'✓':i===1?'▶':node.level}
                </div>
                <div className="flex-1 text-xs">
                  <div className="font-semibold text-white">{node.name}</div>
                  <div className="text-slate-500">{node.role}</div>
                </div>
                {i===1 && <span className="text-xs text-amber-400 font-bold">Notified</span>}
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Button variant="primary" className="flex-1 justify-center" onClick={()=>navigate('/citizen/tickets')}>📋 Track Ticket</Button>
            <Button variant="ghost" className="flex-1 justify-center" onClick={()=>{setTicket(null);setStep(1);}}>+ New Report</Button>
          </div>
        </div>
      </CitizenLayout>
    );
  }

  const STEPS = ['Category','Details','Location','Severity','Review'];

  return (
    <CitizenLayout>
      <div className="px-4 py-4 max-w-md mx-auto">
        {/* Step indicator */}
        <div className="flex items-center gap-1 mb-5">
          {STEPS.map((s,i) => (
            <React.Fragment key={s}>
              <div className={`flex-1 h-1.5 rounded-full transition-all ${i<step?'bg-amber-500':i===step-1?'bg-amber-500/60':'bg-slate-700'}`} />
            </React.Fragment>
          ))}
        </div>
        <div className="text-xs text-slate-400 mb-4">Step {step} of {STEPS.length}: <span className="text-white font-semibold">{STEPS[step-1]}</span></div>

        {/* Step 1: Category */}
        {step === 1 && (
          <div>
            <h2 className="text-base font-black text-white mb-1">Select Category</h2>
            <div className="text-xs text-slate-400 mb-4" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>புகார் வகையை தேர்ந்தெடுக்கவும்</div>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(CAT_CONFIG).map(([k,v]) => (
                <button key={k} onClick={()=>{setF('category',k);setStep(2);}}
                  className={`p-3 rounded-xl text-center transition-all border ${form.category===k?'border-amber-500 bg-amber-500/15':'border-white/7 bg-slate-800 hover:border-white/20'}`}
                >
                  <div className="text-2xl mb-1">{v.icon}</div>
                  <div className="text-xs font-semibold text-white leading-tight" style={{ fontSize:'9px' }}>{v.label}</div>
                  <div className="text-slate-500 leading-tight mt-0.5" style={{ fontSize:'8px', fontFamily:"'Noto Sans Tamil',sans-serif" }}>{v.tamil}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Details */}
        {step === 2 && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center gap-2 p-3 rounded-xl mb-4" style={{ background:'rgba(232,147,26,.1)', border:'1px solid rgba(232,147,26,.2)' }}>
                <span className="text-2xl">{catCfg?.icon}</span>
                <div>
                  <div className="text-sm font-bold text-white">{catCfg?.label}</div>
                  <div className="text-xs text-amber-400">{catCfg?.tamil}</div>
                </div>
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Describe the Problem *<span className="ml-2 text-slate-500" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>பிரச்சனை விவரம்</span></label>
              <textarea value={form.description} onChange={e=>setF('description',e.target.value)}
                placeholder={`Describe ${catCfg?.label} issue in detail. How many people are affected?`}
                rows={4}
                className="w-full bg-slate-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 resize-none"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Contact Number *</label>
              <input value={form.phone} onChange={e=>setF('phone',e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="+91 XXXXX XXXXX"
              />
            </div>
            {/* Photo zone */}
            <div className="border-2 border-dashed border-white/10 rounded-xl p-4 text-center cursor-pointer hover:border-amber-500/50 transition-all"
              onClick={()=>setF('photos',form.photos+1)}
            >
              <Camera size={24} className="mx-auto mb-2 text-slate-400" />
              <div className="text-sm font-semibold text-white">Add Photo / Video</div>
              <div className="text-xs text-slate-500 mt-0.5">புகைப்படம் / வீடியோ சேர்க்கவும்</div>
              {form.photos > 0 && <div className="text-xs text-green-400 mt-1">✓ {form.photos} file{form.photos>1?'s':''} added</div>}
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={()=>setStep(1)} className="flex-1 justify-center">← Back</Button>
              <Button variant="primary" onClick={()=>setStep(3)} className="flex-1 justify-center">Next →</Button>
            </div>
          </div>
        )}

        {/* Step 3: Location */}
        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-base font-black text-white">Location Details</h2>
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Village / Area *</label>
              <input value={form.village} onChange={e=>setF('village',e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Your village name"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-1">Taluk *</label>
              <select value={form.taluk} onChange={e=>setF('taluk',e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
              >
                {TALUKS.map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            <button onClick={handleGPS}
              className={`w-full flex items-center justify-center gap-2 p-3 rounded-xl text-sm font-semibold transition-all ${form.gps?'bg-green-500/20 border border-green-500 text-green-400':'bg-slate-700 border border-white/10 text-slate-300 hover:border-amber-500'}`}
            >
              <MapPin size={16} />
              {form.gps ? `📍 GPS Captured: ${form.gps.lat.toFixed(4)}°N, ${form.gps.lng.toFixed(4)}°E` : '📍 Capture GPS Location (Optional)'}
            </button>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={()=>setStep(2)} className="flex-1 justify-center">← Back</Button>
              <Button variant="primary" onClick={()=>setStep(4)} className="flex-1 justify-center">Next →</Button>
            </div>
          </div>
        )}

        {/* Step 4: Severity */}
        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-base font-black text-white">How Severe?</h2>
            <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>தீவிரத்தை தேர்ந்தெடுக்கவும்</div>
            <div className="space-y-3">
              {[
                { key:'low',     icon:'🟢', label:'Low',      ta:'குறைந்த',  desc:'Minor inconvenience · Resolved in 30 days', color:'#16A34A' },
                { key:'medium',  icon:'🟡', label:'Medium',   ta:'நடுத்தர', desc:'Moderate issue · Resolved in 7 days', color:'#CA8A04' },
                { key:'high',    icon:'🟠', label:'High',     ta:'அதிக',    desc:'Serious problem · Resolved in 72 hours', color:'#EA580C' },
                { key:'critical',icon:'🔴', label:'Critical', ta:'அவசர',    desc:'People suffering · Resolved in 24 hours', color:'#DC2626' },
                { key:'emergency',icon:'🚨',label:'Emergency', ta:'அவசர நிலை',desc:'Life threat — Immediate response', color:'#7C3AED' },
              ].map(s => (
                <button key={s.key} onClick={()=>setF('severity',s.key)}
                  className={`w-full p-4 rounded-xl text-left border transition-all ${form.severity===s.key?'border-2':'border'}`}
                  style={{ background:form.severity===s.key?`${s.color}20`:'rgba(255,255,255,.03)', borderColor:form.severity===s.key?s.color:'rgba(255,255,255,.07)' }}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{s.icon}</span>
                    <div className="flex-1">
                      <div className="text-sm font-bold text-white">{s.label} <span className="text-xs ml-1" style={{ fontFamily:"'Noto Sans Tamil',sans-serif", color:s.color }}>{s.ta}</span></div>
                      <div className="text-xs text-slate-400">{s.desc}</div>
                    </div>
                    {form.severity===s.key && <span className="text-lg">✓</span>}
                  </div>
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={()=>setStep(3)} className="flex-1 justify-center">← Back</Button>
              <Button variant="primary" onClick={()=>setStep(5)} className="flex-1 justify-center">Next →</Button>
            </div>
          </div>
        )}

        {/* Step 5: Review */}
        {step === 5 && (
          <div className="space-y-4">
            <h2 className="text-base font-black text-white">Review & Submit</h2>
            <div className="bg-slate-800 rounded-xl p-4 space-y-3 border border-white/7">
              {[
                ['Category', `${catCfg?.icon} ${catCfg?.label}`],
                ['Village / Taluk', `${form.village} · ${form.taluk}`],
                ['Severity', form.severity.toUpperCase()],
                ['Photos', `${form.photos} file${form.photos!==1?'s':''}`],
                ['GPS', form.gps ? `${form.gps.lat.toFixed(4)}°N` : 'Not captured'],
                ['Dept.', route?.dept_officer?.dept || 'Auto-assigned'],
                ['Officer', route?.bdo?.name || 'BDO'],
                ['SLA', SLA_CONFIG[form.severity]?.label || '7 days'],
              ].map(([l,v]) => (
                <div key={l} className="flex justify-between items-center">
                  <span className="text-xs text-slate-400">{l}</span>
                  <span className="text-xs font-semibold text-white">{v}</span>
                </div>
              ))}
            </div>
            {form.description && (
              <div className="bg-slate-800 rounded-xl p-3 border border-white/7">
                <div className="text-xs text-slate-400 mb-1">Description</div>
                <div className="text-xs text-slate-300">{form.description}</div>
              </div>
            )}
            <div className="text-xs text-slate-500 text-center">By submitting, you confirm this is a genuine report. False reports may result in action.</div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={()=>setStep(4)} className="flex-1 justify-center">← Back</Button>
              <Button variant="primary" onClick={handleSubmit} disabled={submitting} className="flex-2 justify-center flex-1">
                {submitting ? <Spinner size={16} /> : '🚀 Submit Report'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </CitizenLayout>
  );
}

// ── MY TICKETS ────────────────────────────────────────────────
export function MyTickets() {
  const { user } = useAuthStore();
  const { complaints } = useAppStore();
  const [filter, setFilter] = useState('all');

  // Show all complaints filtered by taluk or user (in demo, show a sample)
  const myComplaints = complaints.filter(c =>
    c.reporter_id === user?.id || c.taluk === user?.taluk
  ).slice(0, 30);

  const filtered = myComplaints.filter(c =>
    filter === 'all' || c.status === filter ||
    (filter === 'active' && !['resolved','closed','rejected'].includes(c.status))
  );

  return (
    <CitizenLayout>
      <div className="px-4 py-4">
        <div className="text-base font-black text-white mb-1">My Tickets</div>
        <div className="text-xs text-slate-400 mb-4" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>என் புகார்கள்</div>

        {/* Filter tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
          {[['all','All'],['active','Active'],['resolved','Resolved'],['overdue','Overdue']].map(([k,l])=>(
            <button key={k} onClick={()=>setFilter(k)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${filter===k?'bg-amber-500 text-slate-900':'bg-slate-800 text-slate-400 border border-white/10'}`}
            >
              {l}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <EmptyState icon="🎫" title="No complaints yet" description="Tap + Report to file your first complaint"
            action={<Link to="/citizen/report"><Button variant="primary">+ File Report</Button></Link>}
          />
        ) : (
          <div className="space-y-3">
            {filtered.map(c => {
              const sv = getSeverityConfig(c.severity);
              const st = getStatusConfig(c.status);
              return (
                <Link key={c.id} to={`/citizen/ticket/${c.id}`}>
                  <div className="bg-slate-800 rounded-xl border border-white/7 p-3 hover:border-amber-500/30 transition-all">
                    <div className="flex items-start gap-2 mb-2">
                      <span className="text-xl">{c.category_icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-bold text-white truncate">{c.category_label}</div>
                        <div className="font-mono text-xs text-amber-400">{c.id}</div>
                      </div>
                      <Badge color={st.color}>{st.label}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-slate-400">{c.village} · {c.days_ago===0?'Today':`${c.days_ago}d ago`}</div>
                      <Badge color={sv.color}>{sv.label}</Badge>
                    </div>
                    {c.overdue && <div className="text-xs text-red-400 font-bold mt-1">⚠ SLA Breached — Escalated</div>}
                    {c.status === 'resolved' && <div className="text-xs text-green-400 mt-1">✓ Issue resolved by {c.assigned_bdo_name?.split(',')[0]||'Officer'}</div>}
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </CitizenLayout>
  );
}

// ── TICKET DETAIL ─────────────────────────────────────────────
export function TicketDetail() {
  const id = window.location.pathname.split('/').pop();
  const { complaints } = useAppStore();
  const complaint = complaints.find(c => c.id === id) || complaints[0];

  if (!complaint) return (
    <CitizenLayout>
      <EmptyState icon="❌" title="Ticket not found" />
    </CitizenLayout>
  );

  const sv = getSeverityConfig(complaint.severity);
  const st = getStatusConfig(complaint.status);
  const sla = calculateSLAStatus(complaint);
  const route = autoRoute(complaint.category, complaint.taluk);

  const TIMELINE = [
    { status:'Submitted', time:`${complaint.days_ago}d ago`, done:true, icon:'📝' },
    { status:'Verified & Routed', time:`${Math.max(0,complaint.days_ago-1)}d ago`, done:complaint.days_ago>0, icon:'✅' },
    { status:'Assigned to Officer', time:`${Math.max(0,complaint.days_ago-1)}d ago`, done:['assigned','accepted','in_progress','work_done','resolved'].includes(complaint.status), icon:'👤' },
    { status:'In Progress', time:'', done:['in_progress','work_done','resolved'].includes(complaint.status), icon:'🔨' },
    { status:'Work Completed', time:'', done:['work_done','resolved'].includes(complaint.status), icon:'🏗️' },
    { status:'Resolved', time:'', done:complaint.status==='resolved', icon:'🎉' },
  ];

  return (
    <CitizenLayout>
      <div className="px-4 py-4 max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center gap-2 mb-4">
          <Link to="/citizen/tickets" className="text-slate-400 hover:text-white">←</Link>
          <span className="font-mono text-amber-400 text-sm font-bold">{complaint.id}</span>
        </div>

        {/* Status Card */}
        <div className="rounded-2xl overflow-hidden border border-white/10 mb-4">
          <div className="p-4 text-center" style={{ background:`linear-gradient(135deg,${sv.color}20,rgba(37,99,235,.15))` }}>
            <span className="text-4xl">{complaint.category_icon}</span>
            <div className="text-base font-black text-white mt-2">{complaint.category_label}</div>
            <div className="flex items-center justify-center gap-2 mt-2">
              <Badge color={sv.color}>{complaint.severity.toUpperCase()}</Badge>
              <Badge color={st.color}>{st.label}</Badge>
            </div>
          </div>
          <div className="p-4 bg-slate-800 space-y-2">
            {[
              ['📍 Location', `${complaint.village} · ${complaint.taluk}`],
              ['👤 Assigned Officer', complaint.assigned_bdo_name?.split(',')[0] || '—'],
              ['🏢 Department', route?.dept_officer?.dept || '—'],
              ['⏰ SLA Status', sla.remaining],
              ['📅 Submitted', `${complaint.days_ago===0?'Today':`${complaint.days_ago} days ago`}`],
            ].map(([l,v]) => (
              <div key={l} className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{l}</span>
                <span className="font-semibold text-white">{v}</span>
              </div>
            ))}
            <div>
              <div className="text-xs text-slate-400 mb-1">SLA Progress</div>
              <ProgressBar value={sla.pct} color={sla.color} />
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-slate-800 rounded-2xl p-4 border border-white/7 mb-4">
          <div className="text-xs font-bold text-slate-400 uppercase mb-3">Complaint Timeline</div>
          {TIMELINE.map((t, i) => (
            <div key={i} className="flex items-start gap-3 mb-3 last:mb-0">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0 ${t.done?'bg-green-500/20 border border-green-500':'bg-slate-700 border border-slate-600'}`}>
                {t.done ? t.icon : <span className="text-slate-500">{i+1}</span>}
              </div>
              <div className="flex-1">
                <div className={`text-sm font-semibold ${t.done?'text-white':'text-slate-500'}`}>{t.status}</div>
                {t.time && <div className="text-xs text-slate-500">{t.time}</div>}
                {i < TIMELINE.length-1 && (
                  <div className={`w-0.5 h-4 ml-3 mt-1 ${t.done?'bg-green-500/40':'bg-slate-700'}`} />
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Description */}
        <div className="bg-slate-800 rounded-xl p-3 border border-white/7 mb-4">
          <div className="text-xs text-slate-400 mb-1">Description</div>
          <div className="text-sm text-slate-300">{complaint.description}</div>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" className="flex-1 justify-center" onClick={()=>window.history.back()}>← Back</Button>
          {complaint.status === 'resolved' ? (
            <Button variant="ghost" className="flex-1 justify-center">⭐ Rate Response</Button>
          ) : (
            <Button variant="danger" className="flex-1 justify-center">↑ Escalate</Button>
          )}
        </div>
      </div>
    </CitizenLayout>
  );
}

// ── CITIZEN PROFILE ───────────────────────────────────────────
export function CitizenProfile() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const { complaints, language, setLanguage } = useAppStore();
  const myCount = complaints.filter(c=>c.reporter_id===user?.id).length;
  const resolvedCount = complaints.filter(c=>c.reporter_id===user?.id&&c.status==='resolved').length;

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <CitizenLayout>
      <div className="px-4 py-4 max-w-md mx-auto">
        {/* Avatar */}
        <div className="text-center mb-6">
          <div className="w-20 h-20 rounded-full mx-auto mb-3 flex items-center justify-center text-4xl" style={{ background:'rgba(232,147,26,.15)', border:'2px solid rgba(232,147,26,.3)' }}>
            {user?.avatar || '👤'}
          </div>
          <div className="text-lg font-black text-white">{user?.name}</div>
          <div className="text-xs text-amber-400 capitalize mt-0.5">{user?.role?.replace('_',' ')}</div>
          <div className="text-xs text-slate-400">{user?.village} · {user?.taluk}</div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[['My Reports',myCount,'📋'],['Resolved',resolvedCount,'✅'],['Pending',Math.max(0,myCount-resolvedCount),'🔄']].map(([l,v,ic])=>(
            <div key={l} className="bg-slate-800 rounded-xl p-3 text-center border border-white/7">
              <div className="text-xl mb-1">{ic}</div>
              <div className="text-xl font-black text-white">{v}</div>
              <div className="text-xs text-slate-400">{l}</div>
            </div>
          ))}
        </div>

        {/* Info */}
        <div className="space-y-2 mb-6">
          {[['📱 Phone',user?.phone],['📧 Email',user?.email],['📍 Village',user?.village],['🏛️ Taluk',user?.taluk],['🔑 Role',user?.role?.replace('_',' ')]].map(([l,v])=>(
            <div key={l} className="flex items-center justify-between p-3 rounded-xl bg-slate-800 border border-white/7">
              <span className="text-sm text-slate-400">{l}</span>
              <span className="text-sm font-semibold text-white capitalize">{v||'—'}</span>
            </div>
          ))}
        </div>

        {/* Language toggle */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800 border border-white/7 mb-6">
          <span className="text-sm text-slate-400">Language / மொழி</span>
          <div className="flex rounded-lg overflow-hidden border border-white/10">
            <button onClick={()=>setLanguage('en')} className={`px-3 py-1 text-xs ${language==='en'?'bg-amber-500 text-slate-900':'bg-slate-700 text-slate-400'}`}>EN</button>
            <button onClick={()=>setLanguage('ta')} className={`px-3 py-1 text-xs ${language==='ta'?'bg-amber-500 text-slate-900':'bg-slate-700 text-slate-400'}`}>தமிழ்</button>
          </div>
        </div>

        {/* Logout */}
        <Button variant="danger" className="w-full justify-center" onClick={handleLogout}>
          🚪 Logout · வெளியேறு
        </Button>
      </div>
    </CitizenLayout>
  );
}

// ── CITIZEN NOTIFICATIONS ─────────────────────────────────────
export function CitizenNotifications() {
  const { notifications, markNotificationRead, markAllRead } = useAppStore();
  const TYPE_ICONS = { new_complaint:'📋', escalation:'⚡', status_change:'🔄', resolved:'✅', overdue:'⏰' };

  return (
    <CitizenLayout>
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="text-base font-black text-white">Notifications</div>
          {notifications.some(n=>!n.read) && (
            <button onClick={markAllRead} className="text-xs text-amber-400 hover:text-amber-300">Mark all read</button>
          )}
        </div>

        {notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No notifications" description="You'll be notified when your complaint status changes" />
        ) : (
          <div className="space-y-2">
            {notifications.slice(0,20).map(n => (
              <div key={n.id} onClick={()=>markNotificationRead(n.id)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${n.read?'bg-slate-800 border-white/7':'bg-amber-500/8 border-amber-500/25'}`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-xl">{TYPE_ICONS[n.type]||'🔔'}</span>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-white">{n.title}</div>
                    <div className="text-xs text-slate-400 mt-0.5">{n.message}</div>
                    <div className="text-xs text-slate-500 mt-1">{timeAgo(n.created_at)}</div>
                  </div>
                  {!n.read && <div className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0 mt-1" />}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </CitizenLayout>
  );
}
