import React, { useState, useMemo } from 'react';
import { useAuthStore, useAppStore } from '../../store/index.js';
import { OfficerLayout } from '../../components/layout/index.jsx';
import { KPICard, Card, Badge, Button, Modal, SectionHeader, Table, ProgressBar, EmptyState } from '../../components/ui/index.jsx';
import { getSeverityConfig, getStatusConfig, calculateSLAStatus, formatDateTime, timeAgo } from '../../utils/index.js';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { TALUKS } from '../../data/seed.js';

export function OfficerDashboard() {
  const { user } = useAuthStore();
  const { complaints, officers, updateComplaint, resolveComplaint, escalateComplaint } = useAppStore();
  const [selected, setSelected] = useState(null);
  const [newStatus, setNewStatus] = useState('');
  const [comment, setComment] = useState('');

  const myOfficer = officers.find(o => o.role === user?.role);

  const myComplaints = useMemo(() =>
    complaints.filter(c =>
      c.assigned_officer === myOfficer?.id ||
      c.assigned_bdo === myOfficer?.id ||
      c.taluk === user?.taluk ||
      user?.role === 'bdo'
    ).slice(0, 50),
    [complaints, myOfficer, user]
  );

  const pending = myComplaints.filter(c => !['resolved','closed','rejected'].includes(c.status));
  const overdue = myComplaints.filter(c => c.overdue);
  const resolved = myComplaints.filter(c => c.status === 'resolved');
  const critical = myComplaints.filter(c => ['critical','emergency'].includes(c.severity) && !['resolved','closed'].includes(c.status));

  return (
    <OfficerLayout>
      <div className="p-5 max-w-5xl mx-auto">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl" style={{ background:'rgba(232,147,26,.15)', border:'1px solid rgba(232,147,26,.3)' }}>
            {user?.avatar || '👤'}
          </div>
          <div>
            <h1 className="text-base font-black text-white">Welcome, {user?.name?.split(' ')[0] || 'Officer'}</h1>
            <div className="text-xs text-slate-400 capitalize">{user?.role?.replace('_',' ')} · {user?.taluk || 'Krishnagiri'} · Govt. of Tamil Nadu</div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <KPICard label="Pending Tasks" value={pending.length} icon="📋" color="#E8931A" />
          <KPICard label="Overdue" value={overdue.length} icon="⏰" color="#DC2626" />
          <KPICard label="Critical" value={critical.length} icon="🚨" color="#DC2626" />
          <KPICard label="Resolved" value={resolved.length} icon="✅" color="#16A34A" />
        </div>

        {overdue.length > 0 && (
          <div className="mb-4 p-3 rounded-xl" style={{ background:'rgba(220,38,38,.1)', border:'1px solid rgba(220,38,38,.25)' }}>
            <div className="text-sm font-bold text-red-400">⚠️ {overdue.length} complaints are overdue — immediate action required</div>
          </div>
        )}

        {/* Critical complaints */}
        {critical.length > 0 && (
          <Card className="mb-4">
            <SectionHeader title="🚨 Critical — Immediate Action" />
            <div className="space-y-2">
              {critical.slice(0,5).map(c => {
                const sv = getSeverityConfig(c.severity);
                const sla = calculateSLAStatus(c);
                return (
                  <div key={c.id} onClick={() => setSelected(c)}
                    className="p-3 rounded-xl cursor-pointer hover:bg-slate-700 transition-all flex items-start gap-3"
                    style={{ background:'rgba(220,38,38,.08)', border:'1px solid rgba(220,38,38,.2)' }}
                  >
                    <span className="text-lg">{c.category_icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white">{c.category_label}</div>
                      <div className="text-xs text-slate-400">{c.village} · {c.taluk} · {c.reporter}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge color={sv.color}>{sv.label}</Badge>
                        <span className="text-xs font-bold" style={{ color:sla.color }}>{sla.remaining}</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <Button variant="success" size="sm" onClick={e=>{e.stopPropagation();resolveComplaint(c.id);}}>✓ Resolve</Button>
                      <Button variant="danger" size="sm" onClick={e=>{e.stopPropagation();escalateComplaint(c.id);}}>↑ Escalate</Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        )}

        {/* All assigned */}
        <Card>
          <SectionHeader title="All Assigned Complaints" />
          <Table
            headers={['Ticket','Category','Village','Severity','Status','SLA','Actions']}
            rows={pending.slice(0,20).map(c => {
              const sv = getSeverityConfig(c.severity);
              const st = getStatusConfig(c.status);
              const sla = calculateSLAStatus(c);
              return [
                <button onClick={()=>setSelected(c)} className="font-mono text-amber-400 text-xs hover:underline">{c.id}</button>,
                <span className="text-xs">{c.category_icon} {c.category_label}</span>,
                <span className="text-xs">{c.village}</span>,
                <Badge color={sv.color}>{sv.label}</Badge>,
                <Badge color={st.color}>{st.label}</Badge>,
                <span className="text-xs font-semibold" style={{ color:sla.color }}>{sla.remaining}</span>,
                <div className="flex gap-1">
                  <button onClick={()=>resolveComplaint(c.id)} className="text-xs px-2 py-0.5 rounded bg-green-500/20 text-green-400 hover:bg-green-500/30">✓</button>
                  <button onClick={()=>escalateComplaint(c.id)} className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 hover:bg-red-500/30">↑</button>
                </div>,
              ];
            })}
          />
        </Card>

        {/* Detail Modal */}
        <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?.id||''} size="lg"
          footer={
            <>
              <Button variant="ghost" onClick={()=>setSelected(null)}>Close</Button>
              <Button variant="success" onClick={()=>{resolveComplaint(selected?.id);setSelected(null);}}>✓ Mark Resolved</Button>
              <Button variant="danger" onClick={()=>{escalateComplaint(selected?.id);setSelected(null);}}>↑ Escalate</Button>
            </>
          }
        >
          {selected && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['Category', `${selected.category_icon} ${selected.category_label}`],
                  ['Village / Taluk', `${selected.village} · ${selected.taluk}`],
                  ['Severity', <Badge color={getSeverityConfig(selected.severity).color}>{selected.severity.toUpperCase()}</Badge>],
                  ['Status', <Badge color={getStatusConfig(selected.status).color}>{getStatusConfig(selected.status).label}</Badge>],
                  ['Reporter', `${selected.reporter} · ${selected.reporter_phone}`],
                  ['Filed', `${selected.days_ago === 0 ? 'Today' : `${selected.days_ago}d ago`}`],
                  ['SLA Remaining', calculateSLAStatus(selected).remaining],
                  ['GPS', `${selected.lat?.toFixed(4)}°N, ${selected.lng?.toFixed(4)}°E`],
                ].map(([l,v]) => (
                  <div key={l} className="bg-slate-700 rounded-lg p-2.5">
                    <div className="text-xs text-slate-400 mb-0.5">{l}</div>
                    <div className="text-sm font-semibold text-white">{v}</div>
                  </div>
                ))}
              </div>
              <div className="bg-slate-700 rounded-lg p-3">
                <div className="text-xs text-slate-400 mb-1">Description</div>
                <div className="text-sm text-slate-300">{selected.description}</div>
              </div>
              {/* Update status */}
              <div className="flex gap-2">
                <select value={newStatus} onChange={e=>setNewStatus(e.target.value)}
                  className="flex-1 bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="">Update Status…</option>
                  {['accepted','in_progress','work_done','pending_verify','resolved'].map(s=>(
                    <option key={s} value={s}>{s.replace('_',' ')}</option>
                  ))}
                </select>
                <Button variant="primary" onClick={()=>{if(newStatus)updateComplaint(selected.id,{status:newStatus});setNewStatus('');}}>Update</Button>
              </div>
              {/* Comment */}
              <div className="flex gap-2">
                <input value={comment} onChange={e=>setComment(e.target.value)}
                  placeholder="Add work update or comment…"
                  className="flex-1 bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                />
                <Button variant="secondary" onClick={()=>setComment('')}>Post</Button>
              </div>
              {/* Photo upload sim */}
              <div className="border-2 border-dashed border-white/10 rounded-xl p-4 text-center cursor-pointer hover:border-amber-500 transition-colors">
                <div className="text-2xl mb-1">📷</div>
                <div className="text-xs text-slate-400">Upload completion photo / work evidence</div>
                <div className="text-xs text-slate-500 mt-0.5">JPG, PNG, MP4 supported</div>
              </div>
              <ProgressBar value={calculateSLAStatus(selected).pct} color={calculateSLAStatus(selected).color} />
            </div>
          )}
        </Modal>
      </div>
    </OfficerLayout>
  );
}

export function OfficerComplaintsPage() {
  const { user } = useAuthStore();
  const { complaints, resolveComplaint, escalateComplaint } = useAppStore();
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState('');

  const myComplaints = useMemo(() =>
    complaints.filter(c =>
      c.taluk === user?.taluk || !user?.taluk || user?.taluk === 'All'
    ).filter(c =>
      (!search || c.id.includes(search) || c.category_label.toLowerCase().includes(search.toLowerCase()) || c.village.toLowerCase().includes(search.toLowerCase())) &&
      (!statusF || c.status === statusF)
    ),
    [complaints, user, search, statusF]
  );

  return (
    <OfficerLayout>
      <div className="p-5 max-w-5xl mx-auto">
        <SectionHeader title={`Complaints (${myComplaints.length})`} />
        <Card className="mb-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e=>setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Search…" />
            </div>
            <select value={statusF} onChange={e=>setStatusF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Status</option>
              {['submitted','assigned','in_progress','resolved','overdue'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}
            </select>
          </div>
        </Card>
        <Card noPad>
          <Table
            headers={['Ticket','Category','Village','Severity','Status','SLA','Age','Actions']}
            rows={myComplaints.slice(0,40).map(c => {
              const sv = getSeverityConfig(c.severity);
              const st = getStatusConfig(c.status);
              const sla = calculateSLAStatus(c);
              return [
                <span className="font-mono text-amber-400 text-xs">{c.id}</span>,
                <span className="text-xs">{c.category_icon} {c.category_label}</span>,
                <span className="text-xs">{c.village}</span>,
                <Badge color={sv.color}>{sv.label}</Badge>,
                <Badge color={st.color}>{st.label}</Badge>,
                <span className="text-xs" style={{ color:sla.color }}>{sla.remaining}</span>,
                <span className="text-xs text-slate-400">{c.days_ago===0?'Today':`${c.days_ago}d`}</span>,
                <div className="flex gap-1">
                  <button onClick={()=>resolveComplaint(c.id)} className="text-xs px-1.5 py-0.5 rounded bg-green-500/20 text-green-400">✓</button>
                  <button onClick={()=>escalateComplaint(c.id)} className="text-xs px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400">↑</button>
                </div>,
              ];
            })}
          />
        </Card>
      </div>
    </OfficerLayout>
  );
}

export function OfficerProfilePage() {
  const { user, logout } = useAuthStore();
  const navigate = (path) => window.location.hash = path;
  return (
    <OfficerLayout>
      <div className="p-5 max-w-md mx-auto">
        <div className="text-center mb-6">
          <div className="w-20 h-20 rounded-full mx-auto mb-3 flex items-center justify-center text-4xl" style={{ background:'rgba(232,147,26,.15)', border:'2px solid rgba(232,147,26,.3)' }}>
            {user?.avatar || '👤'}
          </div>
          <div className="text-lg font-black text-white">{user?.name}</div>
          <div className="text-sm text-amber-400 capitalize">{user?.role?.replace('_',' ')}</div>
          <div className="text-xs text-slate-400 mt-0.5">{user?.taluk} · {user?.email}</div>
        </div>
        <div className="space-y-2 mb-6">
          {[['📱 Phone', user?.phone],['📧 Email', user?.email],['📍 Taluk', user?.taluk],['🔑 Role', user?.role?.replace('_',' ')],['🕐 Status', user?.status]].map(([l,v])=>(
            <div key={l} className="flex items-center justify-between p-3 rounded-xl bg-slate-800 border border-white/7">
              <span className="text-sm text-slate-400">{l}</span>
              <span className="text-sm font-semibold text-white capitalize">{v || '—'}</span>
            </div>
          ))}
        </div>
        <Button variant="danger" className="w-full justify-center" onClick={logout}>
          🚪 Logout
        </Button>
      </div>
    </OfficerLayout>
  );
}
