import React, { useEffect, useRef, useState } from 'react';
import { useAppStore } from '../../store/index.js';
import { AdminLayout, OfficerLayout, CitizenLayout } from '../../components/layout/index.jsx';
import { getSeverityConfig, getVDSColor, getStatusConfig } from '../../utils/index.js';
import { Badge, Button, SectionHeader } from '../../components/ui/index.jsx';
import { CAT_CONFIG } from '../../data/seed.js';

function MapCore({ height = '100%', standalone = false }) {
  const mapRef = useRef(null);
  const mapInstance = useRef(null);
  const layersRef = useRef({});
  const { villages, complaints, schools, waterAssets } = useAppStore();
  const [activeLayer, setActiveLayer] = useState('villages');
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    // Dynamic Leaflet import
    const L = window.L;
    if (!L) return;

    mapInstance.current = L.map(mapRef.current, {
      center: [12.52, 78.22],
      zoom: 10,
      preferCanvas: true,
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© OSM © CARTO',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(mapInstance.current);

    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const L = window.L;
    if (!L || !mapInstance.current) return;

    // Clear existing layers
    Object.values(layersRef.current).forEach(l => {
      if (mapInstance.current.hasLayer(l)) mapInstance.current.removeLayer(l);
    });
    layersRef.current = {};

    const villageLayer = L.layerGroup();
    villages.forEach(v => {
      const col = getVDSColor(v.vds);
      const sz = v.status === 'red' ? 14 : 12;
      const icon = L.divIcon({
        html: `<div style="width:${sz}px;height:${sz}px;background:${col};border-radius:50%;border:2px solid rgba(255,255,255,.4);box-shadow:0 2px 6px rgba(0,0,0,.4);${v.status==='red'?'animation:pulse 2s ease infinite;':''}"></div>`,
        iconSize: [sz, sz], iconAnchor: [sz/2, sz/2], className: '',
      });
      const m = L.marker([v.lat, v.lng], { icon });
      m.bindTooltip(`<div style="padding:8px 10px;background:#1E293B;border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#E2EBF8;min-width:160px;font-family:Inter,sans-serif;">
        <div style="font-size:11px;font-weight:800;color:${col};margin-bottom:2px;">${v.name}</div>
        <div style="font-size:9px;color:#8DAAC4;">${v.taluk} Taluk · ${v.population.toLocaleString()} people</div>
        <div style="font-size:11px;font-weight:700;color:${col};margin-top:4px;">VDS: ${v.vds}/100</div>
        <div style="font-size:9px;color:#4A6A84;">💧${v.water_score} · 🏫${v.school_score} · 🛣️${v.road_score}</div>
      </div>`, { className: '', direction: 'top', offset: [0, -6] });
      m.on('click', () => setSelected({ type: 'village', data: v }));
      villageLayer.addLayer(m);
    });
    layersRef.current.villages = villageLayer;

    const complaintLayer = L.layerGroup();
    complaints.slice(0, 100).forEach(c => {
      const sv = getSeverityConfig(c.severity);
      const sz = c.severity === 'critical' || c.severity === 'emergency' ? 12 : 9;
      const icon = L.divIcon({
        html: `<div style="width:${sz}px;height:${sz}px;background:${sv.color};border-radius:3px;border:1.5px solid rgba(255,255,255,.35);box-shadow:0 1px 4px rgba(0,0,0,.4);"></div>`,
        iconSize: [sz, sz], iconAnchor: [sz/2, sz/2], className: '',
      });
      const m = L.marker([c.lat, c.lng], { icon });
      m.bindTooltip(`<div style="padding:8px 10px;background:#1E293B;border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#E2EBF8;min-width:150px;font-family:Inter,sans-serif;">
        <div style="font-size:10px;font-weight:700;color:${sv.color};margin-bottom:2px;">${c.category_icon} ${c.category_label}</div>
        <div style="font-size:9px;color:#8DAAC4;">${c.village} · ${c.taluk}</div>
        <div style="font-size:9px;color:${sv.color};">${c.severity.toUpperCase()} · ${getStatusConfig(c.status).label}</div>
      </div>`, { className: '', direction: 'top', offset: [0, -6] });
      m.on('click', () => setSelected({ type: 'complaint', data: c }));
      complaintLayer.addLayer(m);
    });
    layersRef.current.complaints = complaintLayer;

    const schoolLayer = L.layerGroup();
    schools.forEach(s => {
      const col = s.status === 'green' ? '#16A34A' : s.status === 'yellow' ? '#CA8A04' : s.status === 'orange' ? '#EA580C' : '#DC2626';
      const icon = L.divIcon({
        html: `<div style="width:12px;height:12px;background:#7C3AED;border:2px solid rgba(255,255,255,.4);border-radius:3px;box-shadow:0 0 4px #7C3AED66;"></div>`,
        iconSize: [12, 12], iconAnchor: [6, 6], className: '',
      });
      const m = L.marker([s.lat, s.lng], { icon });
      m.bindTooltip(`<div style="padding:8px 10px;background:#1E293B;border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#E2EBF8;font-family:Inter,sans-serif;">
        <div style="font-size:10px;font-weight:700;color:#A78BFA;margin-bottom:2px;">🏫 ${s.name}</div>
        <div style="font-size:9px;color:#8DAAC4;">${s.village} · ${s.taluk}</div>
        <div style="font-size:9px;color:${col};">Score: ${s.score} · ${s.students} students</div>
      </div>`, { className: '', direction: 'top', offset: [0, -6] });
      m.on('click', () => setSelected({ type: 'school', data: s }));
      schoolLayer.addLayer(m);
    });
    layersRef.current.schools = schoolLayer;

    const waterLayer = L.layerGroup();
    waterAssets.forEach(a => {
      const col = a.status === 'Operational' ? '#0891B2' : a.status === 'Failed' || a.status === 'Offline' ? '#DC2626' : '#CA8A04';
      const icon = L.divIcon({
        html: `<div style="width:14px;height:14px;background:${col}22;border:1.5px solid ${col};border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:8px;">💧</div>`,
        iconSize: [14, 14], iconAnchor: [7, 7], className: '',
      });
      const m = L.marker([a.lat, a.lng], { icon });
      m.bindTooltip(`<div style="padding:8px 10px;background:#1E293B;border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#E2EBF8;font-family:Inter,sans-serif;">
        <div style="font-size:10px;font-weight:700;color:${col};">💧 ${a.name}</div>
        <div style="font-size:9px;color:#8DAAC4;">${a.type} · ${a.taluk}</div>
        <div style="font-size:9px;color:${col};">${a.status}</div>
      </div>`, { className: '', direction: 'top', offset: [0, -6] });
      m.on('click', () => setSelected({ type: 'water', data: a }));
      waterLayer.addLayer(m);
    });
    layersRef.current.water = waterLayer;

    // Show active layer
    if (layersRef.current[activeLayer]) {
      mapInstance.current.addLayer(layersRef.current[activeLayer]);
    }
  }, [villages, complaints, schools, waterAssets, activeLayer]);

  const switchLayer = (layer) => {
    const L = window.L;
    if (!L || !mapInstance.current) return;
    Object.values(layersRef.current).forEach(l => {
      if (mapInstance.current.hasLayer(l)) mapInstance.current.removeLayer(l);
    });
    if (layersRef.current[layer]) {
      mapInstance.current.addLayer(layersRef.current[layer]);
    }
    setActiveLayer(layer);
  };

  const LAYER_CONFIGS = [
    { key:'villages', label:'🏘️ Villages', color:'#16A34A' },
    { key:'complaints', label:'📋 Complaints', color:'#E8931A' },
    { key:'schools', label:'🏫 Schools', color:'#7C3AED' },
    { key:'water', label:'💧 Water', color:'#0891B2' },
  ];

  return (
    <div className="relative w-full" style={{ height }}>
      {/* Leaflet CSS */}
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" />

      <div ref={mapRef} className="w-full h-full" />

      {/* Layer chips */}
      <div className="absolute top-2 left-2 z-1000 flex gap-1 flex-wrap">
        {LAYER_CONFIGS.map(lc => (
          <button key={lc.key} onClick={() => switchLayer(lc.key)}
            className="px-2.5 py-1 rounded-full text-xs font-bold backdrop-blur-sm transition-all"
            style={{
              background: activeLayer === lc.key ? lc.color : 'rgba(15,25,40,.9)',
              color: activeLayer === lc.key ? '#fff' : '#94A3B8',
              border: `1px solid ${activeLayer === lc.key ? lc.color : 'rgba(255,255,255,.12)'}`,
            }}
          >
            {lc.label}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="absolute bottom-8 left-2 z-1000 rounded-lg p-2.5 text-xs" style={{ background:'rgba(15,25,40,.94)', border:'1px solid rgba(255,255,255,.07)', backdropFilter:'blur(8px)', zIndex:999 }}>
        <div className="text-slate-500 text-xs font-bold uppercase tracking-wide mb-1.5">Status</div>
        {[['#16A34A','Good / Operational'],['#CA8A04','Needs Attention'],['#EA580C','High Priority'],['#DC2626','Critical']].map(([c,l])=>(
          <div key={l} className="flex items-center gap-1.5 mb-1">
            <div className="w-2 h-2 rounded-full" style={{ background:c }} />
            <span className="text-slate-300">{l}</span>
          </div>
        ))}
      </div>

      {/* Selected panel */}
      {selected && (
        <div className="absolute top-2 right-2 z-1000 w-56 rounded-xl p-3" style={{ background:'rgba(15,25,40,.96)', border:'1px solid rgba(255,255,255,.1)', backdropFilter:'blur(10px)', zIndex:999 }}>
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs font-bold text-white uppercase tracking-wide">{selected.type}</div>
            <button onClick={()=>setSelected(null)} className="text-slate-500 hover:text-white text-xs">✕</button>
          </div>
          {selected.type === 'village' && (
            <div>
              <div className="text-sm font-bold text-white mb-1">{selected.data.name}</div>
              <div className="text-xs text-slate-400">{selected.data.taluk} · {selected.data.population.toLocaleString()} people</div>
              <div className="mt-2 text-xs font-bold" style={{ color:getVDSColor(selected.data.vds) }}>VDS: {selected.data.vds}/100</div>
              {[['💧 Water',selected.data.water_score],['🏫 School',selected.data.school_score],['🛣️ Road',selected.data.road_score]].map(([l,v])=>(
                <div key={l} className="flex items-center gap-1.5 mt-1">
                  <span className="text-xs text-slate-400 w-16">{l}</span>
                  <div className="flex-1 h-1.5 rounded-full bg-slate-700 overflow-hidden">
                    <div className="h-full rounded-full" style={{ width:`${v}%`, background:getVDSColor(v) }} />
                  </div>
                  <span className="text-xs" style={{ color:getVDSColor(v) }}>{v}</span>
                </div>
              ))}
            </div>
          )}
          {selected.type === 'complaint' && (
            <div>
              <div className="text-xs font-mono text-amber-400 mb-1">{selected.data.id}</div>
              <div className="text-sm font-bold text-white">{selected.data.category_icon} {selected.data.category_label}</div>
              <div className="text-xs text-slate-400 mt-1">{selected.data.village} · {selected.data.taluk}</div>
              <div className="mt-2 flex gap-1">
                <Badge color={getSeverityConfig(selected.data.severity).color}>{selected.data.severity.toUpperCase()}</Badge>
                <Badge color={getStatusConfig(selected.data.status).color}>{getStatusConfig(selected.data.status).label}</Badge>
              </div>
            </div>
          )}
          {selected.type === 'school' && (
            <div>
              <div className="text-sm font-bold text-white">{selected.data.name}</div>
              <div className="text-xs text-slate-400 mt-1">{selected.data.village} · {selected.data.taluk}</div>
              <div className="text-xs text-slate-400">{selected.data.type} · {selected.data.students} students</div>
              <div className="mt-2 text-xs font-bold" style={{ color:getVDSColor(selected.data.score) }}>Score: {selected.data.score}/100</div>
            </div>
          )}
          {selected.type === 'water' && (
            <div>
              <div className="text-sm font-bold text-white">💧 {selected.data.name}</div>
              <div className="text-xs text-slate-400 mt-1">{selected.data.type} · {selected.data.taluk}</div>
              <div className="text-xs mt-1" style={{ color:selected.data.status==='Operational'?'#16A34A':'#DC2626' }}>{selected.data.status}</div>
              <div className="text-xs text-slate-400 mt-1">Cap: {selected.data.capacity}</div>
            </div>
          )}
        </div>
      )}

      {/* Stats bar */}
      <div className="absolute bottom-2 right-2 z-999 rounded-full px-4 py-1.5 flex gap-4" style={{ background:'rgba(15,25,40,.92)', border:'1px solid rgba(255,255,255,.07)', backdropFilter:'blur(8px)', zIndex:999 }}>
        {[['50','Villages'],['200','Complaints'],['50','Schools'],['25','Water']].map(([v,l])=>(
          <div key={l} className="text-center">
            <div className="text-sm font-black text-white">{v}</div>
            <div className="text-xs text-slate-500">{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdminMapPage() {
  return (
    <AdminLayout>
      <div className="flex flex-col h-full">
        <div className="px-5 py-3 border-b border-white/10 bg-slate-800 flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-white">GIS District Map — Krishnagiri</div>
            <div className="text-xs text-slate-400">50 villages · 200 complaints · 50 schools · 25 water assets · Click any marker for details</div>
          </div>
        </div>
        <div className="flex-1" style={{ minHeight:0 }}>
          <MapCore height="100%" />
        </div>
      </div>
    </AdminLayout>
  );
}

export function OfficerMapPage() {
  return (
    <OfficerLayout>
      <div className="flex flex-col h-full">
        <div className="px-4 py-3 border-b border-white/10 bg-slate-800">
          <div className="text-sm font-bold text-white">District Map</div>
        </div>
        <div className="flex-1" style={{ minHeight:0 }}>
          <MapCore height="100%" />
        </div>
      </div>
    </OfficerLayout>
  );
}

export function CitizenMapPage() {
  return (
    <CitizenLayout>
      <div className="flex flex-col" style={{ height:'calc(100vh - 100px)' }}>
        <div className="px-4 py-2 border-b border-white/10 bg-slate-800 flex-shrink-0">
          <div className="text-sm font-bold text-white">District Infrastructure Map</div>
          <div className="text-xs text-slate-400">Tap any marker for details</div>
        </div>
        <div className="flex-1" style={{ minHeight:0 }}>
          <MapCore height="100%" />
        </div>
      </div>
    </CitizenLayout>
  );
}
