import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle, Clock, Users, School, Droplets, Building2, Download, Filter, Search, Plus, Edit2, Trash2, Eye, RefreshCw, ChevronUp, BarChart3 } from 'lucide-react';
import { useAppStore } from '../../store/index.js';
import { AdminLayout } from '../../components/layout/index.jsx';
import { KPICard, Card, Badge, Button, Modal, Input, Table, ProgressBar, ScoreRing, SectionHeader, EmptyState, Spinner } from '../../components/ui/index.jsx';
import { getSeverityConfig, getStatusConfig, getVDSColor, getVDSLabel, formatDateTime, timeAgo, calculateSLAStatus, autoRoute } from '../../utils/index.js';
import { CAT_CONFIG, DEPARTMENTS, ROLES, TALUKS } from '../../data/seed.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

// ── RECHARTS TOOLTIP ──────────────────────────────────────────
const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-slate-700 border border-white/10 rounded-lg p-2 text-xs">
      <div className="text-slate-300 mb-1">{label}</div>
      {payload.map((p,i) => <div key={i} style={{ color:p.fill||p.color }}>{p.name}: {p.value}</div>)}
    </div>
  );
};

// ── ADMIN DASHBOARD ──────────────────────────────────────────
export function AdminDashboard() {
  const { complaints, villages, schools, waterAssets, officers, users, getOverdueComplaints } = useAppStore();
  const stats = useMemo(() => ({
    total: complaints.length,
    open: complaints.filter(c=>!['resolved','closed','rejected'].includes(c.status)).length,
    resolved: complaints.filter(c=>c.status==='resolved').length,
    overdue: complaints.filter(c=>c.overdue).length,
    critical: complaints.filter(c=>['critical','emergency'].includes(c.severity)).length,
    total_users: users.length,
    population: villages.reduce((s,v)=>s+v.population,0),
  }), [complaints, villages, users]);

  // Charts data
  const catData = useMemo(() => {
    const counts = {};
    complaints.forEach(c => { counts[c.category_label] = (counts[c.category_label]||0)+1; });
    return Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,value]) => ({ name: name.split(' ').slice(0,2).join(' '), value }));
  }, [complaints]);

  const talukData = useMemo(() =>
    TALUKS.map(t => {
      const tc = complaints.filter(c=>c.taluk===t);
      return { name:t.substring(0,8), total:tc.length, resolved:tc.filter(c=>c.status==='resolved').length };
    }), [complaints]
  );

  const sevData = [
    { name:'Emergency', value:complaints.filter(c=>c.severity==='emergency').length, color:'#7C3AED' },
    { name:'Critical', value:complaints.filter(c=>c.severity==='critical').length, color:'#DC2626' },
    { name:'High', value:complaints.filter(c=>c.severity==='high').length, color:'#EA580C' },
    { name:'Medium', value:complaints.filter(c=>c.severity==='medium').length, color:'#CA8A04' },
    { name:'Low', value:complaints.filter(c=>c.severity==='low').length, color:'#16A34A' },
  ];

  const recentComplaints = complaints.slice(0,8);

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-lg font-black text-white">District Admin Dashboard</h1>
            <div className="text-xs text-slate-400">Krishnagiri District · Govt. of Tamil Nadu · Live data</div>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" icon="📄">Export Report</Button>
            <Button variant="primary" size="sm" icon="⚡">Live Refresh</Button>
          </div>
        </div>

        {/* Overdue Alert */}
        {stats.overdue > 0 && (
          <div className="mb-4 p-3 rounded-xl flex items-center gap-3" style={{ background:'rgba(220,38,38,.1)', border:'1px solid rgba(220,38,38,.25)' }}>
            <AlertTriangle size={18} className="text-red-400 animate-pulse flex-shrink-0" />
            <div className="text-sm">
              <strong className="text-red-400">{stats.overdue} complaints</strong>
              <span className="text-slate-300"> have breached SLA deadline. </span>
              <Link to="/admin/escalation" className="text-red-400 underline">View Escalation →</Link>
            </div>
          </div>
        )}

        {/* KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-5">
          <KPICard label="Total Complaints" value={stats.total} icon="📋" color="#E8931A" sub="This period" />
          <KPICard label="Open" value={stats.open} icon="🔓" color="#EA580C" sub="Pending action" />
          <KPICard label="Resolved" value={stats.resolved} icon="✅" color="#16A34A" sub="Completed" />
          <KPICard label="SLA Breached" value={stats.overdue} icon="⚠️" color="#DC2626" sub="Auto-escalating" />
          <KPICard label="Critical" value={stats.critical} icon="🚨" color="#DC2626" sub="Urgent" />
          <KPICard label="Users" value={stats.total_users} icon="👥" color="#2563EB" sub="Registered" />
        </div>

        {/* Second row KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <KPICard label="Villages" value={villages.length} icon="🏘️" color="#E8931A" sub={`${(stats.population/100000).toFixed(1)}L people`} />
          <KPICard label="Schools" value={schools.length} icon="🏫" color="#7C3AED" sub="294 total target" />
          <KPICard label="Water Assets" value={waterAssets.length} icon="💧" color="#0891B2" sub="Tracked" />
          <KPICard label="Officers" value={officers.length} icon="👤" color="#059669" sub="Assigned" />
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <Card>
            <SectionHeader title="Complaints by Category" />
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={catData} margin={{ top:0, right:0, bottom:30, left:0 }}>
                <XAxis dataKey="name" tick={{ fill:'#94A3B8', fontSize:9 }} angle={-30} textAnchor="end" />
                <YAxis tick={{ fill:'#94A3B8', fontSize:9 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" fill="#E8931A" radius={[3,3,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card>
            <SectionHeader title="Severity Distribution" />
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="60%" height={180}>
                <PieChart>
                  <Pie data={sevData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value" paddingAngle={2}>
                    {sevData.map((e,i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-2">
                {sevData.map(s => (
                  <div key={s.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background:s.color }} />
                    <span className="text-xs text-slate-300">{s.name}</span>
                    <span className="text-xs font-bold text-white ml-auto">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <Card>
            <SectionHeader title="Taluk-wise Complaints" />
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={talukData} margin={{ top:0, right:0, bottom:30, left:0 }}>
                <XAxis dataKey="name" tick={{ fill:'#94A3B8', fontSize:9 }} angle={-30} textAnchor="end" />
                <YAxis tick={{ fill:'#94A3B8', fontSize:9 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="total" fill="#334155" radius={[3,3,0,0]} name="Total" />
                <Bar dataKey="resolved" fill="#16A34A" radius={[3,3,0,0]} name="Resolved" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card>
            <SectionHeader title="Department Performance" />
            <div className="space-y-2">
              {DEPARTMENTS.slice(0,6).map(d => {
                const dc = complaints.filter(c=>c.dept===d.id);
                const rate = dc.length ? Math.round(dc.filter(c=>c.status==='resolved').length/dc.length*100) : 0;
                return (
                  <div key={d.id} className="flex items-center gap-2">
                    <span className="text-sm w-5">{d.icon}</span>
                    <span className="text-xs text-slate-400 w-28 truncate">{d.name.replace(' Department','').replace(' Board','')}</span>
                    <ProgressBar value={rate} color={rate>=80?'#16A34A':rate>=60?'#CA8A04':'#DC2626'} />
                    <span className="text-xs text-slate-300 w-8 text-right">{rate}%</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Recent Complaints */}
        <Card>
          <SectionHeader title="Recent Complaints" actions={<Link to="/admin/complaints"><Button variant="ghost" size="sm">View All →</Button></Link>} />
          <Table
            headers={['Ticket','Category','Village','Taluk','Severity','Status','Assigned','Age']}
            rows={recentComplaints.map(c => {
              const sv = getSeverityConfig(c.severity);
              const st = getStatusConfig(c.status);
              return [
                <span className="font-mono text-amber-400 text-xs">{c.id}</span>,
                <span className="text-xs">{c.category_icon} {c.category_label}</span>,
                <span className="text-xs">{c.village}</span>,
                <span className="text-xs">{c.taluk}</span>,
                <Badge color={sv.color}>{sv.label}</Badge>,
                <Badge color={st.color}>{st.label}</Badge>,
                <span className="text-xs text-slate-400">{c.assigned_officer_name?.split(' ')[0]||'—'}</span>,
                <span className="text-xs text-slate-400">{c.days_ago===0?'Today':`${c.days_ago}d ago`}</span>,
              ];
            })}
          />
        </Card>
      </div>
    </AdminLayout>
  );
}

// ── COMPLAINTS MANAGEMENT ────────────────────────────────────
export function ComplaintsPage() {
  const { complaints, updateComplaint, resolveComplaint, escalateComplaint } = useAppStore();
  const [search, setSearch] = useState('');
  const [talukF, setTalukF] = useState('');
  const [sevF, setSevF] = useState('');
  const [statusF, setStatusF] = useState('');
  const [selected, setSelected] = useState(null);
  const [assignModal, setAssignModal] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [newStatus, setNewStatus] = useState('');

  const filtered = useMemo(() => {
    return complaints.filter(c =>
      (!search || c.id.includes(search) || c.village.toLowerCase().includes(search.toLowerCase()) || c.category_label.toLowerCase().includes(search.toLowerCase())) &&
      (!talukF || c.taluk===talukF) &&
      (!sevF || c.severity===sevF) &&
      (!statusF || c.status===statusF)
    );
  }, [complaints, search, talukF, sevF, statusF]);

  const handleResolve = (id) => { resolveComplaint(id); setSelected(null); };
  const handleEscalate = (id) => { escalateComplaint(id); setSelected(null); };
  const handleStatusUpdate = (id) => {
    if (newStatus) { updateComplaint(id, { status:newStatus }); setNewStatus(''); }
  };

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader
          title={`All Complaints (${filtered.length})`}
          sub="Auto-routed · SLA-tracked · Escalation-enabled"
          actions={
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" icon="📥">Export CSV</Button>
              <Button variant="ghost" size="sm" icon="📄">Export PDF</Button>
            </div>
          }
        />

        {/* Filters */}
        <Card className="mb-4">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-40">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e=>setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Search ticket, village, category…"
              />
            </div>
            <select value={talukF} onChange={e=>setTalukF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Taluks</option>
              {TALUKS.map(t=><option key={t}>{t}</option>)}
            </select>
            <select value={sevF} onChange={e=>setSevF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Severity</option>
              {['emergency','critical','high','medium','low'].map(s=><option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
            </select>
            <select value={statusF} onChange={e=>setStatusF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Status</option>
              {['submitted','verified','assigned','in_progress','resolved','overdue','escalated'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}
            </select>
          </div>
        </Card>

        <Card noPad>
          <Table
            headers={['Ticket ID','Category','Village','Taluk','Severity','Status','Officer','Age','Actions']}
            rows={filtered.slice(0,50).map(c => {
              const sv = getSeverityConfig(c.severity);
              const st = getStatusConfig(c.status);
              const sla = calculateSLAStatus(c);
              return [
                <button onClick={()=>setSelected(c)} className="font-mono text-amber-400 text-xs hover:underline">{c.id}</button>,
                <span className="text-xs">{c.category_icon} {c.category_label}</span>,
                <span className="text-xs">{c.village}</span>,
                <span className="text-xs">{c.taluk}</span>,
                <Badge color={sv.color}>{sv.icon} {sv.label}</Badge>,
                <div>
                  <Badge color={st.color}>{st.label}</Badge>
                  {c.overdue && <div className="text-xs text-red-400 font-bold mt-0.5">⚠ OVERDUE</div>}
                </div>,
                <span className="text-xs text-slate-400">{c.assigned_officer_name?.split(',')[0]||'—'}</span>,
                <span className="text-xs" style={{ color:sla.color }}>{sla.remaining}</span>,
                <div className="flex gap-1">
                  <button onClick={()=>setSelected(c)} className="text-slate-400 hover:text-white p-1 rounded hover:bg-white/10"><Eye size={13}/></button>
                  <button onClick={()=>handleResolve(c.id)} className="text-green-400 hover:text-green-300 p-1 rounded hover:bg-green-400/10 text-xs">✓</button>
                  <button onClick={()=>handleEscalate(c.id)} className="text-red-400 hover:text-red-300 p-1 rounded hover:bg-red-400/10 text-xs">↑</button>
                </div>,
              ];
            })}
          />
          {filtered.length > 50 && <div className="p-3 text-center text-xs text-slate-500">Showing 50 of {filtered.length} results</div>}
        </Card>

        {/* Complaint Detail Modal */}
        <Modal open={!!selected} onClose={()=>setSelected(null)} title={`Complaint ${selected?.id}`} size="lg"
          footer={
            <>
              <Button variant="ghost" onClick={()=>setSelected(null)}>Close</Button>
              <Button variant="success" onClick={()=>handleResolve(selected?.id)}>✓ Mark Resolved</Button>
              <Button variant="danger" onClick={()=>handleEscalate(selected?.id)}>↑ Escalate</Button>
            </>
          }
        >
          {selected && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['Ticket ID', selected.id, 'font-mono text-amber-400'],
                  ['Category', `${selected.category_icon} ${selected.category_label}`],
                  ['Village', selected.village],
                  ['Taluk', selected.taluk],
                  ['Severity', <Badge color={getSeverityConfig(selected.severity).color}>{selected.severity.toUpperCase()}</Badge>],
                  ['Status', <Badge color={getStatusConfig(selected.status).color}>{getStatusConfig(selected.status).label}</Badge>],
                  ['Reporter', `${selected.reporter} · ${selected.reporter_phone}`],
                  ['Filed', selected.days_ago===0?'Today':`${selected.days_ago} days ago`],
                  ['Assigned BDO', selected.assigned_bdo_name],
                  ['Dept. Officer', selected.assigned_officer_name],
                  ['SLA', calculateSLAStatus(selected).remaining],
                  ['GPS', `${selected.lat?.toFixed(4)}°N, ${selected.lng?.toFixed(4)}°E`],
                ].map(([l,v,cls]) => (
                  <div key={l} className="bg-slate-700 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-1">{l}</div>
                    <div className={`text-sm font-semibold text-white ${cls||''}`}>{v}</div>
                  </div>
                ))}
              </div>
              <div className="bg-slate-700 rounded-lg p-3">
                <div className="text-xs text-slate-400 mb-1">Description</div>
                <div className="text-sm text-slate-300">{selected.description}</div>
              </div>
              <div className="flex gap-2">
                <select value={newStatus} onChange={e=>setNewStatus(e.target.value)}
                  className="flex-1 bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="">Change Status…</option>
                  {['verified','assigned','accepted','in_progress','work_done','pending_verify','resolved','rejected'].map(s=>(
                    <option key={s} value={s}>{s.replace('_',' ')}</option>
                  ))}
                </select>
                <Button variant="primary" onClick={()=>handleStatusUpdate(selected.id)}>Update</Button>
              </div>
              <div className="flex gap-2">
                <input value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder="Add officer comment…"
                  className="flex-1 bg-slate-700 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                />
                <Button variant="secondary" onClick={()=>{setCommentText('');} }>Post</Button>
              </div>
              {/* SLA Progress */}
              <div className="bg-slate-700 rounded-lg p-3">
                <div className="text-xs text-slate-400 mb-2">SLA Progress</div>
                <ProgressBar value={calculateSLAStatus(selected).pct} color={calculateSLAStatus(selected).color} />
                <div className="text-xs text-slate-400 mt-1">{calculateSLAStatus(selected).remaining}</div>
              </div>
            </div>
          )}
        </Modal>
      </div>
    </AdminLayout>
  );
}

// ── ESCALATION CENTRE ────────────────────────────────────────
export function EscalationPage() {
  const { complaints, escalateComplaint, resolveComplaint } = useAppStore();
  const overdue = complaints.filter(c => c.overdue);
  const critical = complaints.filter(c => ['critical','emergency'].includes(c.severity) && !['resolved','closed'].includes(c.status));

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title="🚨 Escalation Centre" sub="SLA-breached complaints requiring immediate action" />

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <KPICard label="SLA Breached" value={overdue.length} icon="⏰" color="#DC2626" />
          <KPICard label="Critical Open" value={critical.length} icon="🚨" color="#DC2626" />
          <KPICard label="Level 3+" value={overdue.filter(c=>c.current_level>=3).length} icon="⬆️" color="#EA580C" />
          <KPICard label="Emergency" value={complaints.filter(c=>c.severity==='emergency').length} icon="🆘" color="#7C3AED" />
        </div>

        {/* Escalation Rules */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
          <div className="lg:col-span-2">
            <Card>
              <SectionHeader title="Overdue Complaints" actions={
                <Button variant="danger" size="sm" onClick={()=>overdue.forEach(c=>escalateComplaint(c.id))}>⚡ Escalate All</Button>
              } />
              <div className="space-y-2">
                {overdue.slice(0,10).map(c => {
                  const sv = getSeverityConfig(c.severity);
                  const sla = calculateSLAStatus(c);
                  return (
                    <div key={c.id} className="p-3 rounded-xl border border-red-500/25 flex items-start gap-3" style={{ background:'rgba(220,38,38,.08)', animation:'pulse 3s ease infinite' }}>
                      <div className="text-xl">{c.category_icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-mono text-amber-400 text-xs font-bold">{c.id}</div>
                        <div className="text-sm font-semibold text-white">{c.category_label} — {c.village}</div>
                        <div className="text-xs text-slate-400">{c.taluk} · Reporter: {c.reporter} · {c.days_ago}d ago</div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge color={sv.color}>{sv.label}</Badge>
                          <span className="text-xs font-bold text-red-400">⚠ OVERDUE {sla.remaining}</span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Button variant="success" size="sm" onClick={()=>resolveComplaint(c.id)}>✓ Resolve</Button>
                        <Button variant="danger" size="sm" onClick={()=>escalateComplaint(c.id)}>⚡ Escalate</Button>
                      </div>
                    </div>
                  );
                })}
                {overdue.length === 0 && <EmptyState icon="✅" title="No overdue complaints" description="All complaints are within SLA" />}
              </div>
            </Card>
          </div>
          <div>
            <Card>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">SLA Rules</div>
              {[
                { sev:'Emergency', sla:'1 hour', color:'#7C3AED', chain:'Immediate → Collector' },
                { sev:'Critical', sla:'24 hours', color:'#DC2626', chain:'Panchayat→BDO→Dept→DRDA→Collector' },
                { sev:'High', sla:'72 hours', color:'#EA580C', chain:'Panchayat→BDO→Dept→DRDA' },
                { sev:'Medium', sla:'7 days', color:'#CA8A04', chain:'Panchayat→BDO→Dept' },
                { sev:'Low', sla:'30 days', color:'#16A34A', chain:'Panchayat→BDO' },
              ].map(r => (
                <div key={r.sev} className="mb-2 p-2.5 rounded-lg" style={{ background:`${r.color}15`, borderLeft:`3px solid ${r.color}` }}>
                  <div className="text-xs font-bold" style={{ color:r.color }}>{r.sev} — {r.sla}</div>
                  <div className="text-xs text-slate-400 mt-0.5">{r.chain}</div>
                </div>
              ))}
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

// ── COLLECTOR VIEW ────────────────────────────────────────────
export function CollectorDashboard() {
  const { complaints, villages } = useAppStore();
  const stats = {
    total: complaints.length,
    critical: complaints.filter(c=>['critical','emergency'].includes(c.severity)&&!['resolved','closed'].includes(c.status)).length,
    overdue: complaints.filter(c=>c.overdue).length,
    resolved: complaints.filter(c=>c.status==='resolved').length,
    resolution_rate: Math.round(complaints.filter(c=>c.status==='resolved').length/complaints.length*100),
  };
  const talukStats = TALUKS.map(t => {
    const tc = complaints.filter(c=>c.taluk===t);
    const rate = tc.length ? Math.round(tc.filter(c=>c.status==='resolved').length/tc.length*100) : 0;
    return { taluk:t, total:tc.length, critical:tc.filter(c=>['critical','emergency'].includes(c.severity)).length, overdue:tc.filter(c=>c.overdue).length, rate };
  }).sort((a,b) => a.rate-b.rate);

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <div className="mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl" style={{ background:'radial-gradient(circle,#F59E0B,#D97706)' }}>⚖️</div>
            <div>
              <h1 className="text-lg font-black text-white">District Collector Dashboard</h1>
              <div className="text-xs text-slate-400">Tmt. K. M. Sarayu, I.A.S. · Krishnagiri District</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
          <KPICard label="Total Complaints" value={stats.total} icon="📋" color="#E8931A" />
          <KPICard label="Critical" value={stats.critical} icon="🚨" color="#DC2626" />
          <KPICard label="SLA Breached" value={stats.overdue} icon="⏰" color="#DC2626" />
          <KPICard label="Resolved" value={stats.resolved} icon="✅" color="#16A34A" />
          <KPICard label="Resolution Rate" value={`${stats.resolution_rate}%`} icon="📊" color="#0891B2" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <Card>
            <SectionHeader title="Taluk Performance Ranking" />
            <div className="space-y-2">
              {talukStats.map((t, i) => {
                const col = t.rate>=80?'#16A34A':t.rate>=60?'#CA8A04':'#DC2626';
                return (
                  <div key={t.taluk} className="flex items-center gap-3 p-2 rounded-lg bg-slate-700/50">
                    <div className="w-5 text-xs text-slate-500 font-bold">{i+1}</div>
                    <div className="w-24 text-xs font-semibold text-white truncate">{t.taluk}</div>
                    <ProgressBar value={t.rate} color={col} />
                    <div className="flex gap-1.5 flex-shrink-0">
                      <Badge color="#DC2626">{t.critical}</Badge>
                      <Badge color={col}>{t.rate}%</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
          <Card>
            <SectionHeader title="Critical Complaints — Collector Action" />
            <div className="space-y-2">
              {complaints.filter(c=>['critical','emergency'].includes(c.severity)&&!['resolved','closed'].includes(c.status)).slice(0,8).map(c => {
                const sv = getSeverityConfig(c.severity);
                return (
                  <div key={c.id} className="p-2.5 rounded-lg flex items-center gap-2" style={{ background:`${sv.color}15`, border:`1px solid ${sv.color}33` }}>
                    <span className="text-base">{c.category_icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-white truncate">{c.category_label} — {c.village}</div>
                      <div className="text-xs text-slate-400">{c.taluk} · {c.days_ago}d ago · {c.assigned_officer_name?.split(',')[0]||'Unassigned'}</div>
                    </div>
                    <Badge color={sv.color}>{sv.label}</Badge>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Village Scores */}
        <Card>
          <SectionHeader title="Village Development Score Summary" />
          <div className="grid grid-cols-4 gap-2">
            {[['🟢','Good (80+)',villages.filter(v=>v.status==='green').length,'#16A34A'],
              ['🟡','Attention (60-79)',villages.filter(v=>v.status==='yellow').length,'#CA8A04'],
              ['🟠','High Priority (40-59)',villages.filter(v=>v.status==='orange').length,'#EA580C'],
              ['🔴','Critical (<40)',villages.filter(v=>v.status==='red').length,'#DC2626'],
            ].map(([ic,lb,cnt,col]) => (
              <div key={lb} className="text-center p-3 rounded-xl" style={{ background:`${col}15`, border:`1px solid ${col}33` }}>
                <div className="text-2xl mb-1">{ic}</div>
                <div className="text-xl font-black" style={{ color:col }}>{cnt}</div>
                <div className="text-xs text-slate-400 mt-0.5">{lb}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AdminLayout>
  );
}

// ── SCHOOL MODULE ─────────────────────────────────────────────
export function SchoolsPage() {
  const { schools, updateSchool, deleteSchool } = useAppStore();
  const [search, setSearch] = useState('');
  const [talukF, setTalukF] = useState('');
  const [statusF, setStatusF] = useState('');
  const [view, setView] = useState('grid');
  const [selected, setSelected] = useState(null);
  const [addModal, setAddModal] = useState(false);

  const filtered = useMemo(() => schools.filter(s =>
    (!search || s.name.toLowerCase().includes(search.toLowerCase()) || s.emis.includes(search) || s.village.toLowerCase().includes(search.toLowerCase())) &&
    (!talukF || s.taluk===talukF) &&
    (!statusF || s.status===statusF)
  ), [schools, search, talukF, statusF]);

  const stats = {
    green: schools.filter(s=>s.status==='green').length,
    yellow: schools.filter(s=>s.status==='yellow').length,
    orange: schools.filter(s=>s.status==='orange').length,
    red: schools.filter(s=>s.status==='red').length,
    total_students: schools.reduce((s,sch)=>s+sch.students,0),
  };

  const INFRA_KEYS = [
    ['drinking_water','💧','Water',15],['toilets','🚽','Toilets',10],['girls_toilets','🚺','Girls Toilet',12],
    ['electricity','⚡','Electricity',8],['internet','🌐','Internet',7],['library','📚','Library',8],
    ['science_lab','🔬','Science Lab',10],['computer_lab','💻','Computer Lab',10],
    ['playground','⛹️','Playground',5],['cctv','📷','CCTV',5],['boundary_wall','🧱','Boundary Wall',10],
  ];

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader
          title={`School Module (${filtered.length} schools)`}
          sub="Infrastructure monitoring · Health score 0–100"
          actions={<Button variant="primary" size="sm" icon="+" onClick={()=>setAddModal(true)}>Add School</Button>}
        />

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-4">
          <KPICard label="🔴 Critical" value={stats.red} icon="" color="#DC2626" />
          <KPICard label="🟠 High Priority" value={stats.orange} icon="" color="#EA580C" />
          <KPICard label="🟡 Attention" value={stats.yellow} icon="" color="#CA8A04" />
          <KPICard label="🟢 Good" value={stats.green} icon="" color="#16A34A" />
          <KPICard label="Total Students" value={stats.total_students.toLocaleString()} icon="👩‍🎓" color="#7C3AED" />
        </div>

        {/* Filters */}
        <Card className="mb-4">
          <div className="flex flex-wrap gap-2 items-center">
            <div className="relative flex-1 min-w-40">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e=>setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Search school name, EMIS, village…"
              />
            </div>
            <select value={talukF} onChange={e=>setTalukF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Taluks</option>
              {TALUKS.map(t=><option key={t}>{t}</option>)}
            </select>
            <select value={statusF} onChange={e=>setStatusF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Scores</option>
              <option value="red">🔴 Critical (0-39)</option>
              <option value="orange">🟠 High (40-59)</option>
              <option value="yellow">🟡 Attention (60-79)</option>
              <option value="green">🟢 Good (80-100)</option>
            </select>
            <div className="flex rounded-lg overflow-hidden border border-white/10">
              <button onClick={()=>setView('grid')} className={`px-3 py-1.5 text-xs ${view==='grid'?'bg-amber-500 text-slate-900':'bg-slate-700 text-slate-400'}`}>Grid</button>
              <button onClick={()=>setView('table')} className={`px-3 py-1.5 text-xs ${view==='table'?'bg-amber-500 text-slate-900':'bg-slate-700 text-slate-400'}`}>Table</button>
            </div>
          </div>
        </Card>

        {view === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filtered.map(sch => {
              const col = sch.status==='green'?'#16A34A':sch.status==='yellow'?'#CA8A04':sch.status==='orange'?'#EA580C':'#DC2626';
              return (
                <div key={sch.id} onClick={()=>setSelected(sch)}
                  className="bg-slate-800 rounded-xl border border-white/7 cursor-pointer hover:bg-slate-750 transition-all overflow-hidden"
                  style={{ borderLeftWidth:4, borderLeftColor:col, borderLeftStyle:'solid' }}
                >
                  <div className="p-3 flex items-start gap-3">
                    <ScoreRing score={sch.score} size={46} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white truncate">{sch.name}</div>
                      <div className="text-xs text-slate-400 font-mono">{sch.emis}</div>
                      <div className="text-xs text-slate-400">{sch.village} · {sch.taluk}</div>
                      <div className="text-xs text-slate-400">{sch.type}</div>
                    </div>
                  </div>
                  <div className="px-3 pb-2">
                    <div className="flex gap-3 text-xs text-slate-400 mb-2">
                      <span>👩‍🎓 {sch.students}</span>
                      <span>👨‍🏫 {sch.teachers}</span>
                      {sch.open_complaints>0&&<span className="text-red-400">⚠ {sch.open_complaints} issues</span>}
                    </div>
                    <div className="flex gap-0.5 flex-wrap">
                      {INFRA_KEYS.map(([k,ic]) => (
                        <span key={k} title={k.replace('_',' ')} className={`text-xs px-1 py-0.5 rounded ${sch.infra[k]?'opacity-100':'opacity-20'}`}>{ic}</span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <Card noPad>
            <Table
              headers={['School Name','EMIS','Village','Taluk','Type','Students','Score','Status','Issues','Actions']}
              rows={filtered.map(s => {
                const col = s.status==='green'?'#16A34A':s.status==='yellow'?'#CA8A04':s.status==='orange'?'#EA580C':'#DC2626';
                return [
                  <button onClick={()=>setSelected(s)} className="text-xs text-white hover:text-amber-400 text-left font-semibold">{s.name}</button>,
                  <span className="font-mono text-xs text-slate-400">{s.emis}</span>,
                  <span className="text-xs">{s.village}</span>,
                  <span className="text-xs">{s.taluk}</span>,
                  <span className="text-xs">{s.type}</span>,
                  <span className="text-xs">{s.students}</span>,
                  <span className="text-xs font-bold" style={{ color:col }}>{s.score}</span>,
                  <Badge color={col}>{s.status.toUpperCase()}</Badge>,
                  <span className="text-xs" style={{ color:s.open_complaints>0?'#DC2626':'#16A34A' }}>{s.open_complaints}</span>,
                  <div className="flex gap-1">
                    <button onClick={()=>setSelected(s)} className="text-slate-400 hover:text-white p-1 rounded"><Eye size={12}/></button>
                    <button onClick={()=>deleteSchool(s.id)} className="text-slate-400 hover:text-red-400 p-1 rounded"><Trash2 size={12}/></button>
                  </div>,
                ];
              })}
            />
          </Card>
        )}

        {/* School Detail Modal */}
        <Modal open={!!selected} onClose={()=>setSelected(null)} title={selected?.name||''} size="xl">
          {selected && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <ScoreRing score={selected.score} size={64} />
                  <div>
                    <div className="text-sm font-bold text-white">{selected.name}</div>
                    <div className="text-xs text-slate-400 font-mono">EMIS: {selected.emis}</div>
                    <div className="text-xs text-slate-400">{selected.type} · {selected.village} · {selected.taluk}</div>
                    <div className="text-xs text-slate-400">HM: {selected.headmaster} · {selected.phone}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {[['Students',selected.students,'👩‍🎓'],['Teachers',selected.teachers,'👨‍🏫'],['Student:Teacher',`${(selected.students/selected.teachers).toFixed(1)}:1`,'📏'],['Open Issues',selected.open_complaints,'⚠️']].map(([l,v,ic])=>(
                    <div key={l} className="bg-slate-700 rounded-lg p-2.5 text-center">
                      <div className="text-base">{ic}</div>
                      <div className="text-base font-black text-white">{v}</div>
                      <div className="text-xs text-slate-400">{l}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs font-bold text-slate-400 uppercase mb-2">Infrastructure Checklist</div>
                <div className="space-y-1.5">
                  {INFRA_KEYS.map(([k,ic,label,weight]) => (
                    <div key={k} className="flex items-center gap-2 p-2 rounded-lg" style={{ background:selected.infra[k]?'rgba(22,163,74,.12)':'rgba(220,38,38,.08)' }}>
                      <span className="text-sm">{ic}</span>
                      <span className="text-xs text-slate-300 flex-1">{label}</span>
                      <span className="text-xs text-slate-500">+{weight}</span>
                      <span className={`text-xs font-bold ${selected.infra[k]?'text-green-400':'text-red-400'}`}>
                        {selected.infra[k]?'✓ Present':'✗ Missing'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </Modal>
      </div>
    </AdminLayout>
  );
}

// ── VILLAGES PAGE ─────────────────────────────────────────────
export function VillagesPage() {
  const { villages } = useAppStore();
  const [search, setSearch] = useState('');
  const [talukF, setTalukF] = useState('');
  const [statusF, setStatusF] = useState('');
  const [selected, setSelected] = useState(null);

  const filtered = useMemo(() => villages.filter(v=>
    (!search||v.name.toLowerCase().includes(search.toLowerCase())) &&
    (!talukF||v.taluk===talukF) && (!statusF||v.status===statusF)
  ), [villages, search, talukF, statusF]);

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title={`Village Module (${filtered.length})`} sub="Village Development Score · 6-dimension analysis" />
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-4">
          <KPICard label="🔴 Critical" value={villages.filter(v=>v.status==='red').length} icon="" color="#DC2626" />
          <KPICard label="🟠 High Priority" value={villages.filter(v=>v.status==='orange').length} icon="" color="#EA580C" />
          <KPICard label="🟡 Attention" value={villages.filter(v=>v.status==='yellow').length} icon="" color="#CA8A04" />
          <KPICard label="🟢 Good" value={villages.filter(v=>v.status==='green').length} icon="" color="#16A34A" />
          <KPICard label="Total Population" value={`${(villages.reduce((s,v)=>s+v.population,0)/100000).toFixed(1)}L`} icon="👥" color="#E8931A" />
        </div>
        <Card className="mb-4">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-40">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e=>setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Search village name…" />
            </div>
            <select value={talukF} onChange={e=>setTalukF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Taluks</option>{TALUKS.map(t=><option key={t}>{t}</option>)}
            </select>
            <select value={statusF} onChange={e=>setStatusF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Scores</option>
              <option value="red">Critical</option><option value="orange">High Priority</option>
              <option value="yellow">Attention</option><option value="green">Good</option>
            </select>
          </div>
        </Card>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.sort((a,b)=>a.vds-b.vds).map(v => {
            const col = getVDSColor(v.vds);
            const scores = [['💧',v.water_score],['🏫',v.school_score],['🛣️',v.road_score],['🚿',v.sanitation_score],['🏥',v.health_score],['🛡️',v.safety_score]];
            return (
              <div key={v.id} onClick={()=>setSelected(v)}
                className="bg-slate-800 rounded-xl border border-white/7 cursor-pointer hover:bg-slate-750 transition-all overflow-hidden"
                style={{ borderLeftWidth:4, borderLeftColor:col, borderLeftStyle:'solid' }}
              >
                <div className="p-3 flex items-center gap-3">
                  <ScoreRing score={v.vds} size={46} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-white">{v.name}</div>
                    <div className="text-xs text-slate-400">📍 {v.taluk} Taluk · {v.population.toLocaleString()} people</div>
                    <div className="text-xs mt-0.5" style={{ color:col }}>{getVDSLabel(v.vds)}</div>
                  </div>
                </div>
                <div className="px-3 pb-3">
                  {scores.map(([ic,sc]) => (
                    <div key={ic} className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs w-4">{ic}</span>
                      <div className="flex-1 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width:`${sc}%`, background:getVDSColor(sc) }} />
                      </div>
                      <span className="text-xs text-slate-400 w-6 text-right">{sc}</span>
                    </div>
                  ))}
                  {v.open_complaints>0&&<div className="text-xs text-red-400 mt-1">⚠ {v.open_complaints} open complaints</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AdminLayout>
  );
}

// ── WATER MODULE ──────────────────────────────────────────────
export function WaterPage() {
  const { waterAssets } = useAppStore();
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const filtered = useMemo(()=>waterAssets.filter(a=>!search||a.name.toLowerCase().includes(search.toLowerCase())||a.type.toLowerCase().includes(search.toLowerCase())),[waterAssets,search]);
  const STATUS_COLOR = { 'Operational':'#16A34A', 'Failed':'#DC2626', 'Offline':'#DC2626', 'Maintenance':'#CA8A04', 'Low Level':'#EA580C', 'Low Yield':'#EA580C', 'Partial Leak':'#EA580C', 'Overflow':'#7C3AED' };

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title={`Water Infrastructure (${filtered.length} assets)`} sub="Sources · Treatment · Distribution · Monitoring" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          {[['Operational',waterAssets.filter(a=>a.status==='Operational').length,'✅','#16A34A'],['Issues',waterAssets.filter(a=>!['Operational'].includes(a.status)).length,'⚠️','#DC2626'],['Borewells',waterAssets.filter(a=>a.type==='Borewell').length,'🔩','#0891B2'],['WTPs',waterAssets.filter(a=>a.type==='Water Treatment Plant').length,'🏭','#7C3AED']].map(([l,v,ic,col])=>(
            <KPICard key={l} label={l} value={v} icon={ic} color={col} />
          ))}
        </div>
        <Card className="mb-4">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={search} onChange={e=>setSearch(e.target.value)}
              className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
              placeholder="Search asset name, type…"
            />
          </div>
        </Card>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(a => {
            const col = STATUS_COLOR[a.status]||'#CA8A04';
            const TYPE_ICONS = { 'Dam':'🌊','Overhead Tank':'🛢️','Water Treatment Plant':'🏭','Borewell':'🔩','Pump Station':'⚙️','River Intake':'🌀','Reservoir':'💦','Sewage Treatment Plant':'⚗️','Pipeline Network':'🔧','Ground Level Tank':'🏗️','Public Tap':'🚰' };
            return (
              <div key={a.id} onClick={()=>setSelected(a)}
                className="bg-slate-800 rounded-xl border border-white/7 p-3 cursor-pointer hover:bg-slate-750 transition-all"
                style={{ borderLeftWidth:3, borderLeftColor:col, borderLeftStyle:'solid' }}
              >
                <div className="flex items-start gap-3 mb-2">
                  <span className="text-xl">{TYPE_ICONS[a.type]||'💧'}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-white truncate">{a.name}</div>
                    <div className="text-xs text-slate-400">{a.type} · {a.village}</div>
                    <div className="text-xs text-slate-400">{a.taluk}</div>
                  </div>
                  <Badge color={col}>{a.status}</Badge>
                </div>
                <div className="flex gap-3 text-xs text-slate-400">
                  {a.capacity&&<span>Cap: {a.capacity}</span>}
                  <span>📅 {a.last_inspection}</span>
                  {a.complaints>0&&<span className="text-red-400">⚠ {a.complaints} issues</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AdminLayout>
  );
}

// ── USERS PAGE ────────────────────────────────────────────────
export function UsersPage() {
  const { users, addUser, updateUser: upd, deleteUser, toggleUserStatus } = useAppStore();
  const [search, setSearch] = useState('');
  const [roleF, setRoleF] = useState('');
  const [addModal, setAddModal] = useState(false);
  const [form, setForm] = useState({ name:'', email:'', phone:'', role:'citizen', taluk:'Hosur', password:'', status:'active' });
  const setF = (k,v)=>setForm(f=>({...f,[k]:v}));

  const filtered = useMemo(()=>users.filter(u=>
    (!search||u.name.toLowerCase().includes(search.toLowerCase())||u.email.toLowerCase().includes(search.toLowerCase())) &&
    (!roleF||u.role===roleF)
  ),[users,search,roleF]);

  const handleAdd = () => {
    addUser({ ...form, avatar:'👤' });
    setAddModal(false);
    setForm({ name:'', email:'', phone:'', role:'citizen', taluk:'Hosur', password:'', status:'active' });
  };

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title={`Users (${filtered.length})`}
          actions={<Button variant="primary" size="sm" icon="+" onClick={()=>setAddModal(true)}>Add User</Button>}
        />
        <Card className="mb-4">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-40">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e=>setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500"
                placeholder="Search name or email…" />
            </div>
            <select value={roleF} onChange={e=>setRoleF(e.target.value)} className="bg-slate-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-500">
              <option value="">All Roles</option>
              {ROLES.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
          </div>
        </Card>
        <Card noPad>
          <Table
            headers={['Avatar','Name','Email','Phone','Role','Taluk','Status','Actions']}
            rows={filtered.map(u => {
              const role = ROLES.find(r=>r.id===u.role);
              return [
                <span className="text-xl">{u.avatar||'👤'}</span>,
                <span className="text-sm font-semibold text-white">{u.name}</span>,
                <span className="text-xs text-slate-400">{u.email}</span>,
                <span className="text-xs text-slate-400">{u.phone}</span>,
                <Badge color={role?.color||'#6B7280'}>{role?.label||u.role}</Badge>,
                <span className="text-xs">{u.taluk}</span>,
                <span className={`text-xs font-semibold ${u.status==='active'?'text-green-400':'text-red-400'}`}>{u.status}</span>,
                <div className="flex gap-1">
                  <button onClick={()=>toggleUserStatus(u.id)} className="text-xs px-1.5 py-0.5 rounded bg-slate-700 text-slate-300 hover:bg-white/10">{u.status==='active'?'Deactivate':'Activate'}</button>
                  <button onClick={()=>deleteUser(u.id)} className="text-slate-400 hover:text-red-400 p-1 rounded"><Trash2 size={12}/></button>
                </div>,
              ];
            })}
          />
        </Card>
        <Modal open={addModal} onClose={()=>setAddModal(false)} title="Add New User"
          footer={<><Button variant="ghost" onClick={()=>setAddModal(false)}>Cancel</Button><Button variant="primary" onClick={handleAdd}>Add User</Button></>}
        >
          <div className="space-y-3">
            <Input label="Full Name" value={form.name} onChange={v=>setF('name',v)} placeholder="Full name" />
            <Input label="Email" type="email" value={form.email} onChange={v=>setF('email',v)} placeholder="email@example.com" />
            <Input label="Phone" value={form.phone} onChange={v=>setF('phone',v)} placeholder="+91 XXXXX XXXXX" />
            <Input label="Password" type="password" value={form.password} onChange={v=>setF('password',v)} placeholder="Min 6 chars" />
            <Input label="Role" value={form.role} onChange={v=>setF('role',v)} options={ROLES.map(r=>({value:r.id,label:r.label}))} />
            <Input label="Taluk" value={form.taluk} onChange={v=>setF('taluk',v)} options={TALUKS} />
          </div>
        </Modal>
      </div>
    </AdminLayout>
  );
}

// ── OFFICERS PAGE ─────────────────────────────────────────────
export function OfficersPage() {
  const { officers } = useAppStore();
  const DEPT_ICONS = { 'District Administration':'⚖️', 'Revenue Department':'📜', 'DRDA':'🏗️', 'Education Department':'🏫', 'TWAD Water Supply':'💧', 'Public Health Engineering':'🚰', 'Electricity Board':'⚡', 'Public Works Department':'🛣️', 'Health Department':'🏥', 'Fire & Rescue':'🔥', 'Block Development':'📋', 'Panchayat Administration':'🏘️', 'Municipal Administration':'🏙️' };
  const LEVEL_BADGE = { collector:'#D97706', dro:'#7C3AED', drda_po:'#065F46', ceo:'#0891B2', deo:'#6D28D9', beo:'#7C3AED', bdo:'#059669', twad:'#0891B2', health:'#DC2626', fire:'#EF4444', electricity:'#B45309', municipal:'#6D28D9', panchayat:'#16A34A' };

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title={`Officer Directory (${officers.length})`} sub="Official contacts · Source: krishnagiri.nic.in" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {officers.map(o => {
            const col = LEVEL_BADGE[o.role] || '#6B7280';
            const ic = DEPT_ICONS[o.dept] || '👤';
            return (
              <div key={o.id} className="bg-slate-800 rounded-xl border border-white/7 p-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0" style={{ background:`${col}22`, border:`1px solid ${col}44` }}>{ic}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold text-white truncate">{o.name}</div>
                  <div className="text-xs text-slate-400 truncate">{o.designation}</div>
                  <div className="text-xs text-amber-400">{o.phone}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <Badge color={col}>{o.role.replace('_',' ').toUpperCase()}</Badge>
                  {o.taluk&&<div className="text-xs text-slate-500 mt-0.5">{o.taluk}</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AdminLayout>
  );
}

// ── REPORTS PAGE ──────────────────────────────────────────────
export function ReportsPage() {
  const { complaints, villages, schools, waterAssets } = useAppStore();
  const [period, setPeriod] = useState('monthly');

  const deptData = DEPARTMENTS.map(d => {
    const dc = complaints.filter(c=>c.dept===d.id);
    const resolved = dc.filter(c=>c.status==='resolved').length;
    return { name:d.name.split(' ')[0], total:dc.length, resolved, rate:dc.length?Math.round(resolved/dc.length*100):0 };
  });

  const categoryData = Object.entries(CAT_CONFIG).map(([k,v]) => {
    const cnt = complaints.filter(c=>c.category===k).length;
    return { name:v.label.split(' ').slice(0,2).join(' '), value:cnt, icon:v.icon };
  }).sort((a,b)=>b.value-a.value).slice(0,10);

  return (
    <AdminLayout>
      <div className="p-5 max-w-7xl mx-auto">
        <SectionHeader title="Reports & Analytics" sub="District-wide performance data"
          actions={
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" icon="📄">Export PDF</Button>
              <Button variant="ghost" size="sm" icon="📊">Export CSV</Button>
              <Button variant="ghost" size="sm" icon="📈">Export Excel</Button>
            </div>
          }
        />

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <KPICard label="Total Complaints" value={complaints.length} icon="📋" color="#E8931A" />
          <KPICard label="Avg Resolution" value="38.4h" icon="⏱️" color="#0891B2" />
          <KPICard label="SLA Compliance" value={`${Math.round(complaints.filter(c=>!c.overdue).length/complaints.length*100)}%`} icon="✅" color="#16A34A" />
          <KPICard label="Critical Resolved" value={`${Math.round(complaints.filter(c=>c.severity==='critical'&&c.status==='resolved').length/Math.max(complaints.filter(c=>c.severity==='critical').length,1)*100)}%`} icon="🚨" color="#DC2626" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <Card>
            <SectionHeader title="Complaints by Category (Top 10)" />
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={categoryData} margin={{ top:0, right:0, bottom:40, left:0 }}>
                <XAxis dataKey="name" tick={{ fill:'#94A3B8', fontSize:8 }} angle={-40} textAnchor="end" />
                <YAxis tick={{ fill:'#94A3B8', fontSize:9 }} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="value" fill="#E8931A" radius={[3,3,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card>
            <SectionHeader title="Department Resolution Rates" />
            <div className="space-y-2">
              {deptData.filter(d=>d.total>0).sort((a,b)=>b.rate-a.rate).map(d => {
                const col = d.rate>=80?'#16A34A':d.rate>=60?'#CA8A04':'#DC2626';
                return (
                  <div key={d.name} className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 w-20 truncate">{d.name}</span>
                    <ProgressBar value={d.rate} color={col} />
                    <span className="text-xs font-bold w-8 text-right" style={{ color:col }}>{d.rate}%</span>
                    <span className="text-xs text-slate-500 w-8 text-right">{d.total}</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card>
            <SectionHeader title="Village Score Distribution" />
            {[['🟢 Good (80+)',villages.filter(v=>v.status==='green').length,'#16A34A'],['🟡 Attention (60-79)',villages.filter(v=>v.status==='yellow').length,'#CA8A04'],['🟠 High (40-59)',villages.filter(v=>v.status==='orange').length,'#EA580C'],['🔴 Critical (<40)',villages.filter(v=>v.status==='red').length,'#DC2626']].map(([l,v,c])=>(
              <div key={l} className="flex items-center gap-2 mb-2">
                <span className="text-xs text-slate-400 w-28 truncate">{l}</span>
                <ProgressBar value={v} max={villages.length} color={c} />
                <span className="text-xs font-bold w-4 text-right" style={{ color:c }}>{v}</span>
              </div>
            ))}
          </Card>
          <Card>
            <SectionHeader title="School Infrastructure" />
            {[['🟢 Good',schools.filter(s=>s.status==='green').length,'#16A34A'],['🟡 Attention',schools.filter(s=>s.status==='yellow').length,'#CA8A04'],['🟠 High',schools.filter(s=>s.status==='orange').length,'#EA580C'],['🔴 Critical',schools.filter(s=>s.status==='red').length,'#DC2626']].map(([l,v,c])=>(
              <div key={l} className="flex items-center gap-2 mb-2">
                <span className="text-xs text-slate-400 w-24 truncate">{l}</span>
                <ProgressBar value={v} max={schools.length} color={c} />
                <span className="text-xs font-bold w-4 text-right" style={{ color:c }}>{v}</span>
              </div>
            ))}
          </Card>
          <Card>
            <SectionHeader title="Water Asset Status" />
            {Object.entries(waterAssets.reduce((acc,a)=>{acc[a.status]=(acc[a.status]||0)+1;return acc;},{})).sort((a,b)=>b[1]-a[1]).map(([s,v])=>{
              const col = s==='Operational'?'#16A34A':s.includes('Failed')||s==='Offline'?'#DC2626':'#CA8A04';
              return (
                <div key={s} className="flex items-center gap-2 mb-2">
                  <span className="text-xs text-slate-400 w-28 truncate">{s}</span>
                  <ProgressBar value={v} max={waterAssets.length} color={col} />
                  <span className="text-xs font-bold w-4 text-right" style={{ color:col }}>{v}</span>
                </div>
              );
            })}
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}

// ── NOTIFICATIONS PAGE ────────────────────────────────────────
export function NotificationsPage() {
  const { notifications, markNotificationRead, markAllRead, clearNotifications } = useAppStore();
  const TYPE_ICONS = { new_complaint:'📋', escalation:'⚡', status_change:'🔄', resolved:'✅', overdue:'⏰' };
  return (
    <AdminLayout>
      <div className="p-5 max-w-3xl mx-auto">
        <SectionHeader title={`Notifications (${notifications.length})`}
          actions={<div className="flex gap-2"><Button variant="ghost" size="sm" onClick={markAllRead}>Mark All Read</Button><Button variant="ghost" size="sm" onClick={clearNotifications}>Clear All</Button></div>}
        />
        {notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No notifications" description="You're all caught up!" />
        ) : (
          <div className="space-y-2">
            {notifications.map(n => (
              <div key={n.id} onClick={()=>markNotificationRead(n.id)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${n.read?'bg-slate-800 border-white/7':'bg-amber-500/10 border-amber-500/25'}`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-xl">{TYPE_ICONS[n.type]||'🔔'}</span>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-white">{n.title}</div>
                    <div className="text-xs text-slate-400">{n.message}</div>
                    <div className="text-xs text-slate-500 mt-1">{timeAgo(n.created_at)}</div>
                  </div>
                  {!n.read && <div className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0 mt-1" />}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

// ── SETTINGS PAGE ─────────────────────────────────────────────
export function SettingsPage() {
  const [activeTab, setActiveTab] = useState('general');
  return (
    <AdminLayout>
      <div className="p-5 max-w-4xl mx-auto">
        <SectionHeader title="Settings & Configuration" />
        <div className="flex gap-2 mb-4">
          {['general','sla','routing','notifications','security'].map(t=>(
            <button key={t} onClick={()=>setActiveTab(t)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${activeTab===t?'bg-amber-500 text-slate-900':'bg-slate-700 text-slate-400 hover:text-white'}`}>{t}</button>
          ))}
        </div>
        {activeTab==='general'&&(
          <Card>
            <div className="text-xs font-bold text-slate-400 uppercase mb-3">General Settings</div>
            <div className="space-y-3">
              {[['App Name','Krishnagiri Connect'],['District','Krishnagiri, Tamil Nadu'],['Collector','Tmt. K. M. Sarayu, I.A.S.'],['Admin Email','admin@krishnagiriconnect.in'],['Default Language','English / Tamil']].map(([l,v])=>(
                <div key={l} className="flex items-center justify-between p-3 rounded-lg bg-slate-700">
                  <span className="text-sm text-slate-300">{l}</span>
                  <span className="text-sm font-semibold text-white">{v}</span>
                </div>
              ))}
            </div>
          </Card>
        )}
        {activeTab==='sla'&&(
          <Card>
            <div className="text-xs font-bold text-slate-400 uppercase mb-3">SLA Configuration</div>
            <div className="space-y-2">
              {[['Emergency','1 hour','#7C3AED'],['Critical','24 hours','#DC2626'],['High','72 hours (3 days)','#EA580C'],['Medium','168 hours (7 days)','#CA8A04'],['Low','720 hours (30 days)','#16A34A']].map(([s,t,c])=>(
                <div key={s} className="p-3 rounded-lg flex items-center justify-between" style={{ background:`${c}15`, borderLeft:`3px solid ${c}` }}>
                  <span className="text-sm font-semibold" style={{ color:c }}>{s}</span>
                  <span className="text-sm text-slate-300">{t}</span>
                  <Button variant="ghost" size="sm">Edit</Button>
                </div>
              ))}
            </div>
          </Card>
        )}
        {activeTab==='routing'&&(
          <Card>
            <div className="text-xs font-bold text-slate-400 uppercase mb-3">Auto-Routing Rules</div>
            <div className="space-y-2">
              {Object.entries(CAT_CONFIG).slice(0,8).map(([k,v])=>{
                const dept = DEPARTMENTS.find(d=>d.id===v.dept);
                return (
                  <div key={k} className="p-2.5 rounded-lg bg-slate-700 flex items-center gap-2">
                    <span className="text-base">{v.icon}</span>
                    <span className="text-xs text-white flex-1">{v.label}</span>
                    <span className="text-xs text-slate-400">→</span>
                    <span className="text-xs text-amber-400">{dept?.name||v.dept}</span>
                  </div>
                );
              })}
            </div>
          </Card>
        )}
        {(activeTab==='notifications'||activeTab==='security')&&(
          <EmptyState icon="⚙️" title="Coming soon" description="This section will be available in the next release" />
        )}
      </div>
    </AdminLayout>
  );
}
