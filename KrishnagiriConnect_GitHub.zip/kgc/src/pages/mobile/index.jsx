import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore, useAuthStore } from '../../store/index.js';
import { Button, Spinner } from '../../components/ui/index.jsx';
import { getRoleDashboard } from '../../utils/index.js';

// ── SPLASH SCREEN ─────────────────────────────────────────────
export function SplashScreen() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 1200);
    const t3 = setTimeout(() => {
      if (isAuthenticated && user) {
        navigate(getRoleDashboard(user.role));
      } else {
        navigate('/language');
      }
    }, 2800);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="absolute rounded-full border border-amber-500"
            style={{ width: 40+i*30, height: 40+i*30, top:'50%', left:'50%', transform:'translate(-50%,-50%)', opacity: 1-i*0.05 }} />
        ))}
      </div>

      <div className={`flex flex-col items-center gap-4 transition-all duration-700 ${phase>=1?'opacity-100 translate-y-0':'opacity-0 translate-y-8'}`}>
        <div className="w-24 h-24 rounded-full flex items-center justify-center text-5xl shadow-2xl" style={{ background:'radial-gradient(circle at 38% 38%,#F59E0B,#D97706)', boxShadow:'0 0 60px rgba(232,147,26,.5)' }}>
          🏛️
        </div>
        <div className="text-center">
          <h1 className="text-3xl font-black text-white">Krishnagiri</h1>
          <h1 className="text-3xl font-black" style={{ color:'#E8931A' }}>Connect</h1>
          <div className="text-sm text-slate-400 mt-2" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>கிருஷ்ணகிரி இணைப்பு</div>
        </div>
        <div className="text-xs text-slate-500 text-center">
          Govt. of Tamil Nadu · District Administration<br/>
          கிருஷ்ணகிரி மாவட்ட நிர்வாகம்
        </div>
      </div>

      {phase >= 2 && (
        <div className="absolute bottom-16 flex flex-col items-center gap-3">
          <Spinner size={24} />
          <div className="text-xs text-slate-500">Loading district data…</div>
        </div>
      )}

      <div className="absolute bottom-6 text-xs text-slate-600 text-center px-4">
        A Digital Governance Initiative · National e-Governance Programme
      </div>
    </div>
  );
}

// ── LANGUAGE SELECTION ────────────────────────────────────────
export function LanguageSelect() {
  const navigate = useNavigate();
  const { setLanguage } = useAppStore();

  const choose = (lang) => {
    setLanguage(lang);
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 px-6">
      <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl mb-6 shadow-xl" style={{ background:'radial-gradient(circle at 38% 38%,#F59E0B,#D97706)' }}>🏛️</div>
      <h2 className="text-xl font-black text-white mb-1">Select Language</h2>
      <div className="text-sm text-slate-400 mb-8" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>மொழியை தேர்ந்தெடுக்கவும்</div>

      <div className="w-full max-w-xs space-y-3">
        <button onClick={()=>choose('en')}
          className="w-full p-5 rounded-2xl flex items-center gap-4 transition-all border hover:border-amber-500 bg-slate-800 border-white/10 hover:bg-slate-750"
        >
          <span className="text-3xl">🇬🇧</span>
          <div className="text-left">
            <div className="text-base font-bold text-white">English</div>
            <div className="text-xs text-slate-400">Continue in English</div>
          </div>
        </button>

        <button onClick={()=>choose('ta')}
          className="w-full p-5 rounded-2xl flex items-center gap-4 transition-all border hover:border-amber-500 bg-slate-800 border-white/10 hover:bg-slate-750"
        >
          <span className="text-3xl">🇮🇳</span>
          <div className="text-left">
            <div className="text-base font-bold text-white" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>தமிழ்</div>
            <div className="text-xs text-slate-400" style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>தமிழில் தொடரவும்</div>
          </div>
        </button>
      </div>

      <div className="mt-8 text-xs text-slate-500 text-center">
        You can change language anytime from Profile<br/>
        <span style={{ fontFamily:"'Noto Sans Tamil',sans-serif" }}>எப்போதும் மொழி மாற்றலாம்</span>
      </div>
    </div>
  );
}
