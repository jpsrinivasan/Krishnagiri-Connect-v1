import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/index.js';
import { getRoleDashboard } from './utils/index.js';
import { LoginPage, SignupPage } from './pages/auth/index.jsx';
import { SplashScreen, LanguageSelect } from './pages/mobile/index.jsx';
import { AdminDashboard, ComplaintsPage, EscalationPage, CollectorDashboard, SchoolsPage, VillagesPage, WaterPage, UsersPage, OfficersPage, ReportsPage, NotificationsPage, SettingsPage } from './pages/admin/index.jsx';
import { AdminMapPage, OfficerMapPage, CitizenMapPage } from './pages/map/index.jsx';
import { OfficerDashboard, OfficerComplaintsPage, OfficerProfilePage } from './pages/officer/index.jsx';
import { CitizenHome, ReportForm, MyTickets, TicketDetail, CitizenProfile, CitizenNotifications } from './pages/citizen/index.jsx';

// Inject Leaflet globally
if (!window._leafletLoaded) {
  window._leafletLoaded = true;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  document.head.appendChild(link);
  const script = document.createElement('script');
  script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
  document.head.appendChild(script);
}

function RequireAuth({ children, adminOnly = false, officerOnly = false }) {
  const { isAuthenticated, user } = useAuthStore();
  const location = useLocation();
  if (!isAuthenticated) return <Navigate to="/login" state={{ from: location }} replace />;
  const ADMIN_ROLES = ['super_admin','admin','collector','dro','drda_po','ceo','deo','beo'];
  const OFFICER_ROLES = ['bdo','panchayat','twad','municipal','health','electricity','fire','headmaster','teacher'];
  if (adminOnly && !ADMIN_ROLES.includes(user?.role)) return <Navigate to={getRoleDashboard(user?.role)} replace />;
  if (officerOnly && !OFFICER_ROLES.includes(user?.role) && !ADMIN_ROLES.includes(user?.role)) return <Navigate to={getRoleDashboard(user?.role)} replace />;
  return children;
}

function RootRedirect() {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/" replace />;
  return <Navigate to={getRoleDashboard(user?.role)} replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="bottom-center" toastOptions={{ style:{ background:'#1E293B', color:'#E2EBF8', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'12px' }, duration:2500 }} />
      <Routes>
        <Route path="/" element={<SplashScreen />} />
        <Route path="/language" element={<LanguageSelect />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/admin" element={<RequireAuth adminOnly><AdminDashboard /></RequireAuth>} />
        <Route path="/admin/collector" element={<RequireAuth adminOnly><CollectorDashboard /></RequireAuth>} />
        <Route path="/admin/map" element={<RequireAuth adminOnly><AdminMapPage /></RequireAuth>} />
        <Route path="/admin/complaints" element={<RequireAuth adminOnly><ComplaintsPage /></RequireAuth>} />
        <Route path="/admin/escalation" element={<RequireAuth adminOnly><EscalationPage /></RequireAuth>} />
        <Route path="/admin/schools" element={<RequireAuth adminOnly><SchoolsPage /></RequireAuth>} />
        <Route path="/admin/villages" element={<RequireAuth adminOnly><VillagesPage /></RequireAuth>} />
        <Route path="/admin/water" element={<RequireAuth adminOnly><WaterPage /></RequireAuth>} />
        <Route path="/admin/users" element={<RequireAuth adminOnly><UsersPage /></RequireAuth>} />
        <Route path="/admin/officers" element={<RequireAuth adminOnly><OfficersPage /></RequireAuth>} />
        <Route path="/admin/reports" element={<RequireAuth adminOnly><ReportsPage /></RequireAuth>} />
        <Route path="/admin/notifications" element={<RequireAuth adminOnly><NotificationsPage /></RequireAuth>} />
        <Route path="/admin/settings" element={<RequireAuth adminOnly><SettingsPage /></RequireAuth>} />
        <Route path="/officer" element={<RequireAuth officerOnly><OfficerDashboard /></RequireAuth>} />
        <Route path="/officer/complaints" element={<RequireAuth officerOnly><OfficerComplaintsPage /></RequireAuth>} />
        <Route path="/officer/map" element={<RequireAuth officerOnly><OfficerMapPage /></RequireAuth>} />
        <Route path="/officer/profile" element={<RequireAuth officerOnly><OfficerProfilePage /></RequireAuth>} />
        <Route path="/citizen" element={<RequireAuth><CitizenHome /></RequireAuth>} />
        <Route path="/citizen/report" element={<RequireAuth><ReportForm /></RequireAuth>} />
        <Route path="/citizen/tickets" element={<RequireAuth><MyTickets /></RequireAuth>} />
        <Route path="/citizen/ticket/:id" element={<RequireAuth><TicketDetail /></RequireAuth>} />
        <Route path="/citizen/map" element={<RequireAuth><CitizenMapPage /></RequireAuth>} />
        <Route path="/citizen/profile" element={<RequireAuth><CitizenProfile /></RequireAuth>} />
        <Route path="/citizen/notifications" element={<RequireAuth><CitizenNotifications /></RequireAuth>} />
        <Route path="*" element={<RootRedirect />} />
      </Routes>
    </BrowserRouter>
  );
}
